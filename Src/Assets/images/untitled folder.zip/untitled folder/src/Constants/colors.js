export default {
  bgcolor: '#29282d',
  inputBgColor: "#303030",
  white: '#ffffff',
  black: '#000000',
  red: 'red',
  lightRed: '#fc8c00',
  lightRedGray: "#543a29",
  placeTextColor: "#999999",
  golden: '#f68b00',
  Orange: '#f68b00',
  transWhite: '#f9e7e5a6',
  transBlack: '#00000085',
  transOrange: '#81541d'
};
