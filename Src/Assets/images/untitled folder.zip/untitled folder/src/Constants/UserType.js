import { LangStrings } from "../Languages/langStrings";

export const USER_PRODUCER = [
  {
    name: LangStrings.producerDrawer?.home,
    routeName: 'ProducerDashboard',
  },
  {
    name: LangStrings.producerDrawer.myProfile,
    routeName: 'MyProfile',
  },
  {
    name: LangStrings.producerDrawer.eventManagement,
    isOpen: false,
    subRoute: [
      {
        name: LangStrings.producerDrawer.allEvents,
        routeName: 'MyEvents'
      },
      {
        name: LangStrings.producerDrawer.associatedEvents,
        routeName: 'AssociatedEvents'
      },
      {
        name: LangStrings.producerDrawer.createEvent,
        routeName: 'CreateEvents'
      },
      {
        name: LangStrings.producerDrawer.myStaff,
        routeName: 'StaffManagement'
      },
      {
        name: LangStrings.producerDrawer.beverages,
        routeName: 'Beverages'
      },
      {
        name: LangStrings.producerDrawer.beverageOrders,
        routeName: 'BeveragesOrders',
      },
      {
        name: LangStrings.producerDrawer.tasks,
        routeName: 'MyTasks'
      },
    ]
  },
  {
    name: LangStrings.producerDrawer.eventAnalytics,
    isOpen: false,
    subRoute: [
      {
        name: LangStrings.producerDrawer.ticketSold,
        routeName: ''
      },
      {
        name: LangStrings.producerDrawer.NftSold,
        routeName: 'NFTS'
      },
      {
        name: LangStrings.producerDrawer.pr,
        routeName: 'PrListing'
      },
    ]
  },
  // {
  //   name: 'My Events',
  //   subRoute: [
  //     {
  //       name: 'All Events',
  //       routeName: 'MyEvents'
  //     },
  //     {
  //       name: 'Associated events',
  //       routeName: 'AssociatedEvents'
  //     },
  //     // {
  //     //   name: 'Current events',
  //     //   routeName: 'EventsListing'
  //     // },
  //     // {
  //     //   name: 'Past events',
  //     //   routeName: 'EventsListing'
  //     // },
  //     // {
  //     //   name: 'Future events',
  //     //   routeName: 'EventsListing'
  //     // },
  //     // {
  //     //   name:'Popular events',
  //     //   routeName:'EventsListing'
  //     // },
  //   ]
  // },
  // {
  //   name: 'Nfts',
  //   routeName: 'NFTS',
  // },
  // {
  //   name: 'Collections',
  //   routeName: 'Collections',
  // },
  // {
  //   name: 'Favourites',
  //   routeName: 'Fevorites',
  // },
  // {
  //   name: 'Beverages',
  //   routeName: 'Beverages',
  // },
  // {
  //   name: 'Beverages Orders',
  //   routeName: 'BeveragesOrders',
  // },
  // {
  //   name: 'Staff Management',
  //   routeName: 'StaffManagement',
  // },
  // {
  //   name: 'ToDo',
  //   routeName: 'MyTasks',
  // },
  // {
  //   name: 'PR',
  //   routeName: 'PrListing'
  // },
  {
    name: LangStrings.producerDrawer.transections,
    routeName: 'PaymentManagement',
  },
  {
    name: LangStrings.producerDrawer.community,
    routeName: 'NewsListing',
  },
  // {
  //   name: 'My Wallet',
  //   routeName: 'WalletModule',
  // },
  // {
  //   name: 'Treading History',
  //   routeName: 'TreadingHistory',
  // },
];

export const USER_ARTIST = [
  {
    name:LangStrings.artistDrawer.home,
    routeName: 'ArtistDashboard',
  },
  {
    name: LangStrings.artistDrawer.myProfile,
    routeName: 'MyProfile',
  },
  {
    name: LangStrings.artistDrawer.collection,
    routeName: 'Collections',
  },
  {
    name: LangStrings.artistDrawer.event,
    routeName: 'EventsListing',
  },
  {
    name: LangStrings.artistDrawer.nfts,
    routeName: 'NFTS',
  },
  {
    name:LangStrings.artistDrawer.transactions,
    routeName: 'PaymentManagement',
  },
  {
    name: LangStrings.artistDrawer.myWallet,
    routeName: 'WalletModule',
  },
  // {
  //   name: 'Treading History',
  //   routeName: 'TreadingHistory',
  // },
];

export const USER_PR = [
  {
    name: LangStrings.prDrawer.home,
    routeName: 'PRDashboard',
  },
  {
    name: LangStrings.prDrawer.myProfile,
    routeName: 'MyProfile',
  },
  {
    name: LangStrings.prDrawer.event,
    routeName: 'AssociatedEvents'
  },
  // {
  //   name: 'Nfts',
  //   routeName: 'NFTS',
  // },
  {
    name: LangStrings.prDrawer.myWallet,
    routeName: 'WalletModule',
  },

  // {
  //   name: 'Payment Mangement',
  //   routeName: 'PaymentManagement',
  // },
  {
    name: LangStrings.prDrawer.transactions,
    routeName: 'PaymentManagement',
  },
  // {
  //   name: 'Treading History',
  //   routeName: 'TreadingHistory',
  // },
];

export const USER_FAN = [
  {
    name: LangStrings.fanDrawer.home,
    routeName: 'FanDashboard'
  },
  {
    name: LangStrings.fanDrawer.myProfile,
    routeName: 'MyProfile'
  },
  {
    name: LangStrings.fanDrawer.favorites,
    routeName: 'Fevorites'
  },
  {
    name: LangStrings.fanDrawer.event,
    isOpen: false,
    subRoute: [
      {
        name: LangStrings.fanDrawer.popularEvents,
        routeName: 'PopularEvents'
      },
      {
        name: LangStrings.fanDrawer.upcomingEvents,
        routeName: 'UpcomingEventsListing'
      },
    ]
  },
  // {
  //   name: 'Nfts',
  //   routeName: 'NFTS'
  // },
  {
    name: LangStrings.fanDrawer.collection,
    routeName: 'Collections'
  },
  // {
  //     name:'Book Ticket',
  //     routeName:'TicketBooking'
  // },
  // {
  //   name: 'Purchase EMT',
  //   routeName: 'WalletModule'
  // },
  {
    name: LangStrings.fanDrawer.transactions,
    routeName: 'PaymentManagement'
  },
  // {
  //   name: 'My Wallet',
  //   routeName: 'WalletModule'
  // },
  // {
  //   name: 'Treading History',
  //   routeName: 'TreadingHistory'
  // }
]
export const USER_STAFF = [
  {
    name: LangStrings.stafDrawer.home,
    routeName: 'StaffDashboard'
  },
  {
    name: LangStrings.stafDrawer.myProfile,
    routeName: 'MyProfile'
  },
  {
    name: LangStrings.stafDrawer.myTasks,
    routeName: 'AssignedTasks',
  },
]
