export const renderIf = (condition, Element = () => { }) => {
  if (condition !== null && condition !== undefined && condition !== '') {
    return Element;
  }
};

export const percentageCalculate = (val, total) => {
  return (val / total) * 100
}

export const isOver18 = (dateOfBirth) => {
  const dob = new Date(dateOfBirth);

  const ageDiffMs = Date.now() - dob.getTime();

  const ageDate = new Date(ageDiffMs);
  const age = Math.abs(ageDate.getUTCFullYear() - 1970);

  // Return true if the person is 18 or older
  return age >= 18;
}
