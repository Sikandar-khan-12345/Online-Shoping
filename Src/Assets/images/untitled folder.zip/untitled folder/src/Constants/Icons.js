export default {
 homeBG:require('../../assets/home_bg.jpg')
};
