import { SimpleToaster } from '../Backend/Backend';
const VALIDATE = {
    EMAIL: /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
    ALPHABET_ONLY: /^[a-zA-Z \s]*$/,
    NUMBER: /[0-9]$/,
    MOBILE: /^[0-9]{1,20}$/,
    STREET: /^[a-zA-Z0-9 '-.~!@#$%^&*()_+={}[];':"<>,.\s]*$/,
    PASSWORD: /[d\-_\s]+$/,
};


export const isValidForm = (form = {}) => {
    let valid = true;
    for (const field in form) {
        if (Object.hasOwnProperty.call(form, field)) {
            const error = form[field];
            valid = valid && !error;
        }
    }
    return valid;
};




export const validators = {
    checkAlphabet: (name, min, max, value) => {
        var min = min || 2;
        var max = max || 30;
        if (value) {
            if (!VALIDATE.ALPHABET_ONLY.test(value)) {
                // SimpleToaster();
                return `${name} is Invalid.`;
            } else if (value.length < min || value.length > max) {
                // SimpleToaster();
                return `${name} must be between ${min} to ${max} Characters.`;
            }
            return null;
        } else {
            // SimpleToaster();
            return `${name} is Required.`;
        }
    },
    checkRegex:(name,value,regex)=>{
        if (value) {
            if (!regex.test(value)) {
                return `${name} is Invalid.`;
            } else {
                return null
            }
        } else {
            return `${name} is Required.`;
        }
    },
    checkEmail: (name, value) => {
        if (value) {
            if (!VALIDATE.EMAIL.test(value)) {
                return `${name} is Invalid.`;
            } else {
                return null
            }
        } else {
            return `${name} is Required.`;
        }
        return null;
    },

    checkNumber: (name, value) => {

        if (value) {
            if (!VALIDATE.NUMBER.test(value)) {

                return `${name} is Invalid.`;
            }
            return null;
        } else {
            // SimpleToaster();
            return `${name} is Required.`;
        }
    },

    checkPhoneNumberWithFixLength: (name, max, value) => {
        var max = max || 10;
        if (value) {
            if (!VALIDATE.MOBILE.test(value)) {
                SimpleToaster(`${name} is Invalid.`);
                return false;
            } else if (value.length != max) {
                SimpleToaster(`${name} should be ${max} digits.`);
                return false;
            }
            return true;
        } else {
            SimpleToaster(`${name} is Required.`);
            return false;
        }
    },

    checkOptionalPhoneNumberWithFixLength: (name, max, value) => {
        var max = max || 10;
        if (value) {
            if (!VALIDATE.MOBILE.test(value)) {
                SimpleToaster(`${name} is Invalid.`);
                return false;
            } else if (value.length != max) {
                SimpleToaster(`${name} should be ${max} digits.`);
                return false;
            }
            return true;
        } else {
            return true;
        }
    },

    checkPhoneNumber: (name, value, min, max) => {
        var min = min || 7;
        var max = max || 15;
        if (value) {
            if (!VALIDATE.MOBILE.test(value)) {
                return `${name} is Invalid.`;
            } else {
                return null
            }
            // else if (value.length < min || value.length > max) {
            //     //   SimpleToaster(`${name} should be greater than ${min - 1} digits.`);
            //     return `${name} should be greater than ${min - 1} digits.`;
            // }
            // return null;
        } else {
            // SimpleToaster(`${name} is Required.`);
            return `${name} is Required.`;
        }
    },

    checkNotNull: (name, min, max, value) => {
        var min = min || 5;
        var max = max || 40;
        if (value) {
            if (value.length < min || value.length > max) {
                SimpleToaster(`${name} must be between ${min} to ${max} Characters.`);
                return false;
            }
            return null;
        } else {
            // SimpleToaster(`${name} is Required.`);
            return `${name} is Required.`;
        }
    },

    checkRequire: (name, value) => {
        if (value) {
            return null;
        } else {
            return ` ${name} is required.  `;
        }
    },
    checkMultiple: (name, value) => {

        if (value?.length > 0) {
            return null
        } else {
            return `${name} is required.`
        }
        // if (value) {
        //     return null;
        // } else {
        //     return `Please enter ${name}`;
        // }
    },

    checkPassword: (name, value) => {

        if (value) {
            if (VALIDATE.PASSWORD.test(value)) {
                return `${name} is Invalid.`;
            } else {
                return null
            }
            //  else if (value.length < min || value.length > max) {
            //   return `${name} entered must be between ${min} to ${max} Characters.`;
            // }
            // return '';
        } else {
            return `${name} is Required.`;
        }
    },

    checkMatch: (name, value, name2, value2) => {
        // var min = min || 5;
        // var max = max || 40;
        if (value == value2) {
            return '';
        } else {
            // SimpleToaster(`${name} and ${name2} should be same.`);
            return `${name} and ${name2} should be same.`;
        }
    },

    checkStreet: (name, min, max, value) => {
        var min = min || 7;
        var max = max || 15;
        if (value) {
            if (VALIDATE.STREET.test(value)) {
                SimpleToaster(`${name} is Invalid.`);
                return false;
            } else if (value.length < min || value.length > max) {
                SimpleToaster(
                    `${name} entered must be between ${min} to ${max} Characters.`,
                );
                return false;
            }
            return true;
        } else {
            SimpleToaster(`${name} is Required.`);
            return false;
        }
    },
};