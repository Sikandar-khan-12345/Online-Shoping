import AsyncStorage from "@react-native-async-storage/async-storage";
import { createRef } from "react";
import variables from "../../utils/variables";

export const print = (...args) => {
  console.log(...args);
};
export const CURRENCY = 'EMT';
export const USDT = '$';


export const navigationRef = createRef()

export const checkProfilePending = async () => {
  let status = await AsyncStorage.getItem(variables.IS_PENDING)
  if (status === 'pending') {
    navigationRef.current?.reset({
      index: 0,
      routes: [{ name: 'Registration' }]
    })
  }
}

export const removePendingStatus = async () => {
  await AsyncStorage.removeItem(variables.IS_PENDING)
  return true
}
