export default {
  regular: 'blinker',
  medium: 'blinker',
  bold: 'blinker',
  // regular: 'Blinker-Regular',
  // medium: 'Blinker-Semibold',
  // bold: 'Blinker-Bold',
};
