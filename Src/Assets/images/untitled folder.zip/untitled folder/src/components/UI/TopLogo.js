import { StyleSheet, Text, View, Image } from 'react-native';
import React, { memo } from 'react';
import Icons from '../../Constants/Icons';
const TopLogo = () => {
  return (
    <View style={styles.topImg}>
      <Image style={styles.Img} source={Icons.logo} />
    </View>
  );
};

export default memo(TopLogo);

const styles = StyleSheet.create({
  topImg: {
    justifyContent: 'space-between',
    alignItems: 'center',
    marginVertical: 20,
  },
  Img: {
    //  width:width /2.20,
    //  height:height * 0.09
    width: 222,
    height: 71,
  },
});
