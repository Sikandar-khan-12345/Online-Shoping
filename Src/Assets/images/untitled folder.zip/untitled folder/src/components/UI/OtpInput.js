import { StyleSheet, Text, TextInput, View } from 'react-native';
import React, { useEffect, useRef, useState } from 'react';
import fonts from '../../Constants/fonts';
import colors from '../../Constants/colors';
import { ErrorBox } from './CommonTextInput';

const OTPInput = ({ onComplete = () => { }, error = '' }) => {
    const [input1, setInput1] = useState('');
    const [input2, setInput2] = useState('');
    const [input3, setInput3] = useState('');
    const [input4, setInput4] = useState('');

    const input1Ref = useRef(null);
    const input2Ref = useRef(null);
    const input3Ref = useRef(null);
    const input4Ref = useRef(null);
    useEffect(() => {
        focusHandler();
    }, [input1, input2, input3, input4]);
    const focusHandler = () => {
        if (!!input1 && !!input2 && input3 && !!input4) {
            onComplete(`${input1}${input2}${input3}${input4}`);
        } else if (!!input1 && !!input2 && !!input3) {
            input4Ref.current.focus();
        } else if (!!input1 && !!input2) {
            input3Ref.current.focus();
        } else if (!!input1) {
            input2Ref.current.focus();
        } else {
            input1Ref.current.focus();
        }
    };
    function onBackspaceClick(inp, ref) {
        return e => {
            if (e.nativeEvent.key === 'Backspace') {
                if (!inp) {
                    ref.current.focus();
                }
            }
        };
    }

    return (
        <View>
            <View style={styles.container}>
                <TextInput
                    ref={input1Ref}
                    value={input1}
                    onChangeText={setInput1}
                    style={styles.input}
                    maxLength={1}
                    keyboardType="number-pad"
                    onKeyPress={onBackspaceClick(input1, input1Ref)}
                />
                <TextInput
                    ref={input2Ref}
                    value={input2}
                    onChangeText={setInput2}
                    style={styles.input}
                    maxLength={1}
                    keyboardType="number-pad"
                    onKeyPress={onBackspaceClick(input2, input1Ref)}
                />
                <TextInput
                    ref={input3Ref}
                    value={input3}
                    onChangeText={setInput3}
                    style={styles.input}
                    maxLength={1}
                    keyboardType="number-pad"
                    onKeyPress={onBackspaceClick(input3, input2Ref)}
                />
                <TextInput
                    ref={input4Ref}
                    value={input4}
                    onChangeText={setInput4}
                    style={styles.input}
                    maxLength={1}
                    keyboardType="number-pad"
                    textContentType="oneTimeCode"
                    onKeyPress={onBackspaceClick(input4, input3Ref)}
                />
            </View>
            <ErrorBox/>
        </View>
    );
};

export default OTPInput;

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        marginVertical: 10
    },
    input: {
        marginHorizontal: 10,
        height: 45,
        width: 45,
        backgroundColor: colors.inputBgColor,
        padding: 5,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 8,
        fontFamily: fonts.medium,
        color: colors.Orange,
        textAlign: 'center',
        fontSize: 28,
        textAlignVertical: 'center',
    },
});
