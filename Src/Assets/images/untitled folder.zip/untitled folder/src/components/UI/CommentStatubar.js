import { StyleSheet, Text, View, StatusBar } from 'react-native'
import React from 'react'

const CommentStatubar = () => {
    return (
        <View style={styles.myStatusBar}>
            <StatusBar barStyle = "dark-content" translucent={true} backgroundColor='transparent' />
        </View>
    )
}

export default CommentStatubar

const styles = StyleSheet.create({
    myStatusBar:{
    },
})