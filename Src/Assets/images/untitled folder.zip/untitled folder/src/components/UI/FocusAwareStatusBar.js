import * as React from 'react';
import {
  Platform,
  SafeAreaView,
  StatusBar,
  StyleSheet,
  View,
} from 'react-native';
import { useIsFocused } from '@react-navigation/native';
// import { print } from '../../Constants';

export const FocusAwareStatusBar = React.memo(({ backgroundColor, ...props }) => {
  const isFocused = useIsFocused();
  // print('FocusAwareStatusBar')
  return (
    Platform.OS === 'ios' ? isFocused && <View style={[styles.statusBar, { backgroundColor }]}>
      <SafeAreaView>
        <StatusBar animated={true} barStyle={'light-content'} backgroundColor={backgroundColor} {...props} />
      </SafeAreaView>
    </View>
      : isFocused ? <StatusBar barStyle={'light-content'} backgroundColor={backgroundColor} {...props} /> : null
  );
})
const STATUSBAR_HEIGHT = StatusBar.currentHeight;
const styles = StyleSheet.create({
  statusBar: {
    height: STATUSBAR_HEIGHT,
  },
});
