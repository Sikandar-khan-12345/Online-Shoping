import {StyleSheet, Text, View, Image} from 'react-native';
import React from 'react';
import Icons from '../../Constants/Icons';
import {FULL_HEIGHT} from '../../Constants/layout';
const TopBanner = ({Topbanner}) => {
  return (
    <View style={styles.topImg}>
      <Image resizeMode="cover" style={styles.Img} source={Topbanner} />
    </View>
  );
};

export default TopBanner;

const styles = StyleSheet.create({
  topImg: {},
  Img: {
    width: '100%',
    height: FULL_HEIGHT / 3,
  },
});
