import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    Image,
    Modal,
} from 'react-native';
import React, { useState } from 'react';
import Animated, { BounceInLeft, BounceOutRight } from 'react-native-reanimated';
import fonts from '../../Constants/fonts';
import { launchCamera, launchImageLibrary } from 'react-native-image-picker';
import ImagePicker, { ImageOrVideo } from 'react-native-image-crop-picker';
import colors from '../../Constants/colors';
import Icons from '../../Constants/Icons';
import Icon from './Icon';
import { print } from '../../Constants';
import { SimpleToaster } from '../../Backend/Backend';
import {
    check,
    request,
    PERMISSIONS,
    RESULTS,
    openSettings,
} from 'react-native-permissions';
import SimpleToast from 'react-native-simple-toast';
import { STANDARD_WIDTH } from '../../Constants/layout';

export const requestPermission = async (permissionFor) => {
    try {
        let permission = '';
        if (permissionFor == 'storage') {
            permission = await request(Platform.OS == 'ios' ? PERMISSIONS.IOS.PHOTO_LIBRARY : PERMISSIONS.ANDROID.READ_EXTERNAL_STORAGE);
        } else {
            permission = await request(Platform.OS == 'ios' ? PERMISSIONS.IOS.CAMERA : PERMISSIONS.ANDROID.CAMERA);
        }

        if (permission == 'granted') {
            return true;
        } else {
            SimpleToast.show('Please Enable Permissions from Settings');
            return false;
        }
    } catch (err) {
        print(err)
    }

}
const SelectionModal = ({ showModal, close = () => { }, selected = () => { } }) => {
    const [check, setCheck] = React.useState(1);
    const checkBox = e => {
        setCheck(e);
        selected(e);
    };

    // const [modalVisible, setModalVisible] = useState(false)



    return (
        <Modal
            onRequestClose={() => close()}
            transparent={true}
            style={{ height: '100%' }}
            visible={showModal}
            animationType="fade"
            statusBarTranslucent
            presentationStyle="overFullScreen">
            <View style={styles.modalContainer}>
                <TouchableOpacity
                    style={{ height: '50%', width: '100%', backgroundColor: 'transparent' }}
                    onPress={() => close()}
                />
                <Animated.View style={styles.bottomModal} entering={BounceInLeft}>
                    <View style={styles.modalShowSection}>
                        <TouchableOpacity
                            style={{ alignSelf: 'flex-end', margin: 10 }}
                            onPress={() => close()}>
                            <Icon
                                source={Icons.close}
                                tintColor={colors.white}
                                size={17}
                            />
                        </TouchableOpacity>
                        <View style={styles.modalView}>
                            <TouchableOpacity
                                style={styles.checkView}
                                onPress={async () => {
                                    const granted = await requestPermission();
                                    if (granted) {
                                        // launchCamera({
                                        //     mediaType: "photo", quality: 0.9
                                        // }, (res) => {
                                        //     print(res)
                                        //     if (!res.didCancel) {
                                        //         if (!res.errorCode) {
                                        //             if (res.assets) {
                                        //                 selected(res?.assets[0])
                                        //             }
                                        //         } else {
                                        //             SimpleToaster(res.errorCode)
                                        //         }
                                        //         // setImag(res.assets[0].uri)

                                        //         // setModalVisible(false)

                                        //     } else {



                                        //     }

                                        // })
                                        ImagePicker.openCamera({
                                            width: STANDARD_WIDTH - 50,
                                            height: STANDARD_WIDTH - 50,
                                            cropping: true,
                                        }).then(res => {
                                            print(res)
                                            selected(res)
                                        }
                                        ).catch((err) => {
                                            print(err)
                                        });
                                    }
                                }} >
                                <Image style={{ height: 50, width: 50, tintColor: 'white' }}
                                    source={require('../../../Assets/images/camera.png')} />
                                <Text style={styles.modalText}>Open Camera</Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                style={styles.checkView}
                                onPress={() => {
                                    ImagePicker.openPicker({
                                        width: STANDARD_WIDTH - 50,
                                        height: STANDARD_WIDTH - 50,
                                        cropping: true,
                                    }).then(res => {
                                        print(res)
                                        selected(res)
                                    }
                                    ).catch((err) => {
                                        print(err)
                                    })
                                    // launchImageLibrary({
                                    //     mediaType: "photo", quality: 0.9,


                                    // }, (res) => {
                                    //     print('ssss', res)
                                    //     if (!res.didCancel) {


                                    //         selected(res?.assets[0])

                                    //         // setModalVisible(false)

                                    //     } else {



                                    //     }

                                    // })
                                }}  >
                                <Image style={{ height: 50, width: 50, tintColor: "white" }} source={require('../../../Assets/images/gallery.png')} />
                                <Text style={styles.modalText}>Open Library</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </Animated.View>
            </View>
        </Modal>
    );
};

export const SignModal = ({
    showModal,
    close = () => { },
    selected = () => { },
}) => {
    const [check, setCheck] = React.useState(1);
    const checkBox = e => {
        setCheck(e);
        selected(e);
    };

    return (
        <Modal
            onRequestClose={() => close()}
            transparent={true}
            style={{ height: '100%' }}
            visible={showModal}
            animationType="fade"
            presentationStyle="overFullScreen">
            <View style={styles.modalContainer}>
                <TouchableOpacity
                    style={{ height: '50%', width: '100%', backgroundColor: 'transparent' }}
                    onPress={() => close()}
                />
                <Animated.View style={styles.bottomModal} entering={BounceInLeft}>
                    <View style={styles.modalShowSection}>
                        <TouchableOpacity
                            style={{ alignSelf: 'flex-end', margin: 10 }}
                            onPress={() => close()}>
                            <Image
                                source={Icons.closeImage}
                                style={{ height: 10, width: 10, tintColor: colors.ba }}
                                resizeMode={'contain'}
                            />
                        </TouchableOpacity>
                        <View style={styles.modalView}>
                            <TouchableOpacity
                                style={styles.checkView}
                                onPress={() => checkBox('image')}>
                                <Image
                                    style={{ height: 50, width: 50 }}
                                    source={Icons.cameraIcon}
                                />
                                <Text style={styles.modalText}>Choose Image</Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                style={styles.checkView}
                                onPress={() => checkBox('sign')}>
                                <Image
                                    style={{ height: 50, width: 50 }}
                                    source={Icons.signatureIcon}
                                />

                                <Text style={styles.modalText}>Signature</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </Animated.View>
            </View>
        </Modal>
    );
};

const styles = StyleSheet.create({
    modalContainer: {
        flex: 1,
        backgroundColor: '#000000ab',
        justifyContent: 'flex-end',
        alignItems: 'center',
    },

    bottomModal: {
        height: '50%',
        width: '100%',
        backgroundColor: 'transparent',
        justifyContent: 'center',
        alignItems: 'center',
    },
    modalView: {
        width: '100%',
        paddingBottom: 30,
        backgroundColor: colors.inputBgColor,
        flexDirection: 'row',
        flexWrap: 'wrap',
        justifyContent: 'space-around',
        paddingHorizontal: 10,
        borderRadius: 10,
        alignItems: 'center',
    },
    modalShowSection: {
        width: '90%',
        //paddingVertical: 30,
        backgroundColor: colors.inputBgColor,
        //flexDirection: "row",
        //flexWrap: "wrap",
        //justifyContent: "space-around",
        ///paddingHorizontal: 10,
        borderRadius: 10,
        //alignItems: "center",
    },
    checkView: {
        width: '45%',
        paddingVertical: 10,
        alignItems: 'center',
    },
    modalText: {
        fontSize: 16,
        fontFamily: fonts.medium,
        color: colors.Orange,
        marginTop: 10
    },
    check: {
        height: 16,
        width: 16,
        borderRadius: 15,
        backgroundColor: colors.backgroundLight,
        borderWidth: 2,
        borderColor: colors.dullWhite,
        marginRight: 15,
    },
});

export default SelectionModal;
