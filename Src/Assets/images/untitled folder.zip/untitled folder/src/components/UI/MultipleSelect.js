import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    Image,
    Modal,
    FlatList,
} from 'react-native';
import React, { useState } from 'react';
import Animated, {
    BounceInLeft,
    BounceOutRight,
    FadeInUp,
    FlipOutEasyY,
    FlipOutEasyX,
    FlipInEasyY,
} from 'react-native-reanimated';
import colors from '../../Constants/colors';


import Typography from './Typography';
import Press from '../HOC/Press';
import Icon from './Icon';
import { FULL_HEIGHT, STANDARD_WIDTH } from '../../Constants/layout';
import CommonButton from './CommonButton';
import Icons from '../../Constants/Icons';
import { print } from '../../Constants';
import { LangStrings } from '../../Languages/langStrings';

const SelectionMultiModel = ({
    detail,
    showModal,
    close = () => { },
    selected = () => { },
}) => {
    const [Visibility, setVisibility] = useState();
    const [data, setData] = useState(detail?.arr);
    const [selectedValue, setSelectedValue] = useState(detail?.selectedArr);

    const onPress = value => {
        var selectedNewArr = [...selectedValue];
        var filterArr = selectedNewArr.filter(item => {
            print(item.label, '=========', value.label);

            return item.label == value.label;
        });

        if (filterArr.length > 0) {
            let index = selectedNewArr
                .map(item => {
                    return item?.label;
                })
                .indexOf(value.label);
            selectedNewArr.splice(index, 1);
        } else {
            selectedNewArr.push(value);
        }

        setSelectedValue(selectedNewArr);
    };

    const isSelected = value => {
        var filterArr = selectedValue.filter(item => {
            return item.label == value.label;
        });
        if (filterArr.length > 0) {
            return true;
        } else {
            return false;
        }
    };

    return (
        <Modal
            statusBarTranslucent
            onRequestClose={() => close()}
            transparent={true}
            style={{ height: '100%' }}
            visible={showModal}
            animationType="fade"
            presentationStyle="overFullScreen">
            <View style={styles.modalContainer}>
                <Animated.View style={styles.bottomModal} entering={FlipInEasyY}>
                    <View style={styles.modalShowSection}>
                        <View
                            style={{
                                flexDirection: 'row',
                                justifyContent: 'space-between',
                                width: '100%',
                                backgroundColor: colors.Orange,
                                height: 50,
                                width: STANDARD_WIDTH - 20,
                                alignItems: 'center',
                                borderTopEndRadius: 5,
                                borderTopStartRadius: 5,
                                alignSelf: 'center',
                            }}>
                            <View style={{}}></View>
                            <Typography
                                size={18}
                                type='medium'
                                style={{ color: 'white', flex: 1 }}
                                textAlign="center">
                                {detail?.title}
                            </Typography>

                            <Press
                                style={{
                                    tintColor: 'grey',
                                    width: 20,
                                    height: 20,
                                    backgroundColor: 'white',
                                    borderRadius: 10,
                                    marginRight: 15,
                                }}
                                onPress={() => close()}
                                scaleSize={0.8}>
                                <Image
                                    source={Icons.close}
                                    style={{
                                        height: 10,
                                        width: 10,
                                        alignSelf: 'center',
                                        marginTop: 5,
                                    }}
                                    resizeMode={'contain'}
                                />
                            </Press>
                        </View>
                        <View style={styles.modalView}>
                            <FlatList
                                data={data}
                                showsVerticalScrollIndicator={false}
                                renderItem={({ item, index }) => (
                                    <View style={{ marginTop: 30 }}>
                                        <Press onPress={() => onPress(item)}>
                                            <View
                                                style={{
                                                    flexDirection: 'row',
                                                    justifyContent: 'space-between',
                                                    paddingHorizontal: 20,
                                                }}>
                                                <Typography color={colors.white} type='medium' style={{}}>{item.label}</Typography>
                                                <Icon
                                                    source={
                                                        Icons.check
                                                    }
                                                    tintColor={isSelected(item) ? colors.Orange : "grey"}
                                                    size={15}
                                                    imgStyle={{ marginTop: 5 }}
                                                />
                                            </View>
                                            <View
                                                style={{
                                                    borderBottomColor: 'grey',
                                                    borderBottomWidth: 0.5,
                                                    width: '95%',
                                                    alignSelf: 'center',
                                                    marginTop: 15,
                                                }}></View>
                                        </Press>
                                    </View>
                                )}
                            />
                        </View>
                        <CommonButton
                            text={LangStrings.addStaff.save}
                            style={{
                                borderRadius: 0,
                                marginBottom: 0,
                                borderBottomEndRadius: 5,
                                borderBottomStartRadius: 5,
                                width: STANDARD_WIDTH - 20,
                            }}
                            onPress={() => {
                                selected(selectedValue, detail?.title);
                            }}
                        />
                    </View>
                </Animated.View>
            </View>
        </Modal>
    );
};

const styles = StyleSheet.create({
    modalContainer: {
        flex: 1,
        backgroundColor: '#000000ab',
        justifyContent: 'center',
        alignItems: 'center',
    },
    bottomModal: {
        height: '80%',
        width: '100%',
        backgroundColor: 'transparent',
        justifyContent: 'center',
        alignItems: 'center',
    },
    modalView: {
        width: '100%',
        height: FULL_HEIGHT - 250,
        backgroundColor: 'transparent',
        flexDirection: 'row',
        justifyContent: 'space-around',
        paddingHorizontal: 10,
        // borderRadius: 10,
        width: STANDARD_WIDTH - 20,
        alignSelf: 'center',
    },
    modalShowSection: {
        width: STANDARD_WIDTH - 20,
        //paddingVertical: 30,
        backgroundColor: colors.inputBgColor,
        //flexDirection: "row",
        //flexWrap: "wrap",
        //justifyContent: "space-around",
        ///paddingHorizontal: 10,
        borderRadius: 10,
        //alignItems: "center",
    },
});

export default SelectionMultiModel;