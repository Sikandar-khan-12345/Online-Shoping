import { Modal, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import React, { memo, useEffect, useState } from 'react';
import Press from '../HOC/Press';
import Icon from './Icon';
import colors from '../../Constants/colors';
import Typography from './Typography';
import Container from '../HOC/Container';
import { print } from '../../Constants';

const MoreItems = ({ items = [], alignDots = 'flex-start', visible = false, onPress = () => { }, onClose = () => { } }) => {
  const [isListVisible, setisListVisible] = useState(false);
  print('MoreItems')
  return (
    <View>
      <TouchableOpacity
        style={{
          width: 40,
          height: 40,
          justifyContent: 'center',
          alignItems: alignDots,
        }}
        onPress={() => onPress()}>
        <Icon
          size={16}
          tintColor={colors.Orange}
          source={require('../../../Assets/images/more.png')}
        />
      </TouchableOpacity>
      <Modal
        backdropTransitionOutTiming={0}
        hideModalContentWhileAnimating
        statusBarTranslucent
        visible={visible}
        transparent={true}
        animationType="slide">
        <View
          style={{
            justifyContent: 'flex-end',
            flex: 1,
            backgroundColor: '#00000099',
            paddingHorizontal: 10,
            paddingBottom: 8,
          }}>
          {items.map((item, i) => (
            <View key={i}>
              <Press
                onPress={item?.action}
                style={{
                  height: 45,
                  justifyContent: 'center',
                  backgroundColor: colors.inputBgColor,
                  marginVertical: 5,
                  borderRadius: 8,
                  elevation: 10,
                }}>
                <Typography color={colors.white} textAlign="center" type="bold">
                  {item?.title}
                </Typography>
              </Press>
            </View>
          ))}
          <Press
            onPress={() => onClose(false)}
            style={{
              height: 55,
              justifyContent: 'center',
              backgroundColor: colors.black,
              marginVertical: 5,
              borderRadius: 8,
              elevation: 5,
              borderWidth: 1,
              borderColor: colors.Orange,
            }}>
            <Typography color={colors.Orange} textAlign="center" type="bold">
              Cancel
            </Typography>
          </Press>
        </View>
      </Modal>
    </View>
  );
};

export default MoreItems;

const styles = StyleSheet.create({});
