import { TouchableOpacity, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import colors from '../../Constants/colors'
const CustomButton = ({
    buttonStyle,
    title,
    btnopacity,
    txtStyle,
    PressAction=()=>{},
}) => {
  return (
    <TouchableOpacity
            onPress={PressAction}
            style={[
                buttonStyle,{
                backgroundColor: colors.black,
                borderRadius: 50,
                height: 60,
                justifyContent: 'center',
                alignItems: 'center',
                borderWidth:2,
                borderColor:colors.lightRed,
                marginBottom:10,
            }]}
            activeOpacity={btnopacity}>

            <Text 
            style={[
                txtStyle, {
                color: colors.lightRed,
                // fontFamily: Fonts.bold,
                fontSize: 15,
            }]}>
                {title}
            </Text>
        </TouchableOpacity>
  )
}

export default CustomButton

const styles = StyleSheet.create({})