import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import QRCode from 'react-native-qrcode-svg'

const QRGenerator = ({
    value,
    logo,
    logoSize,
    logoBackgroundColor = 'transparent',
    getRef,
    color,
    size,
    onError = () => { },
    logoBorderRadius
}) => {
    return (
        <QRCode
            onError={onError}
            size={size}
            color={color}
            value={value}
            logo={logo}
            logoSize={logoSize}
            logoBorderRadius={logoBorderRadius}
            logoBackgroundColor={logoBackgroundColor}
            getRef={getRef}
        />
    )
}

export default QRGenerator