import { FlatList, Image, Modal, Platform, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native'
import React, { memo, useCallback, useEffect, useState } from 'react'
import colors from '../../Constants/colors'
import Typography from './Typography'
import Icon from './Icon'
import Icons from '../../Constants/Icons'
import FormContainer from '../HOC/FormContainer'
import Devider from './Devider'
import { print } from '../../Constants'
import { FocusAwareStatusBar } from './FocusAwareStatusBar'

const SheetModal = ({
    visible = false,
    onClose = () => { },
    sheetData = [],
    onSelect = () => { }
}) => {
    print('sheetModal')
    const selectItem = (name, id, image) => {
        print("🚀 ~ file: SheetModal.js ~ lixxxxxxxxxxxxxxxne 19 ~ selectItem ~ name, id", name, id, image)
        onSelect(name, id, image)
        onClose()
    }
    const _renderItem = useCallback(
        ({ item, index }) => {
            return <SheetItem item={item} index={index} onSelection={selectItem} />
        },
        [],
    )
    const [data, setData] = useState(sheetData)
    useEffect(() => {
        setData(sheetData)
    }, [sheetData])

    return (
        <Modal
            visible={visible}
            animationType={'slide'}
        >
            <FocusAwareStatusBar
                translucent={Platform.OS == 'android'}
                backgroundColor={colors.bgcolor}
            />
            <FormContainer>
                <View style={styles.inputContainer}>
                    <Icon
                        source={Icons.search}
                        size={20}
                        tintColor={colors.white}
                    />
                    <View style={{
                        flex: 1
                    }}>
                        <TextInput
                            onChangeText={(e) => {
                                let searchQuery = e;
                                if (sheetData.length > 0) {
                                    if (searchQuery) {
                                        const regex = new RegExp(searchQuery, 'i');
                                        const blockedListFilters = sheetData.filter((arr) =>
                                            arr?.name.match(regex),
                                        );
                                        setData(blockedListFilters);
                                    } else {
                                        setData(sheetData)
                                    }
                                }
                            }}
                            placeholder='Search...'
                            placeholderTextColor={colors.placeTextColor}
                            style={{ padding: 0, marginHorizontal: 10, color: colors.white }}
                        />
                    </View>
                    <Icon
                        size={18}
                        source={Icons.close}
                        tintColor={colors.white}
                        touchable
                        onPress={onClose}
                    />
                </View>
                <ScrollView>
                    <FlatList
                        data={data}
                        renderItem={_renderItem}
                        contentContainerStyle={{ paddingTop: 15 }}
                        ItemSeparatorComponent={() => <Devider height={0.5} color={'black'} />}
                    />
                </ScrollView>
            </FormContainer>
        </Modal>
    )
}

export default memo(SheetModal)

const SheetItem = memo(({ item, index, onSelection }) => {
    return (
        <TouchableOpacity activeOpacity={0.8} key={index} onPress={() => onSelection(item?.name, item?.id, item?.image_url)} style={styles.sheetItem}>
            <Image
                style={{ width: 55, height: 55, borderRadius: 35, marginRight: 10 }}
                source={{ uri: item?.image_url }}
            />
            <Typography color={colors.white} type='medium'>{item?.name}</Typography>
        </TouchableOpacity>
    )
})

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.bgcolor
    },
    inputContainer: {
        flexDirection: 'row',
        padding: 10,
        alignItems: 'center',
        borderBottomColor: 'ghostwhite',
        borderBottomWidth: 0.5
    },
    sheetItem: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 10,
        paddingVertical: 5
    }
})