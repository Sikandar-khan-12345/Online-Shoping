import { StyleSheet, ActivityIndicator } from 'react-native';
import React from 'react';
import Press from '../HOC/Press';
import Typography from './Typography';
import colors from '../../Constants/colors';
import { SPACING, STANDARD_WIDTH } from '../../Constants/layout';
import globalStyle from '../../Constants/globalStyle';
import { renderIf } from '../../Constants/functions';
import fonts from '../../Constants/fonts';

const CommonButton = ({
  text = 'Press Me',
  onPress = () => { },
  loading = false,
  disable = false,
  backgroundColor = colors.black,
  style = {},
  halfButton = false,
  fullButton = false,
  textColor = colors.lightRed,
}) => {
  const buttonDisable = disable || loading;
  const buttonStyle = [
    globalStyle.button,
    styles.button,
    halfButton ? styles.halfButton : {},
    fullButton ? styles.halfButton : {},
    { backgroundColor },
    style,
  ];
  return (
    <Press onPress={onPress} disable={buttonDisable} style={buttonStyle}>
      {renderIf(
        text,
        loading ? (
          <ActivityIndicator color={textColor} size="small" />
        ) : (
          <Typography style={{
            fontFamily: fonts.medium
          }} color={textColor}>{text}</Typography>

        ),
      )}
    </Press>
  );
};

export default CommonButton;

const styles = StyleSheet.create({
  button: {
    paddingVertical: SPACING - 3,
    paddingHorizontal: 43 / 2,
    justifyContent: "center",
    borderRadius: 50,
    borderWidth: 2,
    borderColor: colors.lightRed,
    height: 60,
    marginBottom: 5,
  },
  fullButton: {
    width: '100%',
  },
  halfButton: {
    width: '50%',
  },
});
