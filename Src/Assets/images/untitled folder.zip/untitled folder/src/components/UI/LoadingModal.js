import { ActivityIndicator, Modal, StyleSheet, Text, View } from 'react-native';
import React, { memo } from 'react';
import { FULL_WIDTH } from '../../Constants/layout';
import { print } from '../../Constants';
import colors from '../../../utils/colors';

const LoadingModal = ({
  visible = false,
  onClose = () => { },
  animationType = 'fade',
  transparent = true,
  loaderanimating,
  loaderSize = 'large',
  loaderColor = colors.primary,
  loaderStyle,
}) => {
  print('LoadingModal')

  return (
    <Modal
      statusBarTranslucent
      animationType={animationType}
      transparent={transparent}
      visible={visible}
      onRequestClose={() => {
        onClose();
      }}>
      <View
        style={{
          flex: 1,
          justifyContent: 'center',
          alignItems: 'center',
          backgroundColor: '#00000099',
        }}>
        <View
          style={{
            width: FULL_WIDTH * 0.25,
            height: FULL_WIDTH * 0.25,
            borderRadius: 10,
            backgroundColor: colors.white,
            elevation: 10,
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <ActivityIndicator
            animating={loaderanimating}
            size={loaderSize}
            color={loaderColor}
            style={loaderStyle}
          />
        </View>
      </View>
    </Modal>
  );
};

export default memo(LoadingModal);

const styles = StyleSheet.create({});
