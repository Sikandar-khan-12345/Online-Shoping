import React, { memo } from 'react'
import { ImageBackground, StyleSheet, View } from 'react-native'
import { CURRENCY } from '../../Constants'
import colors from '../../Constants/colors'
import Icons from '../../Constants/Icons'
import { STANDARD_WIDTH } from '../../Constants/layout'
import Press from '../HOC/Press'
import Icon from './Icon'
import Typography from './Typography'
import moment from 'moment'
import { useNavigation } from '@react-navigation/native';

const TicketCard = props => {
    const { item = {} } = props;
    const {
        event_name = '',
        start_date = '',
        end_date = '',
        city = '',
        state = '',
        zip_code = '',
        country = '',
        total_price = 0,
        price = 0,
        quantity = 1,
        image_url = '',
        id,
    } = item;
    const navigation = useNavigation()
    const image = image_url ? { uri: image_url } : require('../../../Assets/images/profile.png');

    return (
        <Press onPress={() => navigation.navigate('Ticket', { id })}>
            <ImageBackground style={styles.ticketCard} source={Icons.ticketBg1} imageStyle={{ width: STANDARD_WIDTH }} resizeMethod='auto' resizeMode='stretch'>
                <View style={styles.row(7)}>
                    <Icon marginRight={10} size={50} source={image} />
                    <View>
                        <Typography type='bold' color={colors.golden}>
                            {event_name}
                        </Typography>
                        <View style={styles.row(3)}>
                            <Icon size={14} marginRight={5} source={Icons.calendar} tintColor={colors.Orange} />
                            <Typography type='0' size={13} color={colors.white}>
                                {moment(start_date).format('ddd, DD MMM YYYY, hh:mm A')}
                            </Typography>
                        </View>
                        <View style={styles.row(3)}>
                            <Icon size={14} marginRight={5} source={require('../../../Assets/images/location.png')} />
                            <Typography type='0' size={13} color={colors.white}>
                                {/* {moment(end_date).format('ddd, DD MMM YYYY, hh:mm A')} */}
                                {`${city}, ${state}, ${zip_code}, ${country}`}
                            </Typography>
                        </View>
                    </View>
                </View>

                <View style={styles.row(7)}>
                    <View style={styles.ticketTooterTab}>
                        <Typography type='bold' style={{ marginBottom: 3 }} color={colors.golden} size={11}>
                            Ticket Price
                        </Typography>
                        <Typography type='0' color={colors.white} size={11}>
                            {CURRENCY} {price}
                        </Typography>
                    </View>

                    <View style={[styles.ticketTooterTab, { borderLeftWidth: 1, borderLeftColor: colors.golden, paddingLeft: 10 }]}>
                        <Typography type='bold' style={{ marginBottom: 3 }} color={colors.golden} size={11}>
                            Total Price
                        </Typography>
                        <Typography type='0' color={colors.white} size={11}>
                            {CURRENCY} {total_price}
                        </Typography>
                    </View>

                    <View style={[styles.ticketTooterTab, { borderLeftWidth: 1, borderLeftColor: colors.golden, paddingLeft: 10 }]}>
                        <Typography type='bold' style={{ marginBottom: 3 }} color={colors.golden} size={11}>
                            No. of Ticket
                        </Typography>
                        <Typography type='0' color={colors.white} size={11}>
                            {quantity}
                        </Typography>
                    </View>
                </View>
            </ImageBackground>
        </Press>
    )
}

export default memo(TicketCard)

const styles = StyleSheet.create({
    ticketCard: {
        width: '100%',
        padding: 10,
        backgroundColor: colors.inputBgColor,
        marginVertical: 7,
        paddingHorizontal: 15,

    },
    row: (margin) => {
        return {
            flexDirection: 'row',
            marginVertical: margin
        }

    },
    ticketTooterTab: {
        flex: 1,
    },
    line: {
        borderStyle: 'dashed',
        width: '100%',
        borderTopWidth: 1,
        borderTopColor: colors.golden
    }
})