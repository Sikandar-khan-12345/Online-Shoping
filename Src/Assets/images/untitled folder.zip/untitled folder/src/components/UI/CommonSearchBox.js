import { StyleSheet, Text, View, Image } from 'react-native'
import React from 'react'
// import { GooglePlacesAutocomplete } from 'react-native-google-places-autocomplete';
import colors from '../../Constants/colors';
import Typography from './Typography';
import Icons from '../../Constants/Icons';
const CommonSearchBox = () => {
    return (
        <>
            <Typography size={13} color={colors.lightRed} type="bold" style={{ marginBottom: 3, }} > LOCATION </Typography>
            <View style={styles.searchBox} >
                <Image style={styles.searchIcon} source={Icons.search} />

                {/* <GooglePlacesAutocomplete
                    placeholder='Search'
                    placeTextColor="white"
                    onPress={(data, details = null) => {
                        print(data, details);
                    }}
                    query={{
                        key: 'AIzaSyCsXuVvJxS2YgluB3CSG0DW8hwSOm_cFuI',
                        language: 'en',
                    }}
                    styles={{
                        textInputContainer: {
                            backgroundColor: colors.inputBgColor,
                            borderRadius: 10,
                            height: 56,
                            alignItems: "center",
                            // color: colors.white,
                        },
                        textInput: {
                            color: colors.white,
                            fontSize: 15,
                            backgroundColor: "transparent",
                            marginLeft: 30
                        },
                        placeholdertext: { color: colors.white },
                        row: {
                            backgroundColor: colors.inputBgColor,
                        },
                        description: {
                            color: colors.white,
                        },
                        placeholder:{
                            color:colors.white
                        }

                    }}
                /> */}
            </View>
        </>
    )
}

export default CommonSearchBox

const styles = StyleSheet.create({
    searchBox: {
        backgroundColor: colors.inputBgColor,
        borderRadius: 10,
        position: "relative",
    },
    searchIcon: {
        width: 20,
        height: 20,
        tintColor: colors.placeTextColor,
        position: "absolute",
        bottom: 20,
        zIndex: 9,
        left: 11,
    }
})