import { StyleSheet, Text, View, Image, TouchableOpacity, TextInput } from 'react-native'
import React, { useState } from 'react'
import colors from '../../Constants/colors'
import fonts from '../../Constants/fonts'
import Icons from '../../Constants/Icons'
import Reanimated, { FadeIn, FadeInLeft, FadeInRight, FadeOut } from 'react-native-reanimated';
import Typography from './Typography'


const CommenFileUpload = ({
    title,
    fileName,
    error,
}) => {
    return (

        <View style={{ width: "100%", marginLeft: 5, flex: 1 }} >
            <Typography size={12} color={colors.lightRed} style={styles.label} type='medium' > 
            {title} 
            </Typography>
            <View style={styles.uploadeInputBox}>
                <TouchableOpacity style={styles.ImgBox}>
                    <Image style={styles.uploadeIcon} source={Icons.uploade} />
                </TouchableOpacity>
                <View>
                    <Typography size={13} color={colors.white} type="bold" >{fileName} </Typography>
                </View>
            </View>
            {!!error && <ErrorBox error={error} />}
        </View>
    )
}


export const ErrorBox = ({ error }) => {
    return (
        <Reanimated.Text
            entering={FadeInRight}
            exiting={FadeOut}
            numberOfLines={1}
            adjustsFontSizeToFit
            style={{
                fontSize: 10,
                // fontFamily: font.regular,
                color: colors.red,
                marginVertical: 5,
                textAlign: 'right',
                alignSelf: 'flex-end'
            }}>
            {error}
        </Reanimated.Text>
    )
}


export default CommenFileUpload
const styles = StyleSheet.create({
    label: {
        marginBottom: 3,
        fontFamily: fonts.bold,
    },
    uploadeInputBox: {
        backgroundColor: colors.inputBgColor,
        flexDirection: "row",
        alignItems: "center",
        height: 55,
        borderRadius: 10,
    },
    ImgBox: {
        borderWidth: 1,
        borderColor: colors.lightRed,
        width: 40,
        height: 40,
        justifyContent: "center",
        alignItems: "center",
        borderRadius: 10,
        marginHorizontal: 10,
    },
    uploadeIcon: {
        width: 20,
        height: 20,
        tintColor: colors.lightRed,

    }

})