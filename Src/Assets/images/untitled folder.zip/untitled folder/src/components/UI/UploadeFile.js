import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  Image,
  TouchableOpacity,
} from 'react-native';
import React, { memo, useState } from 'react';
import colors from '../../Constants/colors';
import Icons from '../../Constants/Icons';
import fonts from '../../Constants/fonts';

import { launchCamera, launchImageLibrary } from 'react-native-image-picker';
import Card from './Card';
import { print } from '../../Constants';
import { ErrorBox } from './CommenRNPickerSelect';
import { FULL_HEIGHT } from '../../Constants/layout';
import SelectionModal from './SelectionModal';
import Typography from './Typography';
import { LangStrings } from '../../Languages/langStrings';
const UploadeFile = ({
  boxRow,
  type,
  containerHeight,
  boxImg = {
    width: '100%',
    height: FULL_HEIGHT / 4,
    borderRadius: 10,
  },
  ImgBox = {
    backgroundColor: colors.inputBgColor,
    padding: 11,
    borderRadius: 10,
    elevation: 0.7,
  },
  uploadeTxt = {
    color: colors.white,
    fontWeight: '500',
    fontSize: 13,
  },
  uploadeTxtName,
  onChange = () => { },
  img,
  error,
  label = 'UPLOAD IMAGE'
}) => {
  print('uploadFile');
  const [filePath, setFilePath] = useState('');
  const [modal, setModal] = useState(false);
  const requestCameraPermission = async () => {
    if (Platform.OS === 'android') {
      try {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.CAMERA,
          {
            title: 'Camera Permission',
            message: 'App needs camera permission',
          },
        );
        // If CAMERA Permission is granted
        return granted === PermissionsAndroid.RESULTS.GRANTED;
      } catch (err) {
        print(err);
        return false;
      }
    } else return true;
  };

  const requestExternalWritePermission = async () => {
    if (Platform.OS === 'android') {
      try {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
          {
            title: 'External Storage Write Permission',
            message: 'App needs write permission',
          },
        );
        // If WRITE_EXTERNAL_STORAGE Permission is granted
        return granted === PermissionsAndroid.RESULTS.GRANTED;
      } catch (err) {
        print(err);
        alert('Write permission err', err);
      }
      return false;
    } else return true;
  };

  const captureImage = async type => {
    let options = {
      mediaType: type,
      maxWidth: 300,
      maxHeight: 550,
      quality: 1,
      videoQuality: 'low',
      durationLimit: 30,
      saveToPhotos: true,
    };

    let isCameraPermitted = await requestCameraPermission();
    let isStoragePermitted = await requestExternalWritePermission();
    if (isCameraPermitted && isStoragePermitted) {
      launchCamera(options, response => {
        //print('Response = ', response.assets);
        var image = response.assets[0];
        setFilePath(image.uri);
        onChange(image);
      });
    }
  };

  const chooseFile = type => {
    let options = {
      mediaType: type,
      maxWidth: 300,
      maxHeight: 550,
      quality: 1,
    };

    launchImageLibrary(options, response => {
      //print('Response = ', response);
      if (response?.didCancel) {
      } else {
        let image = response.assets[0];
        print('imgggg--->', image);
        setFilePath(image?.uri);
        onChange(image);
      }
    }).catch(err => {
      //print(err);
    });
  };

  return (
    <Card style={{ height: containerHeight }}>
      <View>
        <Typography color={colors.Orange} type='medium' size={20}>{label}</Typography>

        <Typography color={colors.white} type='medium' size={14}>{LangStrings.Uploade_File.ChooseYourImageToUpload}</Typography>
      </View>

      <View style={type == 'small' && {
        flexDirection: 'row',
        alignItems: 'center',
      }}>
        <TouchableOpacity
          // onPress={() => print(filePath)}
          onPress={() => setModal(true)}
          style={styles.uploadeBox}>
          <Image style={styles.uploadeIcon} source={Icons.uploade} />
          <Text style={type == 'small' ? {
            width: 115,
            height: 0,
            justifyContent: 'center',
            alignItems: 'center',
          } : uploadeTxt}> {uploadeTxtName} </Text>
        </TouchableOpacity>
        <View style={type == 'small' && { marginLeft: 15 }}>
          {(filePath || img) ? <Image
            resizeMode="cover"
            style={[type == 'small' ? { width: 115, height: 100, borderRadius: 10 } : boxImg]}
            source={{ uri: filePath ? filePath : img }}
          /> : null}
        </View>
      </View>
      <SelectionModal
        showModal={modal}
        close={() => {
          setModal(false);
        }}
        selected={v => {
          setFilePath(v?.path);
          print('path===============>', v);
          onChange(v);
          setModal(false)
        }}
      />
      {!!error && <ErrorBox error={error} />}
    </Card>
  );
};

export default memo(UploadeFile);

const styles = StyleSheet.create({
  heading: {
    color: colors.lightRed,
    fontFamily: fonts.bold,
    fontSize: 15,
  },
  title: {
    color: colors.white,
    fontWeight: '500',
    fontSize: 15,
  },
  uploadeBox: {
    borderStyle: 'dashed',
    borderWidth: 1,
    borderColor: colors.lightRed,
    height: 100,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    marginVertical: 15,
  },
  uploadeIcon: {
    tintColor: colors.lightRed,
    width: 50,
    height: 50,
  },
  // uploadeTxt: {
  //     color: colors.white,
  //     fontWeight: "500",
  //     fontSize: 13,
  // },
  // ImgBox: {
  //     backgroundColor: colors.inputBgColor,
  //     padding: 11,
  //     borderRadius: 10,
  //     elevation: 0.7,
  //     marginBottom: 20,
  // },
  // boxImg: {
  //     width: "100%",
  //     height: 200,
  //     borderRadius: 10,
  // },
});
