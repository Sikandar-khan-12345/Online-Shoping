import { ActivityIndicator, StyleSheet, Text, TextInput, View } from 'react-native'
import React, { memo } from 'react'
import Card from './Card'
import Icon from './Icon'
import Icons from '../../Constants/Icons'
import colors from '../../Constants/colors'
import Press from '../HOC/Press'

const HeaderSearchBar = ({
    containerStyle,
    style,
    icon = Icons.Search,
    iconTintColor = 'gray',
    iconSize = 20,
    placeholderTextColor = 'gray',
    placeholder = "Search something here",
    onChangeText,
    value,
    onSubmit,
    loading=false
}) => {
    return (
        <Card style={[styles.CardStyle, containerStyle]}>
            <Press onPress={onSubmit}>
            {loading? <ActivityIndicator color={colors.Orange}/>
                :<Icon size={iconSize} tintColor={iconTintColor} source={icon} />}
            </Press>
            <TextInput
                style={[styles.InputStyle, style]}
                placeholderTextColor={placeholderTextColor}
                placeholder={placeholder}
                onChangeText={onChangeText}
                value={value}
            />
        </Card>
    )
}

export default memo(HeaderSearchBar)

const styles = StyleSheet.create({
    CardStyle: {
        flexDirection: 'row',
        alignItems: 'center',
        borderRadius: 9,
        paddingHorizontal: 12,
        backgroundColor: colors.inputBgColor,
        // width: '95%',
        height: 50,
        marginVertical: 0,
        marginTop: 12,
        
    },
    InputStyle:{
        color:'#fff',
        width:'100%'
    }
})