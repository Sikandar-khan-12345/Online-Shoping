import React from "react";
import { View, TextInput } from "react-native";
import colors from "../../../Constants/colors";

import styles from "./styles";

const Input = (props) => {

    const {
        value,
        onChangeText,
        onSubmitEditing,
        inputStyle,
        inputContainerStyle,
        textInputProps
    } = props;

    return (
        <View style={[styles.textInputContainer, inputContainerStyle, { height: 50 }]}>
            <TextInput
                {...textInputProps}
                style={[styles.textInput, inputStyle, { height: 50, backgroundColor: colors.inputBgColor, borderRadius: 8, color: colors.white }]}
                value={value}
                onChangeText={onChangeText}
                onSubmitEditing={onSubmitEditing}
                placeholderTextColor={colors.white}
                underlineColorAndroid="transparent"
            />
        </View>
    );

};

export { Input };
export default Input;