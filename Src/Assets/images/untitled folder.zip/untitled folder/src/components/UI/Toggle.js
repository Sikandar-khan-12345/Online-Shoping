import { StyleSheet, Switch, Text, View } from 'react-native'
import React, { useState } from 'react'
import Typography from './Typography'
import colors from '../../Constants/colors'

const Toggle = ({
    label
}) => {
    const [isEnabled, setIsEnabled] = useState(false);
    return (
        <View>
            {label && (
                <Typography
                    size={12}
                    color={colors.lightRed}
                    type="medium"
                    style={styles.label}>
                    {label}
                </Typography>
            )}
            <View style={styles.toggleTab}>
                <Typography type='medium' color={!isEnabled ? colors.Orange : colors.placeTextColor}>
                    Inside
                </Typography>
                <Switch
                    trackColor={{ false: colors.Orange, true: colors.Orange }}
                    thumbColor={"#f4f3f4"}
                    ios_backgroundColor={colors.Orange}
                    onValueChange={() => setIsEnabled(!isEnabled)}
                    value={isEnabled}
                />
                <Typography type='medium' color={isEnabled ? colors.Orange : colors.placeTextColor}>
                    Outside
                </Typography>
            </View>
        </View>
    )
}

export default Toggle

const styles = StyleSheet.create({
    label: {
        marginBottom: 3,
    },
    toggleTab: {
        width: '100%',
        height: 55,
        backgroundColor: colors.inputBgColor,
        borderRadius: 8,
        justifyContent: 'space-around',
        alignItems: 'center',
        flexDirection: 'row'
    }
})