import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  TextInput,
  Platform,
  ActivityIndicator,
} from 'react-native';
import React, { memo, useState } from 'react';
import colors from '../../Constants/colors';
import fonts from '../../Constants/fonts';
import Icons from '../../Constants/Icons';
import Reanimated, {
  FadeIn,
  FadeInLeft,
  FadeInRight,
  FadeOut,
} from 'react-native-reanimated';
import { print } from '../../Constants';
import Typography from './Typography';

const CommonTextInput = ({
  returnKeyType,
  placeholderText,
  value = '',
  onChangeText,
  onBlur,
  namber,
  inputIcon,
  label,
  error,
  keyboardType,
  type,
  edit,
  placeHolderColor = colors.placeTextColor,
  numberOfLines,
  multiline,
  inputStyle,
  textAlignVertical = 'center',
  name,
  inputContainerStyle,
  containerHeight = 100,
  onFocus,
  maxLength,
  loading,
  right
}) => {
  const [show, setshow] = useState(true);
  print('textInput');
  return (
    <View style={{ height: containerHeight, justifyContent: 'flex-start', zIndex: Platform.OS === 'ios' ? -10 : undefined }}>
      {label && <Text style={styles.label}>{label}</Text>}

      <View style={[styles.inputStyle, inputContainerStyle]}>
        {namber && <Text style={{ color: '#fff' }}> {namber} </Text>}

        <TextInput
          onEndEditing={() => print('end')}
          onFocus={onFocus}
          selectionColor={colors.Orange}
          onBlur={onBlur}
          maxLength={maxLength}
          name={name}
          returnKeyType={returnKeyType}
          placeholder={placeholderText}
          error={error}
          value={`${value}`}
          style={[styles.inputStyle, { height: 55, flex: 1, ...inputStyle }]}
          placeholderTextColor={placeHolderColor}
          editable={edit}
          keyboardType={keyboardType}
          onChangeText={onChangeText}
          numberOfLines={numberOfLines}
          multiline={multiline}
          textAlignVertical={textAlignVertical}
          secureTextEntry={type === 'password' ? show : false}
        />
        {type == 'password' && (
          <TouchableOpacity onPress={() => setshow(!show)}>
            <Image
              style={{
                width: 20,
                height: 20,
                marginRight: 15,
                tintColor: colors.placeTextColor,
              }}
              source={!show ? Icons.show : Icons.hide}
            />
          </TouchableOpacity>
        )}
        {inputIcon && (
          <Image
            style={{
              width: 20,
              height: 20,
              tintColor: colors.placeTextColor,
              marginRight: 15,
            }}
            source={inputIcon}
          />
        )}
        {
          loading && <ActivityIndicator size={'small'} color={colors.Orange} style={{ marginRight: 15, }} />
        }
      </View>
      {!!error && <ErrorBox error={error} />}
    </View>
  );
};

export const ErrorBox = ({ error, marginVertical = 5 }) => {
  return (
    <Reanimated.Text
      entering={FadeInRight}
      exiting={FadeOut}
      numberOfLines={1}
      adjustsFontSizeToFit
      style={{
        fontSize: 10,
        // fontFamily: font.regular,
        color: colors.red,
        marginVertical: marginVertical,
        textAlign: 'right',
        alignSelf: 'flex-end',
      }}>
      {error}
    </Reanimated.Text>
  );
};

export default memo(CommonTextInput);
const styles = StyleSheet.create({
  inputStyle: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 8,
    paddingLeft: 10,
    color: colors.black,
    width: '100%',
    backgroundColor: colors.inputBgColor,
    color: colors.white,
  },
  label: {
    color: colors.lightRed,
    fontSize: 12,
    marginBottom: 3,
    fontFamily: fonts.medium,
  },
});
