import {StyleSheet, Text, View, Image} from 'react-native';
import React from 'react';
import colors from '../../Constants/colors';
import {TouchableOpacity} from 'react-native-gesture-handler';
import {useNavigation} from '@react-navigation/core';
import Typography from './Typography';

const CommonHeader = ({onBack, title}) => {
  const navigation = useNavigation();
  return (
    <View style={styles.header}>
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <Image style={styles.backIcon} source={onBack} />
      </TouchableOpacity>
      <Typography size={20} color={colors.lightRed} type="bold">
        {' '}
        {title}{' '}
      </Typography>
    </View>
  );
};

export default CommonHeader;
const styles = StyleSheet.create({
  header: {
    backgroundColor: colors.inputBgColor,
    height: 90,
    paddingHorizontal: 15,
    flexDirection: 'row',
    alignItems: 'center',
  },
  backIcon: {
    width: 35,
    height: 35,
    marginRight: 10,
  },
});
