import { StyleSheet, Text, View } from 'react-native';
import React, { memo } from 'react';
import colors from '../../Constants/colors';
import { STANDARD_WIDTH } from '../../Constants/layout';

const Devider = ({ marginVertical = 0, height = 1, standardWidth, color = colors.Orange }) => {
  return (
    <View style={styles.line(marginVertical, height, standardWidth, color)}></View>
  );
};

export default memo(Devider);

const styles = StyleSheet.create({
  line: (marginVertical, height, standardWidth, color) => {
    return {
      width: standardWidth ? STANDARD_WIDTH : '100%',
      height: height,
      marginVertical: marginVertical,
      backgroundColor: color,
      borderRadius: 10,
      alignSelf: 'center',
    };
  },
});
