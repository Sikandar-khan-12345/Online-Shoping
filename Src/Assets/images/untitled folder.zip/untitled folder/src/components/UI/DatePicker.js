import { StyleSheet, View, Image } from 'react-native';
import React, { memo, useState } from 'react';
import colors from '../../Constants/colors';
import Icons from '../../Constants/Icons';
import fonts from '../../Constants/fonts';
import Typography from '../../Components/UI/Typography';

import Reanimated, { FadeInRight, FadeOut } from 'react-native-reanimated';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import Press from '../HOC/Press';
import moment from 'moment';
import { print } from '../../Constants';

const DatePicker = ({
  label = 'Select Date',
  value,
  onValueChange = () => { },
  error,
  EMB,
  marginBottom = 0,
  marginTop = 5,
  inputRowBox,
  iconColor = colors.white,
  marginHorizontal = 15,
  pickerStyle,
  minimumDate,
  date = new Date(),
  mode = "date"
}) => {
  print('DatePicker')
  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);
  const [selectedDate, setselectedDate] = useState('Select Date');
  const showDatePicker = () => {
    setDatePickerVisibility(true);
  };

  const hideDatePicker = () => {
    setDatePickerVisibility(false);
  };

  const handleConfirm = date => {
    let newDate = new Date(date).toLocaleDateString()
    setselectedDate(moment(newDate).format('DD-MMM-YYYY'))
    onValueChange(date)
    hideDatePicker();
  };
  return (
    <View style={{ marginBottom: marginBottom, marginTop: marginTop, height: 90 }}>
      {label && (
        <Typography
          size={12}
          color={colors.lightRed}
          type="medium"
          style={styles.label}>
          {label}
        </Typography>
      )}

      <Press
        style={[styles.inputRowBox, inputRowBox]}
        onPress={() => showDatePicker()}>
        <View
          style={{
            marginHorizontal: marginHorizontal,
            flex: 1,
          }}>
          <Typography color={colors.white} type="medium">
            {value ? value : selectedDate}
          </Typography>
        </View>
        <Image source={Icons.downArrow} style={styles.dropIcons(iconColor)} />

        {EMB && (
          <Typography
            size={14}
            color={colors.lightRed}
            style={{ fontFamily: fonts.bold }}>
            {' '}
            {EMB}{' '}
          </Typography>
        )}
      </Press>
      {!!error && <ErrorBox error={error} />}
      <DateTimePickerModal
        timePickerModeAndroid='clock'
        is24Hour={false}
        date={date}
        minimumDate={minimumDate}
        isVisible={isDatePickerVisible}
        mode={mode}
        onConfirm={handleConfirm}
        onCancel={hideDatePicker}
      />
    </View>
  );
};

export const ErrorBox = ({ error }) => {
  return (
    <Reanimated.Text
      entering={FadeInRight}
      exiting={FadeOut}
      numberOfLines={1}
      adjustsFontSizeToFit
      style={{
        fontSize: 10,
        // fontFamily: font.regular,
        color: colors.red,
        marginVertical: 5,
        textAlign: 'right',
        alignSelf: 'flex-end',
      }}>
      {error}
    </Reanimated.Text>
  );
};

export default memo(DatePicker);
const styles = StyleSheet.create({
  inputRowBox: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: colors.inputBgColor,
    paddingRight: 10,
    borderRadius: 8,
    height: 55,
    // paddingLeft: 10,
    // color: colors.white,
  },
  dropIcons: color => {
    return {
      width: 20,
      height: 20,
      tintColor: color,
    };
  },
  label: {
    marginBottom: 3,
  },
});
