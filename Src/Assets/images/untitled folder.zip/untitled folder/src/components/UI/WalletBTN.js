import {View, StyleSheet, Image, TouchableOpacity} from 'react-native';
import React, {useState} from 'react';
import colors from '../../Constants/colors';
import Icons from '../../Constants/Icons';
import Icon from './Icon';
import Typography from './Typography';

const WalletBTN = ({
  onPress,
  label = 'Wallet Connect',
  style,
  rightIcon = Icons.downArrow,
  leftIcon = Icons.icon,
  centerItem,
  arrowICON,
  leftIconStyle = {
    tintColor: '',
    size: 25,
    marginRight: 10,
  },
  rightIconStyle = {
    tintColor: '',
    size: 18,
    marginRight: 0,
  },
}) => {
  return (
    <View
      style={{
        width: '100%',
      }}>
      <TouchableOpacity
        onPress={onPress}
        style={[styles.btn, style]}
        activeOpacity={0.99}>
        <View style={{flexDirection: 'row', alignItems: 'center'}}>
          <Icon
            size={25}
            style={leftIconStyle}
            tintColor={leftIconStyle.tintColor}
            marginRight={10}
            source={leftIcon}
          />
          {centerItem ? (
            centerItem
          ) : (
            <Typography
              type="medium"
              size={17}
              color={colors.white}
              style={styles.btnText}>
              {label}
            </Typography>
          )}
        </View>
        <Image
          style={[
            styles.arrowICON,
            {alignItems: 'flex-end', justifyContent: 'flex-end'},
            rightIconStyle,
          ]}
          resizeMode="contain"
          source={Icons.LeftArrow}
        />
      </TouchableOpacity>
    </View>
  );
};

export default WalletBTN;

const styles = StyleSheet.create({
  btn: {
    height: 60,
    width: '100%',
    backgroundColor: '#373737',
    borderRadius: 8,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 10,
    elevation: 5,
  },
  arrowICON: {
    width: 15,
    height: 15,
    tintColor: colors.white,
  },
  btnText: {
    fontWeight: '700',
  },
});
