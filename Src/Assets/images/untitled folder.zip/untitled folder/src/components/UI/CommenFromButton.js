import { StyleSheet, Text, TouchableOpacity } from 'react-native'
import React from 'react'
import colors from '../../Constants/colors';
import Typography from './Typography';
import fonts from '../../Constants/fonts';

const CommenFromButton = ({
    text,
    size,
    color,
    onPress={}
}) => {
    return (
        <>
            <TouchableOpacity onPress={onPress} style={styles.BTN} >
                <Typography size={size} color={color} type={fonts.bold} > {text} </Typography>
            </TouchableOpacity>
        </>
    )
}

export default CommenFromButton;

const styles = StyleSheet.create({
    BTN:{
        backgroundColor:colors.inputBgColor,
        height:55,
        borderRadius:10,
        justifyContent:"center",
        alignItems:'center', 
    },

})