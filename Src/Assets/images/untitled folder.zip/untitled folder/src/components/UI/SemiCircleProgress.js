import React, { memo, useEffect, useRef, useState } from 'react';
import {
  Animated,
  View,
  StyleSheet,
  ViewPropTypes,
  TextInput,
} from 'react-native';
import PropTypes from 'prop-types';
import { FULL_WIDTH } from '../../Constants/layout';
import colors from '../../Constants/colors';
import Typography from './Typography';
const SemiCircleProgress = ({
  percentage,
  exteriorCircleStyle = {
    backgroundColor: colors.bgcolor,
  },
  interiorCircleStyle = {
    backgroundColor: colors.inputBgColor,
  },
  minValue,
  maxValue,
  currentValue,
  textColor,
  progressShadowColor = 'silver',
  progressColor = colors.placeTextColor,
  interiorCircleColor = 'white',
  circleRadius = FULL_WIDTH * 0.1,
  progressWidth = FULL_WIDTH * 0.02,
  animationSpeed = 500,
  initialPercentage = 0,
}) => {
  const rotationAnimation = useRef(new Animated.Value(initialPercentage)).current
  const AnimatedInput = Animated.createAnimatedComponent(TextInput);

  const inputRef = useRef()
  useEffect(() => {
    animate(100);
    if (inputRef?.current) {
      inputRef.current.setNativeProps({
        text: `${percentage.toFixed()}%`,
      });
    }
  }, [percentage])
  const animate = toValue => {
    const speed = animationSpeed;
    Animated.timing(rotationAnimation, {
      toValue,
      speed,
      delay: 0,
      useNativeDriver: true,
    }).start(() => {
      animate(getPercentage());
    });
  };

  const getPercentage = () => {
    if (percentage) return Math.max(Math.min(percentage, 100), 0);

    if (currentValue && minValue && maxValue) {
      const newPercent =
        ((currentValue - minValue) / (maxValue - minValue)) * 100;
      return Math.max(Math.min(newPercent, 100), 0);
    }

    return 0;
  };

  const interiorCircleRadius = circleRadius - progressWidth;

  const styles = StyleSheet.create({
    exteriorCircle: {
      width: circleRadius * 2,
      height: circleRadius,
      borderRadius: circleRadius,
      backgroundColor: progressShadowColor,
    },
    rotatingCircleWrap: {
      width: circleRadius * 2,
      height: circleRadius,
      top: circleRadius,
    },
    rotatingCircle: {
      width: circleRadius * 2,
      height: circleRadius,
      borderRadius: circleRadius,
      backgroundColor: progressColor,
      transform: [
        { translateY: -circleRadius / 2 },
        {
          rotate: rotationAnimation.interpolate({
            inputRange: [0, 100],
            outputRange: ['0deg', '180deg'],
          }),
        },
        { translateY: circleRadius / 2 },
      ],
    },
    interiorCircle: {
      width: interiorCircleRadius * 2,
      height: interiorCircleRadius,
      borderRadius: interiorCircleRadius,
      backgroundColor: interiorCircleColor,
      top: progressWidth,
    },
  });


  return (
    <View
      style={[
        defaultStyles.exteriorCircle,
        styles.exteriorCircle,
        exteriorCircleStyle,
      ]}>
      <View
        style={[defaultStyles.rotatingCircleWrap, styles.rotatingCircleWrap]}>
        <Animated.View
          style={[defaultStyles.rotatingCircle, styles.rotatingCircle]}
        />
      </View>
      <View
        style={[
          defaultStyles.interiorCircle,
          styles.interiorCircle,
          interiorCircleStyle,
        ]}>
        {/* <AnimatedInput
          ref={inputRef}
          underlineColorAndroid={'transparent'}
          editable={false}
          defaultValue='0'
          // defaultValue={`${percentage.toFixed()}%`}
          style={[
            StyleSheet.absoluteFillObject,
            {
              fontSize: FULL_WIDTH * 0.035,
              color: textColor ?? progressColor,
              textAlign: 'center',
              fontWeight: 'bold',
              alignSelf: 'center',
              padding: 0,
            },
          ]}
        /> */}
      </View>
    </View>
  );
}

export default memo(SemiCircleProgress)
const defaultStyles = StyleSheet.create({
  exteriorCircle: {
    borderBottomLeftRadius: 0,
    borderBottomRightRadius: 0,
    alignItems: 'center',
    overflow: 'hidden',
  },
  rotatingCircleWrap: {
    position: 'absolute',
    left: 0,
  },
  rotatingCircle: {
    position: 'absolute',
    top: 0,
    left: 0,
    borderTopLeftRadius: 0,
    borderTopRightRadius: 0,
  },
  interiorCircle: {
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    borderBottomLeftRadius: 0,
    borderBottomRightRadius: 0,
  },
});
