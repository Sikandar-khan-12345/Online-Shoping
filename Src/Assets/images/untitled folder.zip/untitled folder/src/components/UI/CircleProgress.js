import { StyleSheet, Text, } from 'react-native'
import React from 'react'
import colors from '../../Constants/colors';
import Card from '../../Components/UI/Card';
import Typography from '../../Components/UI/Typography';

import ProgressCircle from 'react-native-progress-circle';

const CircleProgress = ({
    percent,
    Textpercent,
    TicketName,
    TicketPercent,

}) => {
    return (
        <>
            <Card style={styles.circleBox} >
                <ProgressCircle
                    percent={percent}
                    radius={45}
                    borderWidth={5}
                    color={colors.lightRed}
                    shadowColor={colors.white}
                    bgColor={colors.bgcolor}
                >
                    <Text style={styles.circleBoxTxt}>{Textpercent}</Text>

                </ProgressCircle>

                <Card style={styles.circleTextBox} >
                    <Typography size={18} color={colors.lightRed} type='bold'> {TicketName} </Typography>
                    <Typography size={18} color={colors.white} style={{ fontWeight: "700" }}> {TicketPercent} </Typography>
                </Card>
            </Card>

        </>
    )
}

export default CircleProgress;

const styles = StyleSheet.create({
    circleBox: {
        flexDirection: "row",
        alignContent: "center"
    },
    circleTextBox: {
        marginLeft: 15,
    },
    circleBoxTxt: {
        fontSize: 18,
        color: colors.white,
        fontWeight: "700"
    },
})

