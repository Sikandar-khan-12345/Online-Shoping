import { StyleSheet, View, Image } from 'react-native';
import React, { useState } from 'react';
import colors from '../../Constants/colors';
import Icons from '../../Constants/Icons';
import fonts from '../../Constants/fonts';
import RNPickerSelect from 'react-native-picker-select';
import Typography from '../../Components/UI/Typography';
import Reanimated, {
  FadeIn,
  FadeInLeft,
  FadeInRight,
  FadeOut,
} from 'react-native-reanimated';
import { print } from '../../Constants';

const CommenRNPickerSelect = ({
  label,
  value,
  onValueChange = () => { },
  error,
  placeholder,
  items = [
    { label: 'sd', value: 'dsds' }
  ],
  useNativeAndroidPickerStyle,
  EMB,
  marginBottom = 10,
  marginTop = 5,
  inputRowBox,
  iconColor = colors.white,
  marginHorizontal = 15,
  pickerStyle,
  containerHeight = 90,
}) => {
  print('CommenRNPickerSelect');
  return (
    <View
      style={{
        marginBottom: marginBottom,
        marginTop: marginTop,
        height: containerHeight,
      }}>
      {label && (
        <Typography
          size={12}
          color={colors.lightRed}
          type="medium"
          style={styles.label}>
          {label}
        </Typography>
      )}

      <View style={[styles.inputRowBox, inputRowBox]}>
        <RNPickerSelect
          touchableWrapperProps={{ activeOpacity: 0.5 }}
          useNativeAndroidPickerStyle={useNativeAndroidPickerStyle}
          placeholder={placeholder}
          onValueChange={e => onValueChange(e)}
          pickerProps={{
            mode: 'dropdown',
          }}

          value={value}
          items={items}
          style={{
            placeholder: {
              color: '#fff',
            },
            inputIOS: {
              color: '#fff',
            },
            inputAndroid: {
              width: '100%',
              fontSize: 13,
              color: '#fff',
            },
            inputAndroidContainer: {
              paddingHorizontal: 10,
            },
            inputIOSContainer: {
              paddingHorizontal: 10,
            },
            ...pickerStyle,
          }}
          fixAndroidTouchableBug={true}
        />
        <Image source={Icons.downArrow} style={styles.dropIcons(iconColor)} />

        {EMB && (
          <Typography
            size={14}
            color={colors.lightRed}
            style={{ fontFamily: fonts.bold }}>
            {' '}
            {EMB}{' '}
          </Typography>
        )}
      </View>
      {!!error && <ErrorBox error={error} />}
    </View>
  );
};

export const ErrorBox = ({ error }) => {
  return (
    <Reanimated.Text
      entering={FadeInRight}
      exiting={FadeOut}
      numberOfLines={1}
      adjustsFontSizeToFit
      style={{
        fontSize: 10,
        // fontFamily: font.regular,
        color: colors.red,
        marginVertical: 5,
        textAlign: 'right',
        alignSelf: 'flex-end',
      }}>
      {error}
    </Reanimated.Text>
  );
};

export default React.memo(CommenRNPickerSelect);
const styles = StyleSheet.create({
  inputRowBox: {
    // flexDirection: 'row',
    justifyContent: 'center',
    backgroundColor: colors.inputBgColor,
    borderRadius: 8,
    height: 55,
    zIndex: 10,
    // color: colors.white,
  },
  dropIcons: color => {
    return {
      width: 20,
      height: 20,
      tintColor: color,
      position: 'absolute',
      right: 10,
      zIndex: 0,
    };
  },
  label: {
    marginBottom: 3,
  },
});
