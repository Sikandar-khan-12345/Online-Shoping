import {
    StyleSheet,
    Text,
    View,
    Image,
    TouchableOpacity,
    TextInput,
} from 'react-native';
import React, { memo, useState } from 'react';
import colors from '../../Constants/colors';
import fonts from '../../Constants/fonts';
import Icons from '../../Constants/Icons';
// import Tags from "react-native-tags";
import Reanimated, {
    FadeIn,
    FadeInLeft,
    FadeInRight,
    FadeOut,
} from 'react-native-reanimated';
import { print } from '../../Constants';
import Typography from './Typography';
import TagsInput from '../UI/TagInput/index';
import { LangStrings } from '../../Languages/langStrings';

const TagInput = ({
    placeholderText = LangStrings.tagInput.selectTag,
    value,
    onChange = () => { },
    onBlur,
    label,
    error,
    keyboardType,
    placeHolderColor = colors.placeTextColor,
    inputStyle,
    inputContainerStyle,
    onFocus,
    initialTags = []
}) => {
    const [show, setshow] = useState(true);
    print('tagInput');
    return (
        <View style={{ justifyContent: 'flex-start', marginBottom: 20 }}>
            {label && <Text style={styles.label}>{label}</Text>}
            <TagsInput
                initialTags={initialTags}
                textInputProps={{
                    placeholder: placeholderText,
                }}
                onChangeTags={tags => onChange(tags)}
                onTagPress={(index, tagLabel, event, deleted) =>
                    print(index, tagLabel, event, deleted ? "deleted" : "not deleted")
                }
                containerStyle={{ justifyContent: "center" }}
                inputStyle={{ backgroundColor: "white" }}
                renderTag={({ tag, index, onPress, deleteTagOnPress, readonly }) => (
                    <TouchableOpacity style={styles.tag} key={`${tag}-${index}`} onPress={onPress}>
                        <Typography type='0' size={14} color={colors.white}>#{tag}</Typography>
                    </TouchableOpacity>
                )}
            />
            {!!error && <ErrorBox error={error} />}
        </View>
    );
};

export const ErrorBox = ({ error }) => {
    return (
        <Reanimated.Text
            entering={FadeInRight}
            exiting={FadeOut}
            numberOfLines={1}
            adjustsFontSizeToFit
            style={{
                fontSize: 10,
                color: colors.red,
                marginVertical: 5,
                textAlign: 'right',
                alignSelf: 'flex-end',
            }}>
            {error}
        </Reanimated.Text>
    );
};

export default memo(TagInput);
const styles = StyleSheet.create({
    inputStyle: {
        flexDirection: 'row',
        alignItems: 'center',
        borderRadius: 8,
        paddingLeft: 10,
        color: colors.black,
        width: '100%',
        backgroundColor: colors.inputBgColor,
        color: colors.white,
    },
    label: {
        color: colors.lightRed,
        fontSize: 12,
        marginBottom: 3,
        fontFamily: fonts.medium,
    },
    tag: {
        backgroundColor: colors.inputBgColor,
        padding: 10,
        margin: 5
    }
});
