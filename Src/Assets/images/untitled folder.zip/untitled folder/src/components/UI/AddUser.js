import { Alert, FlatList, Image, StyleSheet, Switch, TouchableOpacity, View } from 'react-native'
import React, { memo, useCallback, useState } from 'react'
import colors from '../../Constants/colors'
import Typography from './Typography'
import CommonTextInput, { ErrorBox } from './CommonTextInput'
import CommenRNPickerSelect from './CommenRNPickerSelect'
import Icon from './Icon'
import Icons from '../../Constants/Icons'
import Press from '../HOC/Press'
import Toggle from './Toggle'
import { isValidForm, validators } from '../../Constants/Validation'
import BottomSheet from './BottomSheet/BottomSheet'
import SheetModal from './SheetModal'
import { print } from '../../Constants'
import { LangStrings } from '../../Languages/langStrings'

const AddUser = ({
    error,
    label,
    containerHeight,
    defaultUserName = 'Select User',
    pickerItems = [],
    onAdd = () => { },
    dataList = [],
    onDelete = () => { },
    paymentSettlement = 'commission',
    onChangePaymentSettlement = () => { },
    onCommissionChange = () => { },
    commission = '',
    assignTickets = '',
    onTicketsChange = () => { },
    onSearch = () => { },
    type = '6',
    sheetData = [],
    onSelectionUser = () => { }
}) => {
    print('AddUser')
    const [errors, setErrors] = useState({})
    const [sheetVisible, setSheetVisible] = useState(false)
    const deleteUser = (i, array) => {
        let arr = [...array]
        arr.splice(i, 1)
        onDelete(arr)
    }
    const _renderItem = useCallback(
        ({ item, index }) => {
            return <UserCard items={item} index={index} Delete={() => deleteUser(index, dataList)} />
        },
        [dataList],
    )
    return (
        <View style={{ height: containerHeight, marginBottom: 10 }}>
            <SheetModal
                visible={sheetVisible}
                onClose={() => setSheetVisible(false)}
                sheetData={sheetData}
                onSelect={(name, id, image) => {
                    print("🚀 ~ file: -----------------------.js ~ line 55 ~ img", name, id, image)
                    onSelectionUser(name, id, image)
                }}
            />
            {label && (
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 }}>
                    <Typography
                        size={20}
                        color={colors.lightRed}
                        type="medium"
                        style={styles.label}>
                        {label}
                    </Typography>
                    <Press style={styles.add}
                        onPress={onAdd}
                    >
                        {/* <Icon
                            source={Icons.plus}
                            size={15}
                            tintColor={colors.white}
                        /> */}
                        <Typography size={15} color={colors.white} type='medium'>{LangStrings.addUser.add}</Typography>
                    </Press>
                </View>
            )}
            <TouchableOpacity onPress={() => setSheetVisible(true)} style={{
                width: '100%',
                backgroundColor: colors.inputBgColor,
                height: 55,
                borderRadius: 8,
                justifyContent: 'center',
                padding: 10,
                marginBottom: 5
            }}>
                <Typography color={colors.white} type='medium'>{defaultUserName}</Typography>
            </TouchableOpacity>
            {type != '7' && <View style={styles.container}>
                <View style={{
                    flex: 1,
                    marginVertical: 5,
                    flexDirection: 'row-reverse',
                    justifyContent: 'space-between'
                }}>
                    <View style={{ flex: 1, height: 80, margin: 5 }}>
                        <CommonTextInput
                            containerHeight={90}
                            label={LangStrings.addUser.commission}
                            placeholderText={paymentSettlement == 'commission' ? `${LangStrings.addUser.enterCommission}(EMT)` : `${LangStrings.addUser.enterCommission}%`}
                            value={commission}
                            onChangeText={onCommissionChange}
                            keyboardType='numeric'
                            error={errors?.commission}
                        />
                    </View>
                    <View style={{ flex: 1, height: 80, margin: 5 }}>
                        <Typography
                            size={12}
                            color={colors.lightRed}
                            type="medium"
                            style={styles.label}>
                            {LangStrings.addUser.paymentSettlement}
                        </Typography>
                        <View style={styles.toggleTab}>
                            <Typography type='medium' size={10} color={paymentSettlement == 'commission' ? colors.Orange : colors.placeTextColor}>
                                {LangStrings.addUser.commission}
                            </Typography>
                            <Switch
                                trackColor={{ false: colors.Orange, true: colors.Orange }}
                                thumbColor={"#f4f3f4"}
                                ios_backgroundColor={colors.Orange}
                                onValueChange={onChangePaymentSettlement}
                                value={paymentSettlement == 'percentage'}
                            />
                            <Typography type='medium' size={10} color={paymentSettlement == 'percentage' ? colors.Orange : colors.placeTextColor}>
                                {LangStrings.addUser.percentage}
                            </Typography>
                        </View>
                    </View>
                </View>
                <View style={{
                    flex: 1,
                    flexDirection: 'row',
                    justifyContent: 'space-between'
                }}>
                    {type != '6' && <View style={{ flex: 1, height: 80, margin: 5 }}>
                        <CommonTextInput
                            label={LangStrings.addUser.assignTickets}
                            placeholderText={LangStrings.addUser.enterNumOfTickets}
                            error={errors?.assignTickets}
                            value={assignTickets}
                            onChangeText={onTicketsChange}
                            keyboardType='numeric'
                        />
                    </View>}
                </View>
            </View>}
            {!!dataList.length &&
                <FlatList
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    data={dataList}
                    renderItem={_renderItem}
                />}
            {!!error && <ErrorBox error={error} />}
        </View>
    )
}

export default memo(AddUser)

const UserCard = ({ items, index, Delete }) => {
    print("🚀 ~ file: AddUser.js ~ line 164 ~ UserCard ~ items", items)
    return (
        <View style={styles.userCard}>
            <Press style={styles.delete} onPress={() => Delete(index)}>
                <Icon
                    source={Icons.plus}
                    size={15}
                    tintColor={colors.black}
                />
            </Press>
            <Image
                source={{ uri: items?.img }}
                style={{ width: 80, height: 80, borderRadius: 40, marginBottom: 8 }}
                round
            />
            <Typography size={16} color={colors.Orange} type='medium'>{items?.name}</Typography>
        </View>
    )
}
const styles = StyleSheet.create({
    container: {
        width: '100%',
        borderRadius: 8,
        // flexDirection: 'row',
        // justifyContent: 'space-between',
    },
    label: {
        marginBottom: 3,
    },
    add: {
        padding: 7,
        backgroundColor: colors.Orange,
        borderRadius: 15,
        // height: 30,
        // width: 30,
        // marginTop: 25,
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: 15
        // position: 'absolute',
        // top: 0,
        // right: 0
    },
    userCard: {
        width: 120,
        height: 145,
        backgroundColor: colors.inputBgColor,
        margin: 5,
        borderRadius: 7,
        justifyContent: 'center',
        alignItems: 'center'
    },
    delete: {
        padding: 5,
        backgroundColor: colors.white,
        borderRadius: 50,
        position: 'absolute',
        top: -5,
        right: -5,
        transform: [{ rotate: '45deg' }]
    },
    toggleTab: {
        width: '100%',
        height: 55,
        backgroundColor: colors.inputBgColor,
        borderRadius: 8,
        justifyContent: 'space-around',
        alignItems: 'center',
        flexDirection: 'row',
    }
})