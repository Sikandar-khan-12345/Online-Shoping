import { ImageBackground, StyleSheet, Text, TouchableOpacity, View, ActivityIndicator } from 'react-native'
import React, { memo } from 'react'
import Icon from './Icon'
import Typography from './Typography'
import colors from '../../Constants/colors'
import Icons from '../../Constants/Icons'
import Press from '../HOC/Press'
import { CURRENCY } from '../../Constants'
import Ripple from 'react-native-material-ripple';
const ItemCard = ({
    data = {
        profile: Icons.profile,
        username: 'JHON DOE',
        likes: 100,
        eventImage: 'https://www.liveclefs.com/wp-content/uploads/2018/08/Darshan-Raval-Live.jpg',
        type: 'Collaboration',
        hubName: 'THE DARK CORNER',
        bidPrice: 17,
    },
    imageStyle,
    cardFooter,
    cardHeader,
    eventImage,
    children,
    onPress,
    topRightContent,
    topLeftContent,
    bottomLeftContent,
    bottomRightContent,
    onBottomRightPress = () => { }
}) => {
    return (
        <TouchableOpacity activeOpacity={0.9} style={[styles.card]} onPress={onPress}>
            {
                cardHeader ? cardHeader :
                    <View style={styles.cardHeader}>
                        <View style={{ flexDirection: 'row', marginVertical: 5, alignItems: 'center' }}>
                            <Icon size={27} marginRight={2} source={data.profile} />
                            <Typography size={13} color={colors.golden} type={'bold'}>
                                {data.username}
                            </Typography>
                        </View>
                        {data.likes && <View style={{ flexDirection: 'row', alignItems: 'center', }}>
                            <Typography color={colors.golden} style={{ marginRight: 2 }} type={'bold'}>
                                {data.likes}
                            </Typography>
                            <Icon source={require('../../../Assets/images/heart.png')} tintColor={colors.golden} size={17} />

                        </View>}


                    </View>}
            <ImageBackground source={{ uri: eventImage ? eventImage : data.eventImage }} style={[styles.image, imageStyle]} borderRadius={7} resizeMode={'cover'}>
                {topRightContent && <Press style={[styles.bgIcon, { top: 10, right: 10 }]}>
                    {topRightContent}
                </Press>}
                {topLeftContent && <Press style={[styles.bgIcon, { top: 10, left: 10 }]}>
                    {topLeftContent}
                </Press>}
                {bottomRightContent && <Press style={[styles.bgIcon, { bottom: 10, right: 10 }]}>
                    {bottomRightContent}
                </Press>}
                {bottomLeftContent && <Press onPress={onBottomRightPress} style={[styles.bgIcon, { bottom: 10, left: 10 }]}>
                    {bottomLeftContent}
                </Press>}
            </ImageBackground>
            {
                cardFooter ? cardFooter :
                    <View style={styles.cardHeader}>
                        <View>
                            <Typography size={11} type={'bold'} color={colors.golden}>
                                {data.hubName}
                            </Typography>
                            <Typography size={10} type={'bold'} style={{ marginTop: 5 }} color={colors.white}>
                                {data.type}
                            </Typography>
                        </View>
                        <View>
                            <Typography textAlign={'right'} size={11} type={'bold'} color={colors.golden}>
                                {data.bidPrice} {`${CURRENCY}`}
                            </Typography>
                            <Typography textAlign={'right'} style={{ marginTop: 5 }} type={'bold'} size={10} color={colors.white}>
                                Bid Price
                            </Typography>
                        </View>
                    </View>
            }

        </TouchableOpacity>
    )
}

export default memo(ItemCard)

const styles = StyleSheet.create({
    card: {
        width: '100%',
        backgroundColor: colors.inputBgColor,
        padding: 10,
        borderRadius: 7,
        marginVertical: 10,
    },
    cardHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        flex: 1
    },
    image: { width: '100%', height: 150, marginVertical: 5 },
    bgIcon: {
        backgroundColor: colors.transWhite,
        padding: 10,
        borderRadius: 8,
        position: 'absolute'
    }
})