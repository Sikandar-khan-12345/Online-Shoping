import { StyleSheet, View } from 'react-native';
import React, { memo } from 'react';
import { SPACING, STANDARD_WIDTH } from '../../Constants/layout';
import { print } from '../../Constants';

const Card = ({ children, style = {}, marginVertical = SPACING }) => {
  print('Card')
  return <View style={[styles.card(marginVertical), style]}>{children}</View>;
};

export default memo(Card);

const styles = StyleSheet.create({
  card: (marginVertical) => {
    return {
      width: STANDARD_WIDTH,
      alignSelf: 'center',
      marginVertical: marginVertical,
    }
  },
});
