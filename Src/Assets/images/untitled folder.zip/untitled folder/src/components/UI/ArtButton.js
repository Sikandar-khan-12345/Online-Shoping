import {
  StyleSheet,
  Text,
  View,
  Image,
  ScrollView,
  SafeAreaView,
  ImageBackground,
  TouchableOpacity,
  Platform,
} from 'react-native';
import React from 'react';
import Icons from '../../Constants/Icons';
import { useNavigation } from '@react-navigation/native';
import Press from '../HOC/Press';
import Card from './Card';
import Icon from './Icon';
import colors from '../../Constants/colors';
import { CURRENCY } from '../../Constants';

const ArtButton = ({ img = Icons.noImage }) => {
  const navi = useNavigation();
  return (
    <ImageBackground
      style={styles.BackGroundImg}
      resizeMode="cover"
      resizeMethod="auto"
      source={{ uri: img }}>
      <Card>
        <View style={styles.MainButtonStyle}>
          {/* ------First Button ------- */}
          <Press activeOpacity={0.7} style={styles.ArtButton}>
            <Icon size={16} source={Icons.Invite} />
            <Text style={styles.ButtonText}>David B</Text>
          </Press>
          {/* ------- Second Button ------ */}
          {/* <Press activeOpacity={0.7} style={styles.ArtButton}>
            <Icon size={16} source={Icons.priceTag} />
            <Text style={styles.ButtonText}>{CURRENCY} 400</Text>
          </Press> */}
          {/* --------- Third Button ----------- */}
          <Press activeOpacity={0.7} style={styles.ArtButton}>
            <Icon size={16} source={Icons.united} tintColor={colors.black} />
            <Text style={styles.ButtonText}>209</Text>
          </Press>
        </View>
      </Card>
    </ImageBackground>
  );
};

export default ArtButton;
const styles = StyleSheet.create({
  BackGroundImg: {
    width: '100%',
    height: 301,
    justifyContent: 'flex-end',
    alignItems: 'flex-end',
    paddingBottom: 10,
  },

  MainButtonStyle: {
    opacity: 0.7,
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignSelf: 'center',
    width: '100%',
  },

  ArtButton: {
    backgroundColor: '#fff',
    paddingVertical: Platform.OS === 'android' ? 6 : 10,
    borderRadius: 8,
    width: Platform.OS === 'android' ? 110 : 100,
    alignItems: 'center',
  },
  ButtonIcon: {
    tintColor: '#000',
    height: 20,
    width: 20,
    alignSelf: 'center',
  },
  ButtonText: {
    color: '#000',
    fontWeight: '500',
    textAlign: 'center',
    fontSize: 15,
  },
});
