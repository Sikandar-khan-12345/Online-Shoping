import React from 'react';
import {StyleSheet, Text, View} from 'react-native';

const Header = ({}) => {
  return (
    <View style={styles.container}>
      <View style={styles.left}></View>
      <View style={styles.center}></View>
      <View style={styles.right}></View>
    </View>
  );
};

export default Header;

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: 65,
    flexDirection: 'row',
  },
  left: {
    height: 65,
  },
  center: {
    flex: 1,
    backgroundColor: 'red',
    height: 65,
  },
  right: {
    height: 65,
  },
});
