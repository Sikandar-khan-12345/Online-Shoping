import { ActivityIndicator, ScrollView, StyleSheet, Text, View } from 'react-native';
import React from 'react';
import Container from '../HOC/Container';
import Spinner from './Spinner';
import Typography from './Typography';
import colors from '../../Constants/colors';
import { FULL_HEIGHT, STANDARD_WIDTH } from '../../Constants/layout';
import VirtualizedView from '../HOC/VirtualizedView';
import globalStyle from '../../Constants/globalStyle';
import FloatingButton from '../HOC/FloatingButton';
import ScrollContainer from '../HOC/ScrollContainer';
import { LangStrings } from '../../Languages/langStrings';
const LoadingContainer = ({
  isLoading = false,
  stickyHeaderIndices,
  data,
  children,
  emptyText = LangStrings.loadingContainer.noData,
  refreshControl,
  submitButton = false,
  drawer = true,
  isButtonLoading,
  OnClick,
  bottomButtons,
  buttonTitle = 'Click me',
  contentContainerStyle = globalStyle.commonPaddingBottom,
  onScroll = () => { },
  scrollEventThrottle = 100,
  moreLoading = false,
  bottomLoaderPosition = -50,
  scrollEnabled = false
}) => {
  return (
    <Container>
      {isLoading ? (
        <Spinner />
      ) : (
        <Container>
          {data?.length ? (
            <ScrollContainer
              stickyHeaderIndices={stickyHeaderIndices}
              refreshControl={refreshControl}
              onScroll={onScroll}
              scrollEventThrottle={scrollEventThrottle}
              showsVerticalScrollIndicator={false}
              scrollEnabled={scrollEnabled}
              contentContainerStyle={contentContainerStyle}>
              {children}
            </ScrollContainer>
          ) : (
            <ScrollView
              refreshControl={refreshControl}
              scrollEnabled={false}
              onScroll={onScroll}
              scrollEventThrottle={scrollEventThrottle}
              contentContainerStyle={{ flex: 1, justifyContent: 'center' }}>
              <Typography
                size={35}
                color={colors.Orange}
                textAlign="center"
                type="medium">
                {emptyText}
              </Typography>
            </ScrollView>
          )}
          {moreLoading && <ActivityIndicator style={{ marginBottom: 10, top: bottomLoaderPosition }} color={colors.Orange} size='small' />}
        </Container>
      )}
      {bottomButtons && (
        <FloatingButton
          buttonTitle={buttonTitle}
          titleColor={colors.lightRed}
          drawer={drawer}
          submit={submitButton}
          isLoading={isButtonLoading}
          onSubmit={OnClick}
        />
      )}
    </Container>
  );
};

export default LoadingContainer;

const styles = StyleSheet.create({});
