import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import colors from '../../Constants/colors'

const Process = ({
    active = 1 
}) => {
    return (
        <View style={styles.Process} >
             <Text style={[styles.borderCT, {backgroundColor: active >= 1 ? colors.lightRed : colors.lightRedGray  }]}> </Text>
            <Text style={[styles.borderCT, {backgroundColor: active >= 2 ? colors.lightRed : colors.lightRedGray  }]}> </Text>
            <Text style={[styles.borderCT, {backgroundColor: active >= 3 ? colors.lightRed : colors.lightRedGray  }]}> </Text>
            <Text style={[styles.borderCT, {backgroundColor: active  == 4 ? colors.lightRed : colors.lightRedGray }]}> </Text>
        </View>
    )
}

export default Process

const styles = StyleSheet.create({
    Process:{ 
        marginVertical: 15, 
        flexDirection: "row", 
        justifyContent: "space-between", 
        alignItems: "center" 
    },
    borderCT:{
        backgroundColor:"#563e22",
        borderRadius:10,
        width:"23%",
        height:3,
      }
    

})