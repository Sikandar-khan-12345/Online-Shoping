import React from 'react';
const Container = ({children}) => {
  return <>{children}</>;
};

export default Container;
