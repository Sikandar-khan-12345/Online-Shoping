import { StyleSheet, ScrollView, ActivityIndicator } from 'react-native';
import React, { memo } from 'react';
import ViewContainer, { containerStyle } from './ViewContainer';
import colors from '../../Constants/colors';
import { print } from '../../Constants';

const ScrollContainer = ({
  children,
  backgroundColor = colors.white,
  style = {},
  contentContainerStyle,
  refreshControl,
  stickyHeaderIndices,
  onScroll,
  scrollEnabled,
  nestedScrollEnabled,
  moreLoading,
  bottomLoaderPosition = -50,
  scrollEventThrottle
}) => {
  print('scrollcontainer')
  return (
    <ViewContainer backgroundColor={backgroundColor} style={style}>
      <ScrollView
        nestedScrollEnabled={nestedScrollEnabled}
        scrollEnabled={scrollEnabled}
        onScroll={onScroll}
        contentContainerStyle={contentContainerStyle}
        refreshControl={refreshControl}
        showsVerticalScrollIndicator={false}
        stickyHeaderIndices={stickyHeaderIndices}
        scrollEventThrottle={scrollEventThrottle}
        style={[containerStyle.container(backgroundColor), styles.scroll]}>
        {children}
      </ScrollView>
      {moreLoading && <ActivityIndicator style={{ marginBottom: 10, top: bottomLoaderPosition }} color={colors.Orange} size='small' />}
    </ViewContainer>
  );
};

export default memo(ScrollContainer);

const styles = StyleSheet.create({
  scroll: {},
});
