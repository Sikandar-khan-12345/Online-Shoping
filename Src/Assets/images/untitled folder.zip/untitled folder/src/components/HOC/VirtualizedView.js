import React from 'react';
import { FlatList, ScrollView, StyleSheet } from 'react-native';
import colors from '../../Constants/colors';
import Container from './Container';
import FloatingButton from './FloatingButton';
import ViewContainer, { containerStyle } from './ViewContainer';

export default function VirtualizedView({
  children,
  refreshControl,
  contentContainerStyle,
  backgroundColor,
  submitButton = false,
  drawer = true,
  isLoading,
  OnClick,
  bottomButtons,
  buttonTitle = 'Click me',
  onScroll = () => { },
  scrollEventThrottle = 100,
}) {
  return (
    <ViewContainer>
      <ScrollView
        showsVerticalScrollIndicator={false}
        style={[containerStyle.container(backgroundColor), styles.scroll]}
        contentContainerStyle={contentContainerStyle}
        onScroll={onScroll}
        scrollEventThrottle={scrollEventThrottle}
        refreshControl={refreshControl}
      >{children}</ScrollView>
      {bottomButtons && (
        <FloatingButton
          buttonTitle={buttonTitle}
          titleColor={colors.lightRed}
          drawer={drawer}
          submit={submitButton}
          isLoading={isLoading}
          onSubmit={OnClick}
        />
      )}
    </ViewContainer>
  );
}

const styles = StyleSheet.create({
  scroll: {},
});
