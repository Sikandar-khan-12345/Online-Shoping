import {
  StyleSheet,
  View,
  ImageBackground,
  TouchableOpacity,
  Animated,
  ScrollView,
  Alert,
  FlatList,
  Image,
} from 'react-native';
import React, { memo, useCallback, useEffect, useRef, useState } from 'react';
import Typography from '../UI/Typography';
import { FULL_HEIGHT, FULL_WIDTH, STANDARD_WIDTH } from '../../Constants/layout';
import { Easing, EasingNode } from 'react-native-reanimated';
import colors from '../../Constants/colors';
import Icon from '../UI/Icon';
import Icons from '../../Constants/Icons';
import { useNavigation } from '@react-navigation/native';
import Ripple from 'react-native-material-ripple';
import {
  USER_ARTIST,
  USER_FAN,
  USER_PR,
  USER_PRODUCER,
  USER_STAFF,
} from '../../Constants/UserType';
import { FAN, ARTIST, PR, PRODUCER, STAFF } from '../../Context/UserContext';
import { connect, useDispatch, useSelector } from 'react-redux';
import { updateisauth } from '../../redux/IsAuth/action';
import { logoutHandler, SimpleToaster, storage } from '../../Backend/Backend';
import { appReducer } from '../../redux/rootReducer';
import Spinner from '../UI/Spinner';
import Press from './Press';
import Devider from '../UI/Devider';
import {
  updateBeveragesData,
  updateeventsdata,
  updateuserdata,
} from '../../redux/UserData/action';
import SimpleToast from 'react-native-simple-toast';
import { print } from '../../Constants';
import { LangStrings } from '../../Languages/langStrings';

const FloatingButton = ({
  buttonTitle,
  titleSize = 20,
  titleColor = colors.Orange,
  drawer = false,
  children,
  submit = false,
  onSubmit = () => { },
  isLoading = false,
}) => {
  const dispatch = useDispatch();
  const [drawerTabs, setdrawerTabs] = useState(USER_PRODUCER);
  const [isOpen, setisOpen] = useState(false);
  const navigation = useNavigation();
  const userInfo = useSelector(state => state.useDataReducer.userData);
  const userType = useSelector(state => state.useUserType.userType);
  const animation = useRef(new Animated.Value(0)).current;
  const [userData, setUserData] = useState({})
  useEffect(() => {
    switch (userType) {
      case FAN:
        setdrawerTabs(USER_FAN);
        break;
      case PR:
        setdrawerTabs(USER_PR);
        break;
      case PRODUCER:
        setdrawerTabs(USER_PRODUCER);
        break;
      case ARTIST:
        setdrawerTabs(USER_ARTIST);
        break;
      case STAFF:
        setdrawerTabs(USER_STAFF);
        break;
    }
    const adminData = storage.getString('adminData')
    if (adminData != undefined) {
      print('==', adminData);
      setUserData(JSON.parse(adminData))
    }
  }, []);

  const clearStore = () => {
    dispatch(updateuserdata({}));
    dispatch(updateeventsdata([]));
    dispatch(updateBeveragesData([]));
  };

  const onLogout = () => {
    Alert.alert(LangStrings.flotingButton.logoutAlert, [
      {
        text: LangStrings.flotingButton.cancel,
        onPress: () => print(''),
        style: 'cancel',
      },
      {
        text: LangStrings.flotingButton.ok,
        onPress: async () => {
          logoutHandler();
          clearStore();
          dispatch(updateisauth(false));
        },
      },
    ]);
  }


  const translateX = animation.interpolate({
    inputRange: [0, 1],
    outputRange: [FULL_WIDTH, 0],
    extrapolate: 'clamp',
  });

  const animatedStyles = {
    transform: [{ translateX }],
  };

  const toDoAnimation = () => {
    Animated.timing(animation, {
      toValue: isOpen ? 0 : 1,
      duration: isOpen ? 200 : 500,
      easing: isOpen ? Easing.circle : Easing.bounce,
      useNativeDriver: true,
    }).start();
    setisOpen(!isOpen);
    setisSubRoute(false);
  };

  const onNavigation = (route, type) => {
    Animated.timing(animation, {
      toValue: 0,
      duration: 200,
      easing: Easing.circle,
      useNativeDriver: true,
    }).start(() => {
      setisOpen(!isOpen);
      setisSubRoute(false);
    });
    if (route) {
      if (type) {
        navigation.navigate(route, { apiRoute: type });
      } else {
        navigation.navigate(route);
      }
    } else {
      SimpleToaster(LangStrings.flotingButton.comingSoon)
    }
  }
  const [isSubRoute, setisSubRoute] = useState(false);
  print('floatingButton')


  return (
    <TouchableOpacity
      activeOpacity={0.99}
      onPress={toDoAnimation}
      style={[
        styles.mainContainer,
        {
          width: submit || isOpen ? FULL_WIDTH : FULL_WIDTH * 0.3,
          left: submit || isOpen ? 0 : undefined,
          top: !isOpen ? undefined : 0,
          right: 0,
          zIndex: 0,
        },
      ]}>
      <Animated.View
        style={{
          ...styles.drawer,
          ...animatedStyles,
        }}>
        <ScrollView
          contentContainerStyle={{ paddingBottom: 80 }}
          style={styles.card}
          showsVerticalScrollIndicator={false}>
          <View style={{ flex: 1, alignItems: 'center' }}>
            <Image
              style={{ width: 50, height: 50, borderRadius: 25 }}
              source={{ uri: userInfo?.image_url }}
            />
            <TouchableOpacity
              disabled
              style={[styles.tab, { justifyContent: 'center' }]}
              activeOpacity={0.8}>
              <Typography
                textAlign={'center'}
                size={18}
                color={colors.golden}
                type={'medium'}>
                {userInfo?.name}
              </Typography>
            </TouchableOpacity>
            {drawerTabs.map((item, i) => {
              return (
                <View key={i} style={{ width: '100%' }}>
                  {item?.subRoute ? (
                    <View
                      key={i}
                      style={{ width: '100%', alignItems: 'flex-start' }}>
                      <TouchableOpacity
                        key={i + 1}
                        style={styles.tab}
                        activeOpacity={0.8}
                        onPress={() => {
                          let arr = [...drawerTabs]
                          arr[i]['isOpen'] = arr[i]['isOpen'] ? !(arr[i]['isOpen']) : true
                          console.log('[---', arr);
                          setdrawerTabs(arr)
                        }}
                      >
                        <Typography
                          type="medium"
                          size={16}
                          color={colors.white}>
                          {item?.name}
                        </Typography>
                        <Icon
                          size={15}
                          tintColor={colors.Orange}
                          source={Icons.LeftArrow}
                          style={{
                            transform: [
                              { rotate: item?.isOpen ? '-90deg' : '90deg' },
                            ],
                          }}
                        />
                      </TouchableOpacity>
                      {item?.isOpen &&
                        item.subRoute.map((key, i) => {
                          return (
                            <NavigationTab
                              title={key?.name}
                              marginLeft={20}
                              index={i}
                              onPress={() => onNavigation(key?.routeName, key?.apiRoute)}
                            />
                          );
                        })}
                      <Devider />
                    </View>
                  ) : (
                    <>
                      <NavigationTab
                        title={item?.name}
                        index={i}
                        onPress={() => onNavigation(item?.routeName)}
                      />
                      <Devider />
                    </>
                  )}
                </View>
              );
            })}
            {
              userInfo?.role_id == '7' &&
              <>
                {userInfo?.permission_ids.split(',').map((item, i) => {
                  return (
                    <>
                      <NavigationTab
                        title={item == '1' ? 'Scan Tickets' : 'Beverage Listing'}
                        color={colors.white}
                        onPress={() => {
                          if (item == '1') {
                            onNavigation('ScanTicket')
                          } else {
                            SimpleToast.show(LangStrings.flotingButton.comingSoon)
                          }
                        }}
                      />
                      <Devider />
                    </>
                  );
                })}
              </>
            }
            {(userData?.connect_wallet == '1' && !(userType == '7')) ? <>
              <NavigationTab
                onPress={() => onNavigation('WalletModule')}
                title={LangStrings.flotingButton.myWallet}
                color={colors.white}
              />
              <Devider />
            </>
              : null}
            <NavigationTab
              onPress={onLogout}
              title={LangStrings.flotingButton.logout}
              color={colors.Orange}
            />
            <Devider />
          </View>
        </ScrollView>
      </Animated.View>
      <View
        style={{
          position: 'absolute',
          bottom: 0,
          width: !isOpen ? FULL_WIDTH : FULL_WIDTH * 0.3,
          zIndex: 20,
          height: 80,
          flexDirection: 'row',
        }}>
        <View
          style={{
            width: submit || isOpen ? FULL_WIDTH * 0.8 : 0,
          }}>
          {submit && !isOpen && (
            <Press style={{ flex: 1 }}
              onPress={onSubmit}
            >
              <ImageBackground
                imageStyle={[styles.imageStyle, { height: 80 }]}
                source={require('../../../Assets/images/btn-set-Left.png')}
                resizeMode="stretch"
                style={styles.backgroundImageContainer}>
                {buttonTitle && !isLoading ? (
                  <Typography
                    type="medium"
                    size={titleSize}
                    color={titleColor}
                    textAlign={'center'}>
                    {buttonTitle}
                  </Typography>
                ) : (
                  <Spinner type={'button'} size={'small'} />
                )}
              </ImageBackground>
            </Press>
          )}
        </View>
        <Press
          style={{
            width: FULL_WIDTH * 0.3,
            right: submit || isOpen ? FULL_WIDTH * 0.1 : undefined,
          }}
          onPress={() => toDoAnimation()}
        >
          <ImageBackground
            imageStyle={[
              styles.imageStyle,
              { height: 80, justifyContent: 'center' },
            ]}
            source={require('../../../Assets/images/btn-Right.png')}
            resizeMode="stretch"
            style={[styles.backgroundImageContainer, { paddingLeft: 10 }]}>
            <Icon
              source={isOpen ? Icons.close : Icons.open}
              tintColor={colors.Orange}
              size={isOpen ? 20 : 35}
            />
          </ImageBackground>
        </Press>
      </View>
    </TouchableOpacity>
  );
};

export default memo(FloatingButton);

const NavigationTab = memo(({ onPress, color = colors.white, title, index, marginLeft }) => {
  return (
    <Ripple
      key={index}
      style={[styles.tab, { marginLeft }]}
      onPress={onPress}
    >
      <Typography
        type="medium"
        disabled
        size={16}
        color={color}>
        {title}
      </Typography>
    </Ripple>
  )
})


const styles = StyleSheet.create({
  buttonContainer: {
    justifyContent: 'center',
    borderRadius: 5,
    flex: 1,
  },
  backgroundImageContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
  },
  buttonIcon: {
    width: 30,
    height: 30,
    marginRight: 10,
  },
  mainContainer: {
    position: 'absolute',
    bottom: 0,
    borderRadius: 5,
    backgroundColor: '#00000030',
  },
  card: {
    width: '93%',
    alignSelf: 'center',
    marginVertical: 10,
  },
  tab: {
    width: '100%',
    height: 50,
    justifyContent: 'space-between',
    paddingHorizontal: 13,
    flexDirection: 'row',
    alignItems: 'center',
    zIndex: 1,
  },
  subtab: {
    width: '100%',
    marginBottom: 15,
    justifyContent: 'center',
    paddingLeft: 25,
    paddingVertical: 10,
    zIndex: 1,
  },
  drawer: {
    width: FULL_WIDTH * 0.8,
    height: FULL_HEIGHT * 0.65,
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: colors.inputBgColor,
    borderTopLeftRadius: 8,
    zIndex: 1,
  },
  linearGradient: {
    width: '100%',
    height: 1,
  },
  imageStyle: {
    width: '100%',
  },
});
