import {StyleSheet, Text, View} from 'react-native';
import React from 'react';
import colors from '../../Constants/colors';

import {LineChart} from 'react-native-chart-kit';
import {FULL_WIDTH} from '../../Constants/layout';
const ChartLine = () => {
  return (
    <>
      <LineChart
        data={{
          labels: ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni'],
          datasets: [
            {
              data: [
                Math.random() * 100,
                Math.random() * 100,
                Math.random() * 100,
                Math.random() * 100,
                Math.random() * 100,
                Math.random() * 100,
              ],
            },
          ],
        }}
        width={FULL_WIDTH - 20} // from react-native
        height={220}
        yAxisLabel={'Rp'}
        chartConfig={{
          backgroundColor: colors.inputBgColor,
          backgroundGradientFrom: colors.inputBgColor,
          backgroundGradientTo: colors.inputBgColor,
          decimalPlaces: 2, // optional, defaults to 2dp
          color: (opacity = 1) => `white`,
          labelColor: (opacity = 1) => `white`,
          style: {
            borderRadius: 10,
          },
        }}
        style={{
          borderRadius: 10,
        }}
      />
    </>
  );
};

export default ChartLine;

const styles = StyleSheet.create({});
