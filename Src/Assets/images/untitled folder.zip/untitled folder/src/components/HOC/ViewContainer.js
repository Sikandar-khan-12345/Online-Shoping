import {StyleSheet, SafeAreaView} from 'react-native';
import React from 'react';
import Container from './Container';
import colors from '../../Constants/colors';

const ViewContainer = ({
  children,
  backgroundColor = colors.bgcolor,
  style = {},
}) => {
  return (
    <Container>
      <SafeAreaView style={[{backgroundColor:'red'},containerStyle.container(backgroundColor), style]}>
        {children}
      </SafeAreaView>
    </Container>
  );
};

export default ViewContainer;

export const containerStyle = StyleSheet.create({
  container: backgroundColor => {
    return {flex: 1, backgroundColor};
  },
});
