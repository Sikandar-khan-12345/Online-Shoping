import { Platform, KeyboardAvoidingView, StyleSheet, ScrollView } from 'react-native';
import React from 'react';
import colors from '../../../utils/colors';
const keyboardVerticalOffset = Platform.OS === 'ios' ? 20 : 0;
const behavior = Platform.OS === 'ios' ? 'padding' : undefined
const FormContainer = ({
  children,
  backgroundColor = colors.white,
  style = {},
}) => {
  return (
    <KeyboardAvoidingView

      style={[{ flex: 1, backgroundColor }, styles.keyboard]}
      behavior={behavior}
      keyboardVerticalOffset={keyboardVerticalOffset}>
        {children}
    </KeyboardAvoidingView>
  );
};

export default FormContainer;
const styles = StyleSheet.create({
  keyboard: {
  },
});
