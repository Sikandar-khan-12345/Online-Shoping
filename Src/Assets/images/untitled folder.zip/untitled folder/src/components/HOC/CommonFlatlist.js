import { FlatList, View } from 'react-native';
import React from 'react';

const CommonFlatlist = ({
  renderitem,
  data,
  extradata,
  numColumns,
  contentStyle,
  columnWrapperStyle,
  horizontal = false,
  pagingEnabled = false,
  style,
  refreshControl,
  showsVerticalScrollIndicator = false,
  keyExtractor,
  onEndReached,
  onEndReachedThreshold,
  ListFooterComponent,
  ...props
}) => {
  return (
    // <View>
      <FlatList
        showsVerticalScrollIndicator={showsVerticalScrollIndicator}
        refreshControl={refreshControl}
        style={style}
        pagingEnabled={pagingEnabled}
        contentContainerStyle={contentStyle}
        renderItem={renderitem}
        data={data}
        extraData={extradata}
        numColumns={numColumns}
        columnWrapperStyle={columnWrapperStyle}
        horizontal={horizontal}
        showsHorizontalScrollIndicator={false}
        keyExtractor={keyExtractor}
        onEndReached={onEndReached}
        onEndReachedThreshold={onEndReachedThreshold}
        ListFooterComponent={ListFooterComponent}
        {...props}
      />
    // </View>
  );
};

export default CommonFlatlist;
