import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { CardStyleInterpolators, createStackNavigator } from '@react-navigation/stack'

const Stack = createStackNavigator();

const commonOptions = {
    headerShown: false,
    cardStyleInterpolator: CardStyleInterpolators.forHorizontalIOS
}

export const HomeStack = () => {
    return (
        <Stack.Navigator initialRouteName="myInfo">
            <Stack.Screen
                options={{ ...commonOptions }}
                name="myInfo"
                getComponent={() => require('../../screens/MyInfo').default}
            />
            <Stack.Screen options={{ ...commonOptions }} name="imageUpload"
                getComponent={() => require('../../screens/ImageUpload/ImageUpload').default}
            />
            <Stack.Screen options={{ ...commonOptions }} name="Registration2"
                getComponent={() => require('../../screens/registration').default}
            />
        </Stack.Navigator>
    )
}

export const AuthStack = () => {
    return (
        <Stack.Navigator initialRouteName="home">
            <Stack.Screen options={{ ...commonOptions }} name="home"
                getComponent={() => require('../../screens/HomeScreen').default}
            />
            <Stack.Screen options={{ ...commonOptions }} name="login"
                getComponent={() => require('../../screens/LoginScreen').default}
            />
            <Stack.Screen options={{ ...commonOptions }} name="signUp"
                getComponent={() => require('../../screens/SignUpScreen').default}
            />
            <Stack.Screen options={{ ...commonOptions }} name="SignUpUpdate"
                getComponent={() => require('../../screens/SignUpScreen').default}
            />
            <Stack.Screen options={{ ...commonOptions }} name="forget"
                getComponent={() => require('../../screens/ForgetPassword').default}
            />
            <Stack.Screen options={{ ...commonOptions }} name="mobileVerification"
                getComponent={() => require('../../screens/MobileVerification').default}
            />
            <Stack.Screen options={{ ...commonOptions }} name="Registration"
                getComponent={() => require('../../screens/registration').default}
            />
            <Stack.Screen options={{ ...commonOptions }} name="Intro"
                getComponent={() => require('../../screens/registration/Intro').default}
            />
            <Stack.Screen options={{ ...commonOptions }} name="T_C"
                getComponent={() => require('../../screens/CMS/T_C').default}
            />
            <Stack.Screen options={{ ...commonOptions }} name="PrivacyPolicy"
                getComponent={() => require('../../screens/CMS/PrivacyPolicy').default}
            />
        </Stack.Navigator>
    )
}



const styles = StyleSheet.create({})