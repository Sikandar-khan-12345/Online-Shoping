import { StyleSheet, Text, View } from 'react-native'
import React, { useEffect } from 'react'
import { NavigationContainer } from '@react-navigation/native'
import { AuthStack, HomeStack } from './StackNavigator'
import { useDispatch, useSelector } from 'react-redux'
import { EventRegister } from 'react-native-event-listeners'
import { updateAuth } from '../../features/authReducer'
import NetAlert from '../../Components/NetAlert'
import { checkProfilePending, navigationRef } from '../Constants'
const RootNavigation = () => {

  const isAuth = useSelector(store => store?.auth?.isAuth)
  const dispatch = useDispatch()
  useEffect(() => {
    EventRegister.on('updateIsAuth', () => {
      dispatch(updateAuth(false))
      toast.show('Unauthorized,please login again.')
    })
    return () => {
      EventRegister.removeAllListeners()
    }
  }, [])


  useEffect(() => {
    checkProfilePending()
  }, [navigationRef])

  return (
    <NavigationContainer ref={navigationRef}>
      {isAuth ? <HomeStack /> : <AuthStack />}
      <NetAlert />
    </NavigationContainer>
  )
}

export default RootNavigation