1. First install these packages 
   `react-redux`,`redux-persist` and `@reduxjs/toolkit` 

2. In your Root file (App.js) paste this code.

    import React from 'react';
    import { Provider } from 'react-redux';
    import { PersistGate } from 'redux-persist/es/integration/react';
    import { store, persistor } from 'import from store.js';

    const App = () => {
        return (
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    {/* your components go here */}
                </PersistGate>
            </Provider>
        );
    };

    export default App;

3. Now create your reducers like `exampleReducers.js` and create slices and initial states like this
   const exampleSlice = createSlice({
        name: 'example',
        initialState: {
           count: 0,
           userData:{}
        },
        reducers: {
            increment: state => {
                state.count += 1;
            },
            decrement: state => {
                state.count -= 1;
            },
            other : (state,action) => {
                state.userData = action.payload
            }
        }
   }); 

   export const { increment, decrement } = exampleSlice.actions;
   export default exampleSlice.reducer;
   
4. Import your reducers and redux hooks `useDispatch()` and  `useSelecter()`

   import { useDispatch, useSelector } from 'react-redux';
   import { increment, decrement, other } from './reducers/exampleReducer';
   
   -> To get values from reducers :-
        const count = useSelector(state => state.example.count);

   -> To set values in reducers :-
        const dispatch = useDispatch();
    `dispatch(increment())` or `dispatch(decrement())` or `dispatch(other(data))`  




