import { combineReducers } from '@reduxjs/toolkit';
import { persistReducer } from 'redux-persist';
import storage from '@react-native-async-storage/async-storage';
/*
  import your reducers like this
*/
import exampleReducer from './exampleReducer';
const exampleReducer1PersistConfig = {
    key: 'exampleReducer1',
    storage,
};

const rootReducer = combineReducers({
    /**
     * Use them  here 
    */
    example: persistReducer(exampleReducer1PersistConfig,exampleReducer),
});

export default rootReducer;