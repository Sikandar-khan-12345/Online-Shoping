import { configureStore } from '@reduxjs/toolkit';
import { persistStore } from 'redux-persist';
import rootReducer from './reducers';

const store = configureStore({
  reducer: rootReducer,
});

const persistor = persistStore(store, null, () => {
    // This callback will be called once the persistence has completed.
    console.log('Persistence completed for exampleReducer1');
});

export { store, persistor };
