import { View, Text, ScrollView, Pressable, TextInput } from "react-native";
import React, { useEffect, useState } from "react";
import Header from "../Components/Header/Header";
import OtpInputs from "react-native-otp-inputs";
import PrimaryButton from "../Components/Button/PrimaryButton";
import Loader from "../Components/Loader/Loader";
import { useToast } from "react-native-toast-notifications";
import axios from "axios";
import { useSelector } from "react-redux";
import { useNavigation } from "@react-navigation/native";
import TextField from "../Components/Textfield/TextField";
import { API, POST } from "../utils/Backend/backend";
import { GET_TOKENS } from "../utils/Backend/end_points";
import AsyncStorage from "@react-native-async-storage/async-storage";
import variables from "../utils/variables";
import colors from "../utils/colors";
import Typography from "../src/components/UI/Typography";
import { TouchableOpacity } from "react-native-gesture-handler";


const MobileVerification = ({ route }) => {
  const email = route.params?.email
  const password = route.params?.password
  const navigation = useNavigation();
  const toast = useToast();
  const [otp, setOtp] = useState("");
  const [loading, setLoading] = useState(true);
  const [token, setToken] = useState('')
  const verifyEmail = useSelector((store) => store?.user?.email || "");
  useEffect(() => {
    getToken()
  }, [])

  const getToken = () => {
    const data = new FormData()
    data.append('email', email)
    data.append('password', password)
    // let data = JSON.stringify({
    //   email,
    //   password
    // })
    var config = {
      method: 'post',
      url: API + GET_TOKENS,
      headers: {
        'Content-Type': 'multipart/form-data'
      },
      data: data
    };
    axios(config)
      .then(async (response) => {
        setLoading(false)
        if (response.data) {
          await AsyncStorage.setItem(variables.TOKEN, response.data?.access)
          setToken(response.data?.access)
        }
      })
      .catch(function (error) {
        setLoading(false)
        console.log(error);
      });
  }
  const otpSubmitHandler = () => {
    // navigation.navigate('Intro')
    // return
    if (otp?.length !== 6) {
      toast.show("Please Enter OTP", {
        type: "danger",
      });
    } else {
      setLoading(true);
      let payload = {
        email: verifyEmail,
        otp: otp,
      };
      POST(
        API + 'verify-otp',
        payload,
        success => {
          setLoading(false)
          navigation.navigate('Intro')
        },
        err => {
          setLoading(false)
          // console.log('------', err.message)
          toast.show(
            err?.message || 'Incorrect otp entered! Please try again.' || "Something Went wrong , try again later...",
            {
              type: "danger",
            }
          );
        },
        fail => {
          setLoading(false)
          toast.show(
            fail?.message || "Something Went wrong , try again later...",
            {
              type: "danger",
            }
          );
        },
        {
          'Authorization': `Bearer ${token}`
        }
      )
      // axios
      //   .post("/verify-otp", payload)
      //   .then((res) => {
      //     setLoading(false);
      //     console.log('-----------------hfhfhghgfghfhg-------', res);
      //     if (res?.data?.success) {
      //       // navigation.navigate('login')
      //       // navigation.navigate('Registration')
      //     } else {
      //       toast.show(
      //         res?.data?.message || "Something Went wrong , try again later...",
      //         {
      //           type: "danger",
      //         }
      //       );
      //     }
      //   })
      //   .catch((e) => {
      //     setLoading(false);
      //     toast.show(
      //       e?.response?.data?.message || "Something Went wrong , try again later...",
      //       {
      //         type: "danger",
      //       }
      //     );
      //   });
    }
  };
  return (
    <View className="h-[100%]">
      {loading && <Loader />}
      <Header
        leftIcon={'back'}
        leftIconColor={colors.white}
        title="Verify Your Account" />
      <ScrollView className="bg-gray-200 p-4    ">
        <Text className="mt-5 text-center font-bold text-lg">
          OTP has been sent to your email{" "}
        </Text>
        <Text style={{ color: colors.primary }} className=" text-center font-bold text-lg">
          {verifyEmail}
        </Text>
        <Text className="mb-5 text-center font-bold">
          Please enter the OTP
        </Text>
        <View className="flex align-middle">
          {/* <TextInput
            onChangeText={(code) => setOtp(code)}
            value={otp}
            style={{ backgroundColor: 'red' }}
          /> */}
          <OtpInputs
            handleChange={(code) => setOtp(code)}
            numberOfInputs={6}
            inputStyles={{
              backgroundColor: "#FFFFFf",
              padding: 10,
              marginRight: 5,
              width: 40,
              textAlign: "center",
            }}
            style={{
              justifyContent: "center",
              display: "flex",
              flexDirection: "row",
            }}
          />
        </View>
        <View className="mt-4">
          {/* <Pressable
            onPress={resendOtpHandler}
            className="text-center underline"
          >
            <Text style={{textAlign:'center',textDecorationLine:'underline',color:colors.primary,fontWeight:'900'}}>Resend Otp</Text>
          </Pressable> */}
          <ResentOtpTimer email={email} token={token} />
        </View>
        <PrimaryButton
          disabled={otp.length !== 6}
          onClick={otpSubmitHandler}
          rootClass="mt-10"
          title="Submit"
          style={{ backgroundColor: otp.length !== 6 ? colors.primary + '90' : colors.primary }}
        />
      </ScrollView>
    </View>
  );
};


const ResentOtpTimer = ({ email, token }) => {
  const [timerCount, setTimer] = useState(30);
  const [timerRef, setTimerRef] = useState()
  const timer = () => {
    setTimer(true)
    setTimer(45)
    resendOtp()
    let interval = setInterval(() => {
      setTimer(lastTimerCount => {
        lastTimerCount <= 1 && clearInterval(interval);
        return lastTimerCount - 1;
      });
    }, 1000);
    setTimerRef(interval)
  }

  const resendOtp = () => {
    let payload = {
      email,
    };
    axios
      .post("/resend-otp", payload, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })
      .then((res) => {
        setLoading(false);
        if (res?.data?.success) {
          toast.show(
            res?.data?.message || "Something Went wrong , try again later...",
            {
              type: "success",
            }
          );
        } else {
          toast.show(
            res?.data?.message || "Something Went wrong , try again later...",
            {
              type: "danger",
            }
          );
        }
      })
      .catch((e) => {
        setLoading(false);
        toast.show(
          e?.response?.data?.message || "Something Went wrong , try again later...",
          {
            type: "danger",
          }
        );
      });
  };

  useEffect(() => {
    setTimer(true)
    setTimer(45)
    let interval = setInterval(() => {
      setTimer(lastTimerCount => {
        lastTimerCount <= 1 && clearInterval(interval);
        return lastTimerCount - 1;
      });
    }, 1000);
    setTimerRef(interval)
    return () => clearInterval(timerRef);
  }, []);
  return (
    <>
      {timerCount > 0 ? (
        <Typography
          style={{ textAlign: 'center', color: colors.primary, fontWeight: '900' }}
          type="medium"
          size={14} color={colors.secondary}>
          {' '}0:{timerCount.toString().length < 2 && '0'}{timerCount}
        </Typography>
      ) : (
        <TouchableOpacity onPress={timer}>
          <Typography type="medium" size={14} color={colors.secondary} textAlign='center'>
            <Text style={{ textAlign: 'center', textDecorationLine: 'underline', color: colors.primary, fontWeight: '900' }}>Resend OTP</Text>
          </Typography>
        </TouchableOpacity>
      )
      }

    </>
  )
}


export default MobileVerification;

