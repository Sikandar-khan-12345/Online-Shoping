import { View, Text, ScrollView } from 'react-native'
import React from 'react'
import Header from '../Components/Header/Header'
import colors from '../utils/colors'

const ForgetPassword = () => {
  return (
    <View className="h-[100%]">
      <Header leftIcon={'back'} leftIconColor={colors.white} title="Forgot Password" />
      <ScrollView className="bg-gray-200 p-4   ">

      </ScrollView>
    </View>
  )
}

export default ForgetPassword