import {
  View,
  Text,
  ScrollView,
  Pressable,
  SafeAreaViewBase,
} from "react-native";
import React, { useState } from "react";
import TextField from "../Components/Textfield/TextField";
import PrimaryButton from "../Components/Button/PrimaryButton";
import Header from "../Components/Header/Header";
import { useNavigation } from "@react-navigation/native";
import { useDispatch } from "react-redux";
import { setVerifyEmail, signInUser } from "../features/userSlice";
import Loader from "../Components/Loader/Loader";
import { useToast } from "react-native-toast-notifications";
import { formRequiredValidationErrorGen } from "../utils/utils";
import { RequiredLoginFields } from "../utils/data";
import { POST_FORMDATA, API, POST } from "../utils/Backend/backend";
import { LOGIN } from "../utils/Backend/end_points";
import AsyncStorage from "@react-native-async-storage/async-storage";
import variables from "../utils/variables";
import { updateAuth } from "../features/authReducer";
import colors from "../utils/colors";

const LoginScreen = () => {
  const toast = useToast();
  const [errors, setErrors] = useState({});

  const [values, setValues] = useState({
    email: "pabbathinagarjuna4@gmail.com",
    password: "11111111",
  });
  const [loading, setLoading] = useState(false);

  const cb = async (success, data) => {
    setLoading(false);
    if (success) {
      dispatch(setVerifyEmail(values?.email || ""));
      console.log('daaaaaaaa', data);
      toast.show(`${data?.message}`);
      if (data?.email_verified == false) {
        navigation.navigate("mobileVerification", { email: values.email, password: values.password });
      } else {
        await AsyncStorage.setItem(variables.USER_DATA, JSON.stringify(data?.data?.user))
        await AsyncStorage.setItem(variables.TOKEN, data?.data?.access_token)
        // navigation.navigate("myInfo");
        dispatch(updateAuth(true))
      }
    } else {
      toast.show(data?.message || "Invalid credentials", {
        type: "danger",
      });
    }
  };
  const dispatch = useDispatch();
  const loginClickHandler = async () => {
    let [isErrors, errors] = formRequiredValidationErrorGen(
      values,
      RequiredLoginFields
    );
    if (isErrors) {
      setErrors(errors);
      return;
    }
    setLoading(true);
    dispatch(signInUser({ payload: values, cb: cb }));
    // let formData = {
    //   email:values?.email,
    //   password:values?.password,
    // }
    // POST(
    //   API+LOGIN,
    //   formData,
    //   async success=>{
    //     setLoading(false)
    //     console.log('-------',success);
    //     if (success.status==true) {

    //     }
    //     dispatch(setVerifyEmail(values?.email || ""));
    //     if (success?.data?.email_verified == false) {
    //       navigation.navigate("mobileVerification");
    //     } else {
    //       navigation.navigate("myInfo");
    //     }
    //   },
    //   err=>{
    //     setLoading(false)
    //     console.log('---errr----',err);
    //     toast.show(err?.message || "Invalid credentials", {
    //       type: "danger",
    //     });
    //   },
    //   fail=>{
    //     setLoading(false)
    //     console.log('---errrr----',fail);
    //     toast.show(fail?.message || "Check network,Try again.");
    //   }
    // )
  };
  const ForgotClickHandler = () => {
    navigation.navigate("forget");
  };
  const signUpClickHandler = () => {
    navigation.navigate("signUp");
  };

  const navigation = useNavigation();
  return (
    <View className="h-[100%] bg-gray-200  ">
      {loading && <Loader />}
      <Header leftIcon={'back'} leftIconColor={colors.white} title="Welcome back" />
      <ScrollView className="p-4   ">
        <Text className=" pt-4 font-bold font-[blinker] text-xl ml-2">Login to Gahoi Rishtey</Text>
        <Text className=" pt-1 font-light font-[blinker] text-sm ml-2">We hope you get lucky today!</Text>
        <View className="pt-10">
          <TextField
            label="Email or Phone"
            placeholder="Email or Phone"
            type="text"
            values={values}
            setValues={setValues}
            name="email"
            errors={errors}
            setErrors={setErrors}
          />
          <TextField
            label="Password"
            placeholder="Password"
            type="password"
            values={values}
            setValues={setValues}
            name="password"
            errors={errors}
            setErrors={setErrors}
          />
          <Pressable onPress={ForgotClickHandler}>
            <Text style={{ textAlign: 'right' }} className=" mb-2 mt-2 font-[blinker] pl-0.5 flex flex-row justify-end font-semibold text-primary">
              Forgot Password?
            </Text>
          </Pressable>
          <PrimaryButton
            rootClass="mt-6"
            title={"Login"}
            onClick={loginClickHandler}
          />
        </View>
      </ScrollView>

      <View className="mt-auto mb-6 flex flex-row align-middle justify-center">
        <Text className=" font-[blinker] ">New to Gahoi Rishtey? </Text>
        <Pressable className="" onPress={signUpClickHandler}>
          <Text className="font-[blinker] text-primary font-semibold"> Register Now!</Text>

        </Pressable>
      </View>
    </View>
  );
};

export default LoginScreen;
