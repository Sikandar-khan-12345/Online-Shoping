import * as React from "react";
import { StatusBar } from "expo-status-bar";
import { ImageBackground, Text, View, BackHandler } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { StyleSheet } from "react-native";
import PrimaryButton from "../../Components/Button/PrimaryButton";
import Icons from "../../src/Constants/Icons";
import { useDispatch } from "react-redux";
import { updateAuth } from "../../features/authReducer";
import { FocusAwareStatusBar } from "../../Components/Ui/FocusAwareStatusBar";
import colors from "../../utils/colors";

const HomeScreen = ({ route }) => {
  const navigation = useNavigation();
  const dispatch = useDispatch()
  const loginClickHandler = () => {
    // navigation.navigate("myInfo");
    dispatch(updateAuth(true))
  };
  const signupClickHandler = () => {
    navigation.navigate("Registration");
  };

  React.useEffect(() => {
    const backhandler = BackHandler.addEventListener('hardwareBackPress', () => {
      BackHandler.exitApp()
      return true
    })
    return () => backhandler.remove()
  }, [])

  return (
    <ImageBackground
      source={Icons.homeBG}
      style={styles.screen}
    >
      <FocusAwareStatusBar backgroundColor={colors.black} />
      <View
        style={styles.screen}
        className="pt-10 pl-5 pr-5 pb-7 flex h-screen"
      >
        <Text className="text-xl font-[blinker] font-bold text-white ">
          Gahoi Rishtey
        </Text>

        <View className="mt-auto  ">
          <View className='flex h-14'>
            <PrimaryButton
              title={"Complete Your Profile"}
              onClick={signupClickHandler}
              rootClass="flex-1 "
            />
          </View>

          {/* <View className="flex flex-row mt-5">
            <PrimaryButton
              title={"I'll will do it later"}
              onClick={loginClickHandler}
              rootClass="flex-1"
              isOutline
            />
          </View> */}
        </View>
      </View>
    </ImageBackground>
  );
};

export default HomeScreen;

const styles = StyleSheet.create({
  screen: {
    height: "100%",
  },
});
