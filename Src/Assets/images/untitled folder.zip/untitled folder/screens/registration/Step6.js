import { ScrollView, StyleSheet, Text, View } from 'react-native'
import React, { forwardRef, memo, useEffect, useImperativeHandle, useState } from 'react'
import { makeDropDownData } from '../../utils/data';
import TextField from '../../Components/Textfield/TextField';
import SelectInput from '../../Components/Textfield/SelectInput';
import { FULL_WIDTH } from '../../utils/layout';
import AsyncStorage from '@react-native-async-storage/async-storage';
import variables from '../../utils/variables';
import { useIsFocused } from '@react-navigation/native';
import axios from 'axios';
import { API, POST_FORMDATA, REQUEST_HANDLER } from '../../utils/Backend/backend';
import { isValidForm } from '../../utils/utils';
import { validators } from '../../utils/Validation';
import PrimaryButton from '../../Components/Button/PrimaryButton';
import Loader from '../../Components/Loader/Loader';
import SelectPicker from '../../Components/SelectPicker';
import { useDispatch, useSelector } from 'react-redux';
import { setUserProfileInfo } from '../../features/userSlice';
import { useNavigation } from '@react-navigation/native'
const Step6 = ({ currentIndex, isUpdate, editable, data, next = () => { } }, ref) => {
  const dipatch = useDispatch()
  const navigation = useNavigation()
  const userProfileInfo = useSelector((store) => store?.user?.userProfileInfo || {});
  const [values, setValues] = useState({});
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false)
  const [options, setOptions] = useState({
    profession: makeDropDownData([]),
    aakana: makeDropDownData([]),
    house: makeDropDownData([]),
    car: makeDropDownData([]),
  });
  useImperativeHandle(ref, () => {
    return {
      values,
      setValues,
      errors,
      setErrors,
      index: 5
    };
  }, [values, errors])
  const getConstants = async () => {
    let dataString = await AsyncStorage.getItem(variables.CONSTANT)
    let aakanaString = await AsyncStorage.getItem('aakana')
    let aakana = []
    if (aakanaString) {
      aakana = [...JSON.parse(aakanaString)]
    }
    if (dataString) {
      let data = JSON.parse(dataString)
      setOptions({
        profession: data?.professionLOV,
        aakana: aakana,
        house: data?.houseLOV,
        car: data?.carLOV,
      })
    }
  }
  const isFocused = useIsFocused()
  useEffect(() => {
    getConstants()
  }, [isFocused, currentIndex])

  const fetchInitialOptions = async () => {
    setLoading(true);
    try {
      const res = await Promise.all([
        axios.get("./countries"),
        axios.get("./religions"),
        axios.get("./aakanas"),
      ]);
      const data = res.map((res) => res.data);
      let optionsUpdate = { ...options };
      data.forEach((res, i) => {
        console.log(res);
        if (res.success) {
          if (i === 0 && Array.isArray(res?.data)) {
            optionsUpdate.country = res?.data;
          } else if (i === 1 && Array.isArray(res?.data)) {
            optionsUpdate.religion = res?.data;
          } else if (i === 2 && Array.isArray(res?.data)) {
            optionsUpdate.aakana = res?.data;
          }
        }
      });
      console.log(optionsUpdate);
      setOptions(optionsUpdate);
      setLoading(false);
    } catch (e) {
      console.log(e);
      toast.show(e?.message || "Failed to Fetch Options", {
        type: "danger",
      });
      setLoading(false);
    }
  };

  useEffect(() => {
    if (data) {
      setValues(data)
    }
  }, [data])

  useEffect(() => {
    fetchInitialOptions()
    // getValues()
  }, [])

  const getValues = async () => {
    await REQUEST_HANDLER(
      'PATCH',
      API + `profile?page=familyInfo`,
      {},
      res => {
        print('res--familyInfo----', res)
        setValues(res?.familyInfo)
      },
      err => {

        print('errr--familyInfo----', err)

        toast.show(`${err?.message || "Something went wrong"}`, { type: 'danger' })


      },
      fail => {
        print('fail--religiousInfo----', fail)
        toast.show('Check network,Try again.', { type: 'danger' })
      }
    )
  }

  const submit = async () => {
    let step1form = {
      // father_name: validators.checkRequire('Father name', values?.father_name),
      //     father_profession: validators.checkRequire('Father profession', values?.father_profession),
      //     mother_name: validators.checkRequire('Mother name', values?.mother_name),
      //     mother_profession: validators.checkRequire('Mother profession', values?.mother_profession),
      //     married_brother: validators.checkRequire('Married brother', values?.married_brother),
      //     unmarried_brother: validators.checkRequire('Unmarried brother', values?.unmarried_brother),
      //     married_sister: validators.checkRequire('Married sister', values?.married_sister),
      //     unmarried_sister: validators.checkRequire('Unmarried sister', values?.unmarried_sister),
      //     maternal_uncle_name: validators.checkRequire('Maternal uncle name', values?.maternal_uncle_name),
      //     maternal_uncle_aakana: validators.checkRequire('Maternal uncle aakana', values?.maternal_uncle_aakana),
      //     house: validators.checkRequire('House', values?.house),
      //     car: validators.checkRequire('Car', values?.car),
    }
    if (isValidForm(step1form)) {
      setLoading(true)
      const formData = {}
      // const formData = new FormData()
      for (const key in values) {
        if (typeof values[key] === 'object') {
          formData[key] = values[key]?.value || values[key]
        } else {
          formData[key] = values[key]
        }
      }
      await REQUEST_HANDLER(
        editable ? "PATCH" : "POST",
        API + `profile?page=familyInfo`,
        JSON.stringify(formData),
        async success => {
          let obj = { ...userProfileInfo }
          obj.familyInfo = formData
          dipatch(setUserProfileInfo(obj))
          toast.show(`${success.message}`)
          await AsyncStorage.setItem(variables.USER_PROFILE_INFO, JSON.stringify(obj))
          if (isUpdate) {
            navigation.goBack()
          } else {
            next()
          }
          setLoading(false)
        },
        err => {
          toast.show(`${err?.message || 'Something went wrong'}`)
          setLoading(false)
        },
        fail => {
          toast.show(`${fail?.message || 'Something went wrong'}`)
          setLoading(false)
        },
        {
          'Content-Type': 'application/json'
        }
      )
    } else {
      let obj = {}
      for (const field in step1form) {
        if (Object.hasOwnProperty.call(step1form, field)) {
          obj[field] = [step1form[field]]
        }
      }
      setErrors(obj)
    }
  }

  return (
    <View style={{ width: FULL_WIDTH }} className="h-[100%] bg-gray-200">
      {loading && <Loader />}
      <ScrollView className=" px-4  pb-5 ">
        <View style={{ height: 20 }} />
        <TextField
          label="Father's name"
          placeholder="Father's name"
          name="father_name"
          values={values}
          setValues={setValues}
          type="Text"
          errors={errors}
          setErrors={setErrors}
        />
        <SelectPicker
          rootClassName=""
          label="Father's profession"
          placeholder="Select profession"
          name="father_profession"
          nesting={true}
          values={values}
          setValues={setValues}
          options={options.profession}
          errors={errors}
          setErrors={setErrors}
        />
        <TextField
          label="Mother's name"
          placeholder="Mother's name"
          name="mother_name"
          values={values}
          setValues={setValues}
          type="Text"
          errors={errors}
          setErrors={setErrors}
        />
        <SelectPicker
          rootClassName=""
          label="Mother's profession"
          placeholder="Select profession"
          name="mother_profession"
          nesting={true}
          values={values}
          setValues={setValues}
          options={options.profession}
          errors={errors}
          setErrors={setErrors}
        />
        <TextField
          label="Married brother"
          placeholder="Married brother"
          name="married_brother"
          values={values}
          setValues={setValues}
          type="number"
          keyboardType={'numeric'}
          maxLength={2}
          errors={errors}
          setErrors={setErrors}
        />
        <TextField
          label="Unmarried brother"
          placeholder="Unmarried brother"
          name="unmarried_brother"
          values={values}
          setValues={setValues}
          type="number"
          keyboardType={'numeric'}
          maxLength={2}
          errors={errors}
          setErrors={setErrors}
        />
        <TextField
          label="Married sister"
          placeholder="Married sister"
          name="married_sister"
          values={values}
          keyboardType={'numeric'}
          setValues={setValues}
          type="number"

          maxLength={2}
          errors={errors}
          setErrors={setErrors}
        />
        <TextField
          label="Unmarried sister"
          placeholder="Unmarried sister"
          name="unmarried_sister"
          values={values}
          keyboardType={'numeric'}
          setValues={setValues}
          type="number"
          maxLength={2}
          errors={errors}
          setErrors={setErrors}
        />
        <TextField
          label="Maternal uncle name"
          placeholder="Maternal uncle name"
          name="maternal_uncle_name"
          values={values}
          setValues={setValues}
          type="Text"
          errors={errors}
          setErrors={setErrors}
        />
        <SelectPicker
          rootClassName=""
          label="Maternal uncle aakana"
          placeholder="Select Maternal uncle's aakana"
          name="maternal_uncle_aakana"
          values={values}
          setValues={setValues}
          options={options.aakana}
          errors={errors}
          setErrors={setErrors}
        />
        <SelectPicker
          rootClassName=""
          label="House"
          placeholder="Select house"
          name="house"
          values={values}
          setValues={setValues}
          options={makeDropDownData(options.house)}
          errors={errors}
          setErrors={setErrors}
        />
        <SelectPicker
          rootClassName=""
          label="Car"
          placeholder="Select car"
          name="car"
          values={values}
          setValues={setValues}
          options={makeDropDownData(options.car)}
          errors={errors}
          setErrors={setErrors}
        />
        <PrimaryButton
          onClick={submit}
          title={isUpdate ? "Update" : "Next"}
        />
        <View style={{ height: 55, backgroundColor: 'transparent' }} />
      </ScrollView>
    </View>
  )
}

export default memo(forwardRef(Step6))

const styles = StyleSheet.create({})