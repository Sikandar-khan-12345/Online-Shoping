import { ScrollView, StyleSheet, Text, View } from 'react-native'
import React, { forwardRef, memo, useEffect, useImperativeHandle, useState } from 'react'
import TextField from '../../Components/Textfield/TextField';
import SelectInput from '../../Components/Textfield/SelectInput';
import { makeDropDownData, yesNoOptions } from '../../utils/data';
import { FULL_WIDTH } from '../../utils/layout';
import { useNavigation } from '@react-navigation/native'
import AsyncStorage from '@react-native-async-storage/async-storage';
import variables from '../../utils/variables';
import { useIsFocused } from '@react-navigation/native';
import { API, POST_FORMDATA, REQUEST_HANDLER } from '../../utils/Backend/backend';
import { validators } from '../../utils/Validation';
import { isValidForm } from '../../utils/utils';
import PrimaryButton from '../../Components/Button/PrimaryButton';
import Loader from '../../Components/Loader/Loader';
import SelectPicker from '../../Components/SelectPicker';
import axios from 'axios';
import { useDispatch, useSelector } from 'react-redux';
import { setUserProfileInfo } from '../../features/userSlice';
import { updateAuth } from '../../features/authReducer';
import Dropdown from '../../Components/Ui/Dropdown';
import { removePendingStatus } from '../../src/Constants';

const Step7 = ({ isUpdate, currentIndex, editable, data, next = () => { } }, ref) => {
  const dipatch = useDispatch()
  const userProfileInfo = useSelector((store) => store?.user?.userProfileInfo || {});
  const navigation = useNavigation()
  const [values, setValues] = useState({});
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(true)
  const [options, setOptions] = useState({
    profession: makeDropDownData([]),
    height: makeDropDownData([]),
    marital_status: makeDropDownData([]),
    diet: makeDropDownData([]),
    yesNO: yesNoOptions,
  });

  useImperativeHandle(ref, () => {
    return {
      values,
      setValues,
      errors,
      setErrors,
      index: 6
    };
  }, [values, errors])

  const getConstants = async () => {
    let dataString = await AsyncStorage.getItem(variables.CONSTANT)
    if (dataString) {
      let data = JSON.parse(dataString)
      let obj = {
        // ...options,
        height: data?.heightLOV,
        marital_status: data?.maritalStatusLOV,
        diet: data?.dietLOV,
        yesNO: yesNoOptions,
        profession: data?.professionLOV,
      }
      setOptions(obj)
      return obj
    }
  }
  const isFocused = useIsFocused()
  useEffect(() => {
    getConstants()
  }, [isFocused, currentIndex])
  useEffect(() => {
    if (data) {
      setValues(data)
    }
  }, [data])

  const submit = async () => {
    let step1form = {
      // age: validators.checkRequire('Age', values?.age),
      // height: validators.checkRequire('Height', values?.height),
      // marital_status: validators.checkRequire('Marital status', values?.marital_status),
      // profession: validators.checkRequire('Profession', values?.profession),
      // state: validators.checkRequire('State', values?.state),
      // city: validators.checkRequire('City', values?.city),
      // drinking: validators.checkRequire('Drinking', values?.drinking),
      // smoking: validators.checkRequire('Smoking', values?.smoking),
      // diet: validators.checkRequire('Diet', values?.diet),
    }
    if (isValidForm(step1form)) {
      setLoading(true)
      const formData = {}
      // const formData = new FormData()
      for (const key in values) {
        if (typeof values[key] === 'object') {
          formData[key] = values[key]?.value || values[key]
        } else {
          formData[key] = values[key]
        }
      }
      await REQUEST_HANDLER(
        editable ? "PATCH" : "POST",
        API + `profile?page=preferenceInfo`,
        JSON.stringify(formData),
        async success => {

          let obj = { ...userProfileInfo }
          obj.preferenceInfo = formData
          dipatch(setUserProfileInfo(obj))
          if (isUpdate) {
            navigation.goBack()
          } else {
            dipatch(updateAuth(true))
            next(false)
            removePendingStatus()
          }
          await AsyncStorage.setItem(variables.USER_PROFILE_INFO, JSON.stringify(obj))
          // navigation.navigate('myInfo')
          toast.show(`${success.message}`)
          setLoading(false)
        },
        err => {
          toast.show(`${err?.message || 'Something went wrong'}`)
          setLoading(false)
        },
        fail => {
          toast.show(`${fail?.message || 'Something went wrong'}`)
          setLoading(false)
        },
        {
          'Content-Type': "application/json"
        }
      )
    } else {
      let obj = {}
      for (const field in step1form) {
        if (Object.hasOwnProperty.call(step1form, field)) {
          obj[field] = [step1form[field]]
        }
      }
      setErrors(obj)
    }
  }


  const fetchInitialOptions = async () => {
    setLoading(true);
    try {
      const res = await Promise.all([
        axios.get("./countries")
      ]);
      const data = res.map((res) => res.data);
      let optionsUpdate = options;
      data.forEach((res, i) => {
        console.log(res);
        if (res.success) {
          if (i === 0 && Array.isArray(res?.data)) {
            optionsUpdate.country = res?.data;
          }
        }
      });
      console.log(optionsUpdate);
      setOptions(optionsUpdate);
      setLoading(false);
    } catch (e) {
      console.log(e);
      toast.show(e?.message || "Failed to Fetch Options", {
        type: "danger",
      });
      setLoading(false);
    }
  };

  const CatchErrorHandler = (e, type) => {
    console.log('----------', type, e);
  };
  const dropdwonResponseHandler = (data, optionsName) => {
    setLoading(false);
    if (data?.success) {
      if (Array.isArray(data?.data)) {
        let obj = { ...options }
        obj[optionsName] = data?.data
        setOptions(obj);
      }
    } else {
    }

    // console.log(res);
  };
  const fetchStatesByCountry = (country) => {
    if (!country) {
      return;
    }
    setLoading(true);
    axios
      .get(`/statesForCountry?country_label=India`)
      .then((res) => {
        dropdwonResponseHandler(res?.data, "state");
      })

      .catch((e) => CatchErrorHandler(e, 'state'));
  };
  const fetchCitiesByState = (state) => {
    if (!state) {
      return;
    }
    setLoading(true);
    axios
      .get(`/citiesForState?state_label=${state?.value}`)
      .then((res) => {
        dropdwonResponseHandler(res?.data, "city");
      })
      .catch((e) => CatchErrorHandler(e, 'city'));
  };
  useEffect(() => {
    if (isFocused) {
      fetchStatesByCountry('India');
    }
  }, [isFocused]);


  return (
    <View style={{ width: FULL_WIDTH }} className="h-[100%] bg-gray-200">
      {loading && <Loader />}
      <ScrollView className=" px-4  pb-5 ">
        <View style={{ height: 20 }} />
        <TextField
          label="Age"
          placeholder="Age"
          name="age"
          values={values}
          setValues={setValues}
          type="number"
          keyboardType={'numeric'}
          errors={errors}
          setErrors={setErrors}
        />
        <SelectPicker
          rootClassName=""
          label="Height"
          placeholder="Select height"
          name="height"
          values={values}
          setValues={setValues}
          options={makeDropDownData(options.height)}
          errors={errors}
          setErrors={setErrors}
        />
        <SelectPicker
          rootClassName=""
          label="Marital status"
          placeholder="Select marital status"
          name="marital_status"
          values={values}
          setValues={setValues}
          options={makeDropDownData(options.marital_status)}
          errors={errors}
          setErrors={setErrors}
        />
        <SelectPicker
          rootClassName=""
          label="Profession"
          placeholder="Select profession"
          name="profession"
          nesting={true}
          values={values}
          setValues={setValues}
          options={options.profession}
          errors={errors}
          setErrors={setErrors}
        />
        <SelectPicker
          label="State"
          placeholder="State"
          name="state"
          values={values}
          setValues={setValues}
          type="Text"
          options={options?.state}
          onChange={fetchCitiesByState}
          errors={errors}
          setErrors={setErrors}
        />
        <SelectPicker
          label="City"
          placeholder="City"
          name="city"
          values={values}
          setValues={setValues}
          type="Text"
          errors={errors}
          options={options?.city}
          setErrors={setErrors}
        />
        <Dropdown
          rootClassName=""
          label="Drinking"
          placeholder="Select Drinking"
          name="drinking"
          values={values}
          setValues={setValues}
          options={options.yesNO}
          errors={errors}
          setErrors={setErrors}
        />
        <Dropdown
          rootClassName=""
          label="Smoking"
          placeholder="Select smoking"
          name="smoking"
          values={values}
          setValues={setValues}
          options={options.yesNO}
          errors={errors}
          setErrors={setErrors}
        />
        <SelectPicker
          rootClassName=""
          label="Diet"
          placeholder="Select diet"
          name="diet"
          values={values}
          setValues={setValues}
          options={makeDropDownData(options.diet)}
          errors={errors}
          setErrors={setErrors}
        />
        <PrimaryButton
          onClick={submit}
          title={isUpdate ? "Update" : "Next"}
        />
        <View style={{ height: 55, backgroundColor: 'transparent' }} />
      </ScrollView>
    </View>
  )
}

export default memo(forwardRef(Step7))

const styles = StyleSheet.create({})