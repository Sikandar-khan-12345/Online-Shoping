import { ScrollView, StyleSheet, Text, View } from 'react-native'
import React, { forwardRef, memo, useEffect, useImperativeHandle, useState } from 'react'
import SelectInput from '../../Components/Textfield/SelectInput'
import { makeDropDownData } from '../../utils/data';
import { FULL_WIDTH } from '../../utils/layout';
import AsyncStorage from '@react-native-async-storage/async-storage';
import variables from '../../utils/variables';
import { useIsFocused, useNavigation } from '@react-navigation/native';
import TextField from '../../Components/Textfield/TextField';
import { API, POST_FORMDATA, REQUEST_HANDLER } from '../../utils/Backend/backend';
import { validators } from '../../utils/Validation';
import PrimaryButton from '../../Components/Button/PrimaryButton';
import { isValidForm } from '../../utils/utils';
import Loader from '../../Components/Loader/Loader';
import SelectPicker from '../../Components/SelectPicker';
import { useDispatch, useSelector } from 'react-redux';
import { setUserProfileInfo } from '../../features/userSlice';

const Step2 = ({ currentIndex, isUpdate, data, editable, next = () => { } }, ref) => {
  const dipatch = useDispatch()
  const navigation = useNavigation()
  const userProfileInfo = useSelector((store) => store?.user?.userProfileInfo || {});
  const [values, setValues] = useState({});
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false)
  const [options, setOptions] = useState({
    marital_status: makeDropDownData([]),
    complexion: makeDropDownData([]),
    height: makeDropDownData([]),
    weight: makeDropDownData([]),
    diet: makeDropDownData([]),
    disability: makeDropDownData([]),
  });
  useImperativeHandle(ref, () => {
    return {
      values,
      setValues,
      errors,
      setErrors: (e) => setErrors(e),
      index: 1
    };
  }, [values, errors, currentIndex]);
  const getConstants = async () => {
    let dataString = await AsyncStorage.getItem(variables.CONSTANT)
    if (dataString) {
      let data = JSON.parse(dataString)
      setOptions({
        complexion: data?.complexionLOV,
        height: data?.heightLOV,
        weight: [],
        diet: data?.dietLOV,
        disability: data?.disabilityLOV,
        marital_status: data?.maritalStatusLOV,
      })
    }
  }
  useEffect(() => {
    if (typeof data === 'object') {
      setValues(data)
    }
  }, [data])

  const isFocused = useIsFocused()
  useEffect(() => {
    getConstants()
  }, [isFocused, currentIndex])
  const submit = async () => {
    let step1form = {
      // marital_status: validators.checkRequire('Marital status', values?.marital_status),
      // complexion: validators.checkRequire('Complexion status', values?.complexion),
      height: validators.checkRequire('Height', values?.height),
      // weight: validators.checkRequire('Weight', values?.weight),
      // diet: validators.checkRequire('Dite', values?.diet),
      // disability: validators.checkRequire('Disability', values?.disability),
    }
    if (isValidForm(step1form)) {
      setLoading(true)
      const data = {}
      for (const key in values) {
        if (typeof values[key] === 'object') {
          data[key] = values[key]?.value || values[key]
        } else {
          data[key] = values[key]
        }
      }
      // console.log(formData?._parts);
      // return
      await REQUEST_HANDLER(
        editable ? 'PATCH' : 'POST',
        API + `profile?page=personalInfo`,
        JSON.stringify(data),
        async success => {
          console.log('------12122121-----', success);
          let obj = { ...userProfileInfo }
          obj.personalInfo = data
          dipatch(setUserProfileInfo(obj))
          toast.show(`${success.message}`)
          await AsyncStorage.setItem(variables.USER_PROFILE_INFO, JSON.stringify(obj))
          if (Boolean(isUpdate)) {
            navigation.goBack()
          } else {
            next()
          }
          setLoading(false)
        },
        err => {
          console.log('-=-=-=-=-=err', err);
          toast.show(`${err?.message || 'Something went wrong'}`)
          setLoading(false)
        },
        fail => {
          toast.show(`${fail?.message || 'Something went wrong'}`)
          setLoading(false)
        },
        {
          'Content-Type': 'application/json'
        }
      )
    } else {
      let obj = {}
      for (const field in step1form) {
        if (Object.hasOwnProperty.call(step1form, field)) {
          obj[field] = [step1form[field]]
        }
      }
      setErrors(obj)
    }
  }
  return (
    <View style={{ width: FULL_WIDTH }} className="h-[100%] bg-gray-200">
      {loading && <Loader />}
      <ScrollView className=" px-4  pb-5 ">
        <View style={{ height: 20 }} />
        <SelectPicker
          rootClassName=""
          label="Marital Status"
          placeholder="Marital Status"
          name="marital_status"
          values={values}
          setValues={setValues}
          options={makeDropDownData(options.marital_status)}
          errors={errors}
          setErrors={setErrors}
        />
        <SelectPicker
          rootClassName=""
          label="Complexion"
          placeholder="Complexion"
          name="complexion"
          values={values}
          setValues={setValues}
          options={makeDropDownData(options.complexion)}
          errors={errors}
          setErrors={setErrors}
        />
        <SelectPicker
          rootClassName=""
          label="Height *"
          placeholder="Height *"
          name="height"
          values={values}
          setValues={setValues}
          options={makeDropDownData(options.height)}
          errors={errors}
          setErrors={setErrors}
        />
        <TextField
          rootClassName=""
          label="Weight"
          placeholder="Weight (in kgs)"
          name="weight"
          maxLength={2}
          values={values}
          keyboardType={'numeric'}
          setValues={setValues}
          type='number'
          errors={errors}
          setErrors={setErrors}
        />
        <SelectPicker
          rootClassName=""
          label="Diet"
          placeholder="Diet"
          name="diet"
          values={values}
          setValues={setValues}
          options={makeDropDownData(options.diet)}
          errors={errors}
          setErrors={setErrors}
        />
        <SelectPicker
          rootClassName=""
          label="Disability"
          placeholder="Disability"
          name="disability"
          values={values}
          setValues={setValues}
          options={makeDropDownData(options.disability)}
          errors={errors}
          setErrors={setErrors}
        />
        <PrimaryButton
          onClick={submit}
          title={isUpdate ? "Update" : "Next"}
        />
        <View style={{ height: 55, backgroundColor: 'transparent' }} />
      </ScrollView>
    </View>
  )
}

export default memo(forwardRef(Step2))

const styles = StyleSheet.create({})