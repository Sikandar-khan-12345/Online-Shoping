import { ScrollView, StyleSheet, Text, View } from 'react-native'
import React, { forwardRef, memo, useEffect, useImperativeHandle, useState } from 'react'
import { makeDropDownData } from '../../utils/data';
import SelectInput from '../../Components/Textfield/SelectInput';
import TextField from '../../Components/Textfield/TextField';
import InputCheckBox from '../../Components/Textfield/CheckBox';
import colors from '../../utils/colors';
import { FULL_WIDTH } from '../../utils/layout';
import { useIsFocused } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import variables from '../../utils/variables';
import { API, POST_FORMDATA, REQUEST_HANDLER } from '../../utils/Backend/backend';
import { isValidForm } from '../../utils/utils';
import { validators } from '../../utils/Validation';
import PrimaryButton from '../../Components/Button/PrimaryButton';
import Loader from '../../Components/Loader/Loader';
import SelectPicker from '../../Components/SelectPicker';
import { useDispatch, useSelector } from 'react-redux';
import { setUserProfileInfo } from '../../features/userSlice';
import { useNavigation } from '@react-navigation/native'
import DatePicker from '../../Components/Ui/DatePicker';

const Step5 = ({ currentIndex, isUpdate, data, editable, next = () => { } }, ref) => {
  const dipatch = useDispatch()
  const navigation = useNavigation()
  const userProfileInfo = useSelector((store) => store?.user?.userProfileInfo || {});
  const [values, setValues] = useState({});
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false)
  const [options, setOptions] = useState({
    gotra: makeDropDownData([]),
    mother_tongue: makeDropDownData([]),
    zodiac: makeDropDownData([]),
    caste: makeDropDownData([]),
    sub_caste: makeDropDownData([]),
    manglik: makeDropDownData([]),
    nakshatra: makeDropDownData([]),
  });
  useImperativeHandle(ref, () => {
    return {
      values,
      setValues,
      errors,
      setErrors,
      index: 4
    };
  }, [values, errors])
  const getConstants = async () => {
    let dataString = await AsyncStorage.getItem(variables.CONSTANT)
    if (dataString) {
      let data = JSON.parse(dataString)
      setOptions({
        gotra: data?.gotraLOV,
        mother_tongue: data?.motherTongueLOV,
        zodiac: data?.zodiacLOV,
        manglik: data?.manglikLOV,
        nakshatra: data?.nakshatraLOV,
      })
    }
  }
  useEffect(() => {
    if (data) {
      setValues(data)
    }
  }, [data])

  const isFocused = useIsFocused()
  useEffect(() => {
    getConstants()
  }, [isFocused, currentIndex])
  const getValues = async () => {
    await REQUEST_HANDLER(
      'PATCH',
      API + `profile?page=religiousInfo`,
      {},
      res => {
        print('res--religiousInfo----', res)
        setValues(res?.religiousInfo)
      },
      err => {

        print('errr--religiousInfo----', err)

        toast.show(`${err?.message || "Something went wrong"}`, { type: 'danger' })


      },
      fail => {
        print('fail--religiousInfo----', fail)
        toast.show('Check network,Try again.', { type: 'danger' })
      }
    )
  }
  useEffect(() => {
    // getValues()
  }, [])
  const submit = async () => {
    let step1form = {
      // gotra: validators.checkRequire('Gotra', values?.gotra),
      // mother_tongue: validators.checkRequire('Mother tongue', values?.mother_tongue),
      // birth_time: validators.checkRequire('Birth time', values?.birth_time),
      // birth_place: validators.checkRequire('Birth place', values?.birth_place),
      // zodiac: validators.checkRequire('Zodiac', values?.zodiac),
    }
    if (isValidForm(step1form)) {
      setLoading(true)
      const formData = {}
      // const formData = new FormData()
      for (const key in values) {
        if (typeof values[key] === 'object') {
          formData[key] = values[key]?.value || values[key]
        } else {
          formData[key] = values[key]
        }
      }
      await REQUEST_HANDLER(
        editable ? "PATCH" : "POST",
        API + `profile?page=religiousInfo`,
        JSON.stringify(formData),
        async success => {
          let obj = { ...userProfileInfo }
          obj.educationalInfo = formData
          dipatch(setUserProfileInfo(obj))
          toast.show(`${success.message}`)
          await AsyncStorage.setItem(variables.USER_PROFILE_INFO, JSON.stringify(obj))
          if (isUpdate) {
            navigation.goBack()
          } else {
            next()
          }
          setLoading(false)
        },
        err => {
          toast.show(`${err?.message || 'Something went wrong'}`)
          setLoading(false)
        },
        fail => {
          toast.show(`${fail?.message || 'Something went wrong'}`)
          setLoading(false)
        },
        {
          'Content-Type': 'application/json'
        }
      )
    } else {
      let obj = {}
      for (const field in step1form) {
        if (Object.hasOwnProperty.call(step1form, field)) {
          obj[field] = [step1form[field]]
        }
      }
      setErrors(obj)
    }
  }
  return (
    <View style={{ width: FULL_WIDTH }} className="h-[100%] bg-gray-200">
      {loading && <Loader />}
      <ScrollView className=" px-4  pb-5 ">
        <View style={{ height: 20 }} />
        <SelectPicker
          rootClassName=""
          label="Gotra"
          placeholder="Gotra"
          name="gotra"
          values={values}
          setValues={setValues}
          options={makeDropDownData(options.gotra)}
          errors={errors}
          setErrors={setErrors}
        />
        <SelectPicker
          rootClassName=""
          label="Mother tongue"
          placeholder="Mother tongue"
          name="mother_tongue"
          values={values}
          setValues={setValues}
          options={makeDropDownData(options.mother_tongue)}
          errors={errors}
          setErrors={setErrors}
        />
        {/**
         birth time query with sumit
  */}
        <DatePicker
          label="Birth time"
          name="birth_time"
          values={values}
          setValues={setValues}
          errors={errors}
          mode='time'
          formate={'hh:mm A'}
          setErrors={setErrors}
        />
        <TextField
          label="Birth place"
          placeholder="Birth place"
          name="birth_place"
          values={values}
          setValues={setValues}
          type="Text"
          errors={errors}
          setErrors={setErrors}
        />
        <SelectPicker
          rootClassName=""
          label="Zodiac"
          placeholder="Zodiac"
          name="zodiac"
          values={values}
          setValues={setValues}
          options={makeDropDownData(options.zodiac)}
          errors={errors}
          setErrors={setErrors}
        />
        <SelectPicker
          rootClassName=""
          label="Manglik"
          placeholder="Manglik"
          name="manglik"
          values={values}
          setValues={setValues}
          options={makeDropDownData(options.manglik)}
          errors={errors}
          setErrors={setErrors}
        />
        <SelectPicker
          rootClassName=""
          label="Nakshatra"
          placeholder="Nakshatra"
          name="nakshatra"
          values={values}
          setValues={setValues}
          options={makeDropDownData(options.nakshatra)}
          errors={errors}
          setErrors={setErrors}
        />
        <TextField
          rootClassName=""
          label="Caste"
          placeholder="Caste"
          name="caste"
          values={values}
          setValues={setValues}
          options={makeDropDownData(options.caste)}
          errors={errors}
          setErrors={setErrors}
        />
        <TextField
          rootClassName=""
          label="Sub Caste"
          placeholder="Sub Caste"
          name="sub_caste"
          values={values}
          setValues={setValues}
          options={makeDropDownData(options.sub_caste)}
          errors={errors}
          setErrors={setErrors}
        />
        <View style={{ flexDirection: 'row', marginBottom: 15, alignItems: 'center' }}>
          <InputCheckBox
            name="open_to_other_communities"
            values={values}
            setValues={setValues}
          />
          <Text style={{ marginLeft: 10, color: colors.black, fontSize: 16 }}>Willing to marry from other communities.</Text>
        </View>
        <PrimaryButton
          onClick={submit}
          title={isUpdate ? "Update" : "Next"}
        />
        <View style={{ height: 55, backgroundColor: 'transparent' }} />
      </ScrollView>
    </View>
  )
}

export default memo(forwardRef(Step5))

const styles = StyleSheet.create({})