import { ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import React, { memo, useState, useEffect } from 'react'
import { SCREENS } from '.'
import Icon from "react-native-vector-icons/FontAwesome";
import colors from '../../utils/colors';
import { FULL_WIDTH } from '../../utils/layout';
import Animated, { FadeInDown, FadeOutDown } from 'react-native-reanimated';
const STATUSBAR_HEIGHT = StatusBar.currentHeight
const Header = ({ back = () => { }, isUpdate, currentIndex, screenInfo = {}, scrollX, onIndexPress = () => { } }) => {

    const val = 40
    const translateX = scrollX.interpolate({
        inputRange: [0, FULL_WIDTH * 1, FULL_WIDTH * 2, FULL_WIDTH * 3, FULL_WIDTH * 4, FULL_WIDTH * 5, FULL_WIDTH * 6],
        outputRange: [0, val, val * 2, val * 3, val * 4, val * 5, val * 6],
    })
    const [filledIcon, setFilledIcon] = useState({})
    useEffect(() => {
        setFilledIcon(screenInfo)
    }, [screenInfo])
    useEffect(() => {
        let obj = { ...filledIcon }
        obj[currentIndex] = true
        setFilledIcon(obj)
    }, [currentIndex])

    return (
        <View style={styles.header}>
            <View>
                <Text
                    className="font-bold font-[blinker] "
                    style={{ textAlign: 'center', fontSize: 15 }}>{SCREENS[currentIndex]?.name}</Text>
            </View>
            {/* <View className="relative py-4 pt-9 px-2 bg-white flex flex-row align-middle "> */}
            <View style={{ flexDirection: 'row' }}>
                <TouchableOpacity style={{ padding: 5, marginHorizontal: 20 }} onPress={back}>
                    <Icon size={17} name="chevron-left" color={colors.primary} />
                </TouchableOpacity>
                {(isUpdate == undefined) && <View>
                    <ScrollView horizontal>
                        {
                            SCREENS.map((_, i) => {
                                return (
                                    <Indexing onPress={onIndexPress} key={i} isFilled={filledIcon[i]} currentIndex={currentIndex} i={i} />
                                )
                            })
                        }
                    </ScrollView>
                    {/* <Animated.View style={{ transform:[{translateX}],width:7,height:7,borderRadius:5,backgroundColor:colors.primary,marginLeft:16.5}}/> */}
                </View>}
            </View>

        </View>
    )
}

export default Header

const Indexing = memo(({ isFilled, currentIndex, i, onPress = () => { } }) => {
    return (
        <View style={styles.indexContainer}>
            <TouchableOpacity
                disabled={!isFilled || currentIndex == i}
                onPress={() => onPress(i)} key={i} style={styles.index(isFilled || currentIndex == i)}>
                <Text style={{ color: (isFilled || currentIndex == i) ? colors.white : colors.black }}>{i + 1}</Text>
            </TouchableOpacity>
            {
                (currentIndex == i) ?
                    <Animated.View
                        entering={FadeInDown}
                        exiting={FadeOutDown}
                        style={{ width: 7, height: 7, borderRadius: 5, margin: 3, backgroundColor: colors.primary }} />
                    : <View style={{ width: 7, height: 7, borderRadius: 5, margin: 3, backgroundColor: 'transparent' }} />
            }
        </View>
    )
})

const styles = StyleSheet.create({
    index: (selected) => ({
        // marginHorizontal: 5,
        minWidth: 25,
        minHeight: 25,
        borderRadius: 15,
        justifyContent: 'center',
        alignItems: 'center',
        borderColor: selected ? colors.primary : colors.black,
        backgroundColor: selected ? colors.primary : colors.white,
        borderWidth: 1
    }),
    indexContainer: {
        width: 40,
        height: 40,
        justifyContent: 'center',
        alignItems: 'center',
    },
    header: {
        minHeight: 60 + STATUSBAR_HEIGHT,
        paddingTop: STATUSBAR_HEIGHT + 5,
        padding: 5
    }
})