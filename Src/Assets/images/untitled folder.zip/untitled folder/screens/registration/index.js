import { Animated, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import React, { memo, useCallback, useEffect, useRef, useState } from 'react'
import PrimaryButton from '../../Components/Button/PrimaryButton'
import FormContainer from '../../src/components/HOC/FormContainer'
import { FULL_WIDTH } from '../../utils/layout'
import Step1 from './Step1'
import Step2 from './Step2'
import Step3 from './Step3'
import Step4 from './Step4'
import Step5 from './Step5'
import Step6 from './Step6'
import Step7 from './Step7'

import colors from '../../utils/colors'
import { API, getAuth, GET_WITH_TOKEN } from '../../utils/Backend/backend'
import { useNavigation } from '@react-navigation/native'
import { isValidForm } from '../../utils/utils'
import { validators } from '../../utils/Validation'
import { CONSTANTS, PROFILE } from '../../utils/Backend/end_points'
import AsyncStorage from '@react-native-async-storage/async-storage'
import variables from '../../utils/variables'
import SelectPicker from '../../Components/SelectPicker'
import ListHeader from './Header'
import LoadingModal from '../../src/components/UI/LoadingModal'
import { FocusAwareStatusBar } from '../../Components/Ui/FocusAwareStatusBar'
import Header from '../../Components/Header/Header'

export const SCREENS = [
  {
    id: 0,
    name: 'Basic Details',
    endPoint: 'basicInfo'
  },
  {
    id: 1,
    name: 'Personal Details',
    endPoint: 'personalInfo'
  },
  {
    id: 2,
    name: 'Educational Details',
    endPoint: 'educationalInfo'
  },
  {
    id: 3,
    name: 'Contact Details',
    endPoint: 'contactInfo'
  },
  {
    id: 4,
    name: 'Religious Details',
    endPoint: 'religiousInfo'
  },
  {
    id: 5,
    name: 'Family Details',
    endPoint: 'familyInfo'
  },
  {
    id: 6,
    name: 'Partner preferences',
    endPoint: 'preferenceInfo'
  },
]

const Registeration = ({ route }) => {
  const { indexToUpdate } = route?.params || {}
  const navigation = useNavigation()
  const scrollRef = useRef(null)
  const scrollX = useRef(new Animated.Value(0)).current
  const [userProfile, setUserProfile] = useState({})
  const [currentIndex, setCurrentIndex] = useState(0)
  const [loading, setLoading] = useState(true)
  const [screenInfo, setScreenInfo] = useState({})
  useEffect(() => {
    getConstant()
    getProfileInfo()
    if (indexToUpdate == undefined) {
      setProfilePending()
    }
  }, [])

  const setProfilePending = async () => {
    await AsyncStorage.setItem(variables.IS_PENDING, 'pending')
  }


  const getConstant = async () => {
    await GET_WITH_TOKEN(
      API + CONSTANTS,
      async (success) => {
        console.log('sssssssssss', success);
        if (success?.data) {
          await AsyncStorage.setItem(variables.CONSTANT, JSON.stringify(success?.data))
        }
      },
      err => {
        console.log('errr', err);

      },
      fail => {
        console.log('fail', fail);

      }
    )
  }

  const getProfileInfo = async () => {
    await GET_WITH_TOKEN(
      API + PROFILE,
      success => {
        console.log('=-===-====', success);
        setUserProfile(success)
        setLoading(false)
      },
      err => {
        console.log('errr====', err);
        setLoading(false)
      },
      fail => {
        console.log('fail-----', fail);
        setLoading(false)
      }
    )
  }

  useEffect(() => {
    let obj = {
      0: userProfile?.basicInfo_present,
      1: userProfile?.personalInfo_present,
      2: userProfile?.educationalInfo_present,
      3: userProfile?.contactInfo_present,
      4: userProfile?.religiousInfo_present,
      5: userProfile?.familyInfo_present,
      6: userProfile?.preferenceInfo_present,
    }
    setScreenInfo(obj)
    if (indexToUpdate != undefined) {
      scrollRef?.current?.scrollTo({
        x: FULL_WIDTH * Number(indexToUpdate),
        animated: true,
      })
    } else {
      for (const key in obj) {
        if (obj[key] == false) {
          scrollRef?.current?.scrollTo({
            x: FULL_WIDTH * Number(key),
            animated: true,
          })
          break
        }
      }
    }
  }, [scrollRef && userProfile])


  const back = () => {
    if (indexToUpdate != undefined) {
      navigation.goBack()
      return
    }
    if (currentIndex != 0) {
      scrollRef?.current?.scrollTo({
        x: FULL_WIDTH * (currentIndex - 1),
        animated: true,
      });
    } else {
      if (navigation?.canGoBack()) {
        navigation?.goBack()
      }
    }
  }
  const next = useCallback((last = true) => {
    toast.hideAll()
    if (last) {
      scrollRef?.current?.scrollTo({
        x: FULL_WIDTH * (currentIndex + 1),
        animated: true,
      })
    }
    getProfileInfo()
  }, [scrollRef, currentIndex])
  const handleIndexPress = (i) => {
    scrollRef?.current?.scrollTo({
      x: FULL_WIDTH * i,
      animated: true,
    })
  }
  const handleScroll = ({ nativeEvent }) => {
    setCurrentIndex(Math.round(nativeEvent.contentOffset.x / FULL_WIDTH))
  }
  return (
    <View style={{ flex: 1 }}>
      <FocusAwareStatusBar backgroundColor={colors.primary} />
      {
        indexToUpdate != undefined ?
          <Header leftIcon={'back'} leftIconColor={colors.white} title={SCREENS[indexToUpdate].name} />
          : <ListHeader back={back} isUpdate={indexToUpdate} screenInfo={screenInfo} onIndexPress={handleIndexPress} scrollX={scrollX} currentIndex={currentIndex} />
      }
      <LoadingModal visible={loading} />
      <FormContainer>
        <ScrollView onScroll={handleScroll} scrollEventThrottle={16} ref={scrollRef} className="bg-gray-200" showsHorizontalScrollIndicator={false} horizontal pagingEnabled scrollEnabled={false}>
          <Step1 isUpdate={indexToUpdate} data={userProfile?.basicInfo} editable={userProfile?.basicInfo_present} next={next} />
          <Step2 currentIndex={currentIndex} isUpdate={indexToUpdate} data={userProfile?.personalInfo} editable={userProfile?.personalInfo_present} next={next} />
          <Step3 isUpdate={indexToUpdate} currentIndex={currentIndex} data={userProfile?.educationalInfo} editable={userProfile?.educationalInfo_present} next={next} />
          <Step4 isUpdate={indexToUpdate} data={userProfile?.contactInfo} editable={userProfile?.contactInfo_present} next={next} currentIndex={currentIndex} />
          <Step5 currentIndex={currentIndex} isUpdate={indexToUpdate} data={userProfile?.religiousInfo} editable={userProfile?.religiousInfo_present} next={next} />
          <Step6 currentIndex={currentIndex} isUpdate={indexToUpdate} data={userProfile?.familyInfo} editable={userProfile?.familyInfo_present} next={next} />
          <Step7 isUpdate={indexToUpdate} data={userProfile?.preferenceInfo} editable={userProfile?.preferenceInfo_present} next={next} currentIndex={currentIndex} />
        </ScrollView>
      </FormContainer>
    </View>
  )
}

export default Registeration



const styles = StyleSheet.create({
  index: (selected) => ({
    marginHorizontal: 5,
    width: 25,
    height: 25,
    borderRadius: 15,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
    borderColor: selected ? colors.primary : colors.black,
    backgroundColor: selected ? colors.primary : colors.white
  }),
  button: {
    position: 'absolute',
    bottom: 10,
    left: 10,
    right: 10,
  }
})