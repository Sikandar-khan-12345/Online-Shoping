import { ScrollView, StyleSheet, Text, Touchable, TouchableOpacity, View } from 'react-native'
import React, { forwardRef, memo, useEffect, useImperativeHandle, useState } from 'react'
import colors from '../../utils/colors'
import { useToast } from 'react-native-toast-notifications';
import TextField from '../../Components/Textfield/TextField';
import axios from 'axios';
import { createdByOptions, genderOptions } from '../../utils/data';
import { FULL_WIDTH } from '../../utils/layout';
import SelectPicker from '../../Components/SelectPicker';
import Loader from '../../Components/Loader/Loader';
import { API, POST_FORMDATA, REQUEST_HANDLER } from '../../utils/Backend/backend';
import { BASICINFO } from '../../utils/Backend/end_points';
import PrimaryButton from '../../Components/Button/PrimaryButton';
import { validators } from '../../utils/Validation';
import { isValidForm } from '../../utils/utils';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useDispatch, useSelector } from 'react-redux';
import { setUserProfileInfo } from '../../features/userSlice';
import variables from '../../utils/variables';
import { useNavigation } from '@react-navigation/native'
import Checkbox from 'expo-checkbox';
import Dropdown from '../../Components/Ui/Dropdown';
import Picker from '../../Components/Ui/Picker';
import DatePicker from '../../Components/Ui/DatePicker';
const Step1 = ({ isUpdate, data, editable, next = () => { } }, ref) => {
  // const toast = useToast();
  const navigation = useNavigation()
  const dipatch = useDispatch()
  const userProfileInfo = useSelector((store) => store?.user?.userProfileInfo || {});
  const [values, setValues] = useState({});
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false)
  const [options, setOptions] = useState({
    profile_created_by: createdByOptions,
    gender: genderOptions,
  });
  const fetchInitialOptions = async () => {
    setLoading(true);
    try {
      const res = await Promise.all([
        axios.get("./countries"),
        axios.get("./religions"),
        axios.get("./aakanas"),
      ]);
      const data = res.map((res) => res.data);
      let optionsUpdate = { ...options };
      data.forEach(async (res, i) => {
        console.log(res);
        if (res.success) {
          if (i === 0 && Array.isArray(res?.data)) {
            optionsUpdate.country = res?.data;
          } else if (i === 1 && Array.isArray(res?.data)) {
            optionsUpdate.religion = res?.data;
          } else if (i === 2 && Array.isArray(res?.data)) {
            await AsyncStorage.setItem('aakana', JSON.stringify(res?.data))
            optionsUpdate.aakana = res?.data;
          }
        }
      });
      console.log('-------optionsUpdate-------', optionsUpdate);
      setOptions(optionsUpdate);
      setLoading(false);
    } catch (e) {
      console.log(e);
      toast.show(e?.message || "Failed to Fetch Options", {
        type: "danger",
      });
      setLoading(false);
    }
  };

  const CatchErrorHandler = (e) => { };
  const dropdwonResponseHandler = (data, optionsName) => {
    setLoading(false);
    if (data?.success) {
      if (Array.isArray(data?.data)) {
        setOptions({ ...options, [optionsName]: data?.data });
      }
    } else {
    }

    console.log(res);
  };
  const fetchStatesByCountry = (country) => {
    if (!country) {
      return;
    }
    setLoading(true);
    axios
      .get(`/statesForCountry?country_label=${country?.value}`)
      .then((res) => {
        dropdwonResponseHandler(res?.data, "state");
      })

      .catch(CatchErrorHandler);
  };

  const setSameAsMobile = () => {
    if ((values['mobile_number'] == values['whatsapp_number'])) {
      let obj = { ...values }
      obj['whatsapp_number'] = ''
      setValues(obj)
    } else {
      let obj = { ...values }
      obj['whatsapp_number'] = values['mobile_number']
      setValues(obj)
    }
  }
  useEffect(() => {
    if (typeof data === 'object') {
      let obj = { ...data }
      let { dob } = data
      let dateArr = dob?.split('-')
      obj.month = dateArr[1]
      obj.date = dateArr[2]
      obj.year = dateArr[0]
      setValues(obj)
    }
  }, [data])

  const fetchCitiesByState = (state) => {
    if (!state) {
      return;
    }
    setLoading(true);
    axios
      .get(`/citiesForState?state_label=${state?.value}`)
      .then((res) => {
        dropdwonResponseHandler(res?.data, "city");
      })
      .catch(CatchErrorHandler);
  };
  useImperativeHandle(ref, () => {
    return {
      values,
      setValues,
      errors,
      setErrors: (e) => setErrors(e),
      index: 0
    };
  }, [values, errors]);
  const getValues = async () => {
    await REQUEST_HANDLER(
      'PATCH',
      API + `profile?page=${BASICINFO}`,
      {},
      res => {
        print('res--BASICINFO----', res)
        // setValues(res?.basicInfo)
      },
      err => {

        print('errr--BASICINFO----', err)

        toast.show(`${err?.message || "Something went wrong"}`, { type: 'danger' })


      },
      fail => {
        print('fail--BASICINFO----', fail)
        toast.show('Check network,Try again.', { type: 'danger' })
      }
    )
  }
  useEffect(() => {
    fetchInitialOptions();
    // getValues()
  }, []);
  const submit = async () => {
    let step1form = {
      first_name: validators.checkRequire('First name', values?.first_name?.trim()),
      // middle_name: validators.checkRequire('Middle name', values?.middle_name?.trim()),
      last_name: validators.checkRequire('Last name', values?.last_name?.trim()),
      gender: validators.checkRequire('Gender', values?.gender),
      mobile_number: validators.checkPhoneNumber('Mobile number', values?.mobile_number?.trim()),
      whatsapp_number: validators.checkPhoneNumber('Whatsapp number', values?.whatsapp_number?.trim()),
      // date: validators.checkRequire('Date', values?.date?.trim()),
      // month: validators.checkRequire('Month', values?.month?.trim()),
      // year: validators.checkRequire('Year', values?.year?.trim()),
      dob: validators.checkRequire('Year', values?.dob?.trim()),
      aakana: validators.checkRequire('Aakana', values?.aakana?.value),
      religion: validators.checkRequire('Religion', values?.religion?.value),
      country: validators.checkRequire('Country', values?.country?.value),
      state: validators.checkRequire('State', values?.state?.value),
    }
    if (isValidForm(step1form)) {
      setLoading(true)
      const formData = new FormData()
      const data = {}
      // formData.append('dob',`${values?.date}-${values?.month}-${values?.year}`)
      // for (const key in values) {
      //   if ((key=='month')||(key=='year')||(key=='date')) {
      //     continue
      //   }
      //   if (typeof values[key] === 'object') {
      //     formData.append(key, values[key]?.value)
      //   }else{
      //     formData.append(key, values[key])
      //   }
      // }
      // data.dob = `${values?.date}-${values?.month}-${values?.year}`
      for (const key in values) {
        if (typeof values[key] === 'object') {
          data[key] = values[key]?.value || values[key]
        } else {
          data[key] = values[key]
        }
      }
      console.log(formData?._parts);
      // return
      await REQUEST_HANDLER(
        editable ? 'PATCH' : 'POST',
        API + `profile?page=basicInfo`,
        JSON.stringify(data),
        async success => {
          console.log('successsssssss', success);
          let obj = { ...userProfileInfo }
          obj.basicInfo = data
          if (success?.message) {
            toast.show(`${success?.message}`)
          }
          dipatch(setUserProfileInfo(obj))
          await AsyncStorage.setItem(variables.USER_PROFILE_INFO, JSON.stringify(obj))
          if (isUpdate == 0) {
            navigation.goBack()
          } else {
            next()
          }
          setLoading(false)
        },
        err => {
          toast.show(`${err?.message || 'Something went wrong'}`)
          setLoading(false)
        },
        fail => {
          toast.show(`${fail?.message || 'Something went wrong'}`)
          setLoading(false)
        },
        {
          'Content-Type': 'application/json'
        }
      )
    } else {
      let obj = {}
      for (const field in step1form) {
        if (Object.hasOwnProperty.call(step1form, field)) {
          obj[field] = [step1form[field]]
        }
      }
      setErrors(obj)
    }
  }


  return (
    <View style={{ width: FULL_WIDTH }} className="h-[100%] bg-gray-200">
      {loading && <Loader />}
      <ScrollView
        className=" px-4  pb-5 ">
        <View style={{ height: 20 }} />
        <TextField
          label="First Name *"
          placeholder="First Name *"
          name="first_name"
          values={values}
          setValues={setValues}
          type="Text"
          errors={errors}
          setErrors={setErrors}
        />
        <TextField
          label="Middle Name *"
          placeholder="Middle Name *"
          name="middle_name"
          values={values}
          setValues={setValues}
          type="Text"
          errors={errors}
          setErrors={setErrors}
        />
        <TextField
          label="Last Name *"
          placeholder="Last Name *"
          name="last_name"
          values={values}
          setValues={setValues}
          type="Text"
          errors={errors}
          setErrors={setErrors}
        />
        <Picker
          rootClassName=""
          label="Gender *"
          placeholder="Select Gender *"
          name="gender"
          options={options.gender}
          values={values}
          setValues={setValues}
          errors={errors}
          setErrors={setErrors}
        />
        <TextField
          type="number"
          mobileNumber
          maxLength={10}
          // label="Mobile *"
          placeholder="Mobil"
          name="mobile_number"
          keyboardType={'numeric'}
          values={values}
          setValues={setValues}
          errors={errors}
          setErrors={setErrors}
        />
        <TextField
          // label="Whatsapp *"
          mobileNumber
          placeholder="Whatsapp *"
          name="whatsapp_number"
          values={values}
          setValues={setValues}
          keyboardType={'numeric'}
          type="number"
          maxLength={10}
          errors={errors}
          setErrors={setErrors}
        />
        <TouchableOpacity
          onPress={setSameAsMobile}
          style={{ flexDirection: 'row', marginBottom: 15, alignItems: 'center' }}>
          <View>
            <Checkbox style={{}} color={(values['mobile_number'] == values['whatsapp_number']) ? colors.primary : undefined} value={(values['mobile_number'] == values['whatsapp_number']) && (values['whatsapp_number']) && (values['mobile_number'])} onValueChange={setSameAsMobile} />
          </View>
          <Text style={{ marginLeft: 10, color: colors.black, fontSize: 16 }}>Same as mobile number.</Text>
        </TouchableOpacity>
        <DatePicker
          name={'dob'}
          values={values}
          label='Date of Birth *'
          setValues={setValues}
          setErrors={setErrors}
        />
        {/* <Text className="mb-3">Date of Birth * : </Text>
        <View style={{ justifyContent: 'space-between' }} className="flex flex-row ">
          <View style={{ width: '32%' }}>

            <TextField
              label="Date "
              placeholder="DD"
              name="date"
              values={values}
              setValues={setValues}
              rootClassName="mr-2 w-20"
              type="number"
              errors={errors}
              setErrors={setErrors}
              maxLength={2}
            />
          </View>
          <View style={{ width: '32%' }}>

            <TextField
              label="Month"
              placeholder="MM"
              name="month"
              values={values}
              setValues={setValues}
              rootClassName="mr-2 w-20"
              type="number"
              maxLength={2}
              errors={errors}
              setErrors={setErrors}
            />
          </View>
          <View style={{ width: '32%' }}>

            <TextField
              label="Year"
              placeholder="YYYY"
              name="year"
              values={values}
              setValues={setValues}
              rootClassName="flex-1"
              type="number"
              maxLength={4}
              errors={errors}
              setErrors={setErrors}
            />
          </View>
        </View> */}
        {errors?.dob?.length ? (
          <Text className="text-red-400 relative mt-[-12px] mb-4">
            {errors?.dob?.[0]}
          </Text>
        ) : null}
        <SelectPicker
          label="Aakana *"
          placeholder="Select Aakana *"
          name="aakana"
          values={values}
          setValues={setValues}
          options={options?.aakana}
          errors={errors}
          setErrors={setErrors}
        />
        <SelectPicker
          label="Religion *"
          placeholder="Select Religion *"
          name="religion"
          values={values}
          setValues={setValues}
          options={options?.religion}
          errors={errors}
          setErrors={setErrors}
        />
        <Picker
          label="Country *"
          placeholder="Select Country *"
          name="country"
          values={values}
          setValues={setValues}
          options={options?.country}
          onChange={fetchStatesByCountry}
          errors={errors}
          setErrors={setErrors}
        />
        <Dropdown
          label="State *"
          placeholder="Select State *"
          name="state"
          values={values}
          setValues={setValues}
          options={options?.state}
          onChange={fetchCitiesByState}
          errors={errors}
          setErrors={setErrors}
        />
        <TextField
          label="Pincode"
          placeholder="Pincode"
          name="pincode"
          values={values}
          setValues={setValues}
          type="number"
          maxLength={6}
          keyboardType={'numeric'}
          errors={errors}
          setErrors={setErrors}
        />
        <PrimaryButton
          onClick={submit}
          title={isUpdate == 0 ? "Update" : "Next"}
        />
        <View style={{ height: 55, backgroundColor: 'transparent' }} />
      </ScrollView>
    </View>
  )
}

export default memo(forwardRef(Step1))

const styles = StyleSheet.create({})