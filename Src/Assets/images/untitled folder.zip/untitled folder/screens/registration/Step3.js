import { ScrollView, StyleSheet, Text, View } from 'react-native'
import React, { forwardRef, memo, useEffect, useImperativeHandle, useState } from 'react'
import SelectInput from '../../Components/Textfield/SelectInput'
import { makeDropDownData, yesNoOptions } from '../../utils/data';
import TextField from '../../Components/Textfield/TextField';
import { FULL_WIDTH } from '../../utils/layout';
import { useIsFocused, useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import variables from '../../utils/variables';
import { API, POST_FORMDATA, REQUEST_HANDLER } from '../../utils/Backend/backend';
import { validators } from '../../utils/Validation';
import { isValidForm } from '../../utils/utils';
import PrimaryButton from '../../Components/Button/PrimaryButton';
import Loader from '../../Components/Loader/Loader';
import SelectPicker from '../../Components/SelectPicker';
import { useDispatch, useSelector } from 'react-redux';
import { setUserProfileInfo } from '../../features/userSlice';

const Step3 = ({ currentIndex, isUpdate, data, editable, next = () => { } }, ref) => {
  const navigation = useNavigation()
  const dipatch = useDispatch()
  const userProfileInfo = useSelector((store) => store?.user?.userProfileInfo || {});
  const [values, setValues] = useState({});
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false)
  const [options, setOptions] = useState({
    highest_education: makeDropDownData([]),
    employed_in: makeDropDownData([]),
    profession: makeDropDownData([]),
    annual_income: makeDropDownData([]),
    college_attended: yesNoOptions,
  });
  useImperativeHandle(ref, () => {
    return {
      values,
      setValues,
      errors,
      setErrors,
      index: 2
    };
  }, [values, errors]);
  const getConstants = async () => {
    let dataString = await AsyncStorage.getItem(variables.CONSTANT)
    if (dataString) {
      let data = JSON.parse(dataString)
      setOptions({
        highest_education: data?.educationLOV,
        employed_in: data?.employedInLOV,
        profession: data?.professionLOV,
        annual_income: data?.annualIncomeLOV,
        college_attended: yesNoOptions,
      })
    }
  }
  useEffect(() => {
    if (data) {
      setValues(data)
    }
  }, [data])

  const isFocused = useIsFocused()
  useEffect(() => {
    getConstants()
  }, [isFocused, currentIndex])
  const getValues = async () => {
    await REQUEST_HANDLER(
      'PATCH',
      API + `profile?page=educationalInfo`,
      {},
      res => {
        print('res--educationalInfo----', res)
        setValues(res?.educationalInfo)
      },
      err => {

        print('errr--educationalInfo----', err)

        toast.show(`${err?.message || "Something went wrong"}`, { type: 'danger' })


      },
      fail => {
        print('fail--educationalInfo----', fail)
        toast.show('Check network,Try again.', { type: 'danger' })
      }
    )
  }
  useEffect(() => {
    // getValues()
  }, [])
  const submit = async () => {
    let step1form = {
      // highest_education: validators.checkRequire('Highest education', values?.highest_education),
      //     college_attended: validators.checkRequire('This', values?.college_attended),
      //     employed_in: validators.checkRequire('This', values?.employed_in),
      //     profession: validators.checkRequire('Profession', values?.profession),
      //     current_company_name: validators.checkRequire('Company name', values?.current_company_name),
      //     annual_income: validators.checkRequire('Annual income', values?.annual_income),
    }
    if (isValidForm(step1form)) {
      setLoading(true)
      const formData = {}
      // const formData = new FormData()
      for (const key in values) {
        formData[key] = values[key]?.value || values[key]
      }
      await REQUEST_HANDLER(
        editable ? "PATCH" : "POST",
        API + `profile?page=educationalInfo`,
        JSON.stringify(formData),
        async success => {
          let obj = { ...userProfileInfo }
          obj.educationalInfo = formData
          dipatch(setUserProfileInfo(obj))
          toast.show(`${success.message}`)
          await AsyncStorage.setItem(variables.USER_PROFILE_INFO, JSON.stringify(obj))
          if (isUpdate) {
            navigation.goBack()
          } else {
            next()
          }
          setLoading(false)
        },
        err => {
          toast.show(`${err?.message || 'Something went wrong'}`)
          setLoading(false)
        },
        fail => {
          toast.show(`${fail?.message || 'Something went wrong'}`)
          setLoading(false)
        },
        {
          'Content-Type': 'application/json'
        }
      )
    } else {
      let obj = {}
      for (const field in step1form) {
        if (Object.hasOwnProperty.call(step1form, field)) {
          obj[field] = [step1form[field]]
        }
      }
      setErrors(obj)
    }
  }
  return (
    <View style={{ width: FULL_WIDTH }} className="h-[100%] bg-gray-200">
      {loading && <Loader />}
      <ScrollView className=" px-4  pb-5  ">
        <View style={{ height: 20 }} />
        {/*
        make Custome dropdown for highest_education
        */}
        <SelectPicker
          rootClassName=""
          nesting={true}
          label="Highest education"
          placeholder="Highest education"
          name="highest_education"
          values={values}
          setValues={setValues}
          options={options.highest_education}
          errors={errors}
          setErrors={setErrors}
        />
        <TextField
          rootClassName=""
          label="College attended"
          placeholder="College attended"
          name="college_attended"
          values={values}
          multiline={true}
          setValues={setValues}
          errors={errors}
          setErrors={setErrors}
        />
        <SelectPicker
          rootClassName=""
          label="Employed in"
          placeholder="Employed in"
          name="employed_in"
          values={values}
          setValues={setValues}
          options={makeDropDownData(options.employed_in)}
          errors={errors}
          setErrors={setErrors}
        />
        {/*
        make Custome dropdown for profession
        */}
        <SelectPicker
          rootClassName=""
          label="Profession"
          placeholder="Profession Status"
          name="profession"
          values={values}
          setValues={setValues}
          options={options.profession}
          nesting={true}
          errors={errors}
          setErrors={setErrors}
        />
        <TextField
          label="Current company Name"
          placeholder="Current company Name"
          name="current_company_name"
          values={values}
          setValues={setValues}
          type="Text"
          errors={errors}
          setErrors={setErrors}
        />
        <SelectPicker
          rootClassName=""
          label="Annual Income"
          placeholder="Annual Income"
          name="annual_income"
          values={values}
          setValues={setValues}
          options={makeDropDownData(options.annual_income)}
          errors={errors}
          setErrors={setErrors}
        />
        <PrimaryButton
          onClick={submit}
          title={isUpdate ? "Update" : "Next"}
        />
        <View style={{ height: 55, backgroundColor: 'transparent' }} />
      </ScrollView>
    </View>
  )
}

export default memo(forwardRef(Step3))

const styles = StyleSheet.create({})