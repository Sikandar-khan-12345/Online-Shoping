import { ScrollView, StyleSheet, Text, View } from 'react-native'
import React, { forwardRef, memo, useEffect, useImperativeHandle, useState } from 'react'
import TextField from '../../Components/Textfield/TextField';
import { FULL_WIDTH } from '../../utils/layout';
import { API, POST_FORMDATA, REQUEST_HANDLER } from '../../utils/Backend/backend';
import { validators } from '../../utils/Validation';
import { isValidForm } from '../../utils/utils';
import PrimaryButton from '../../Components/Button/PrimaryButton';
import Loader from '../../Components/Loader/Loader';
import AsyncStorage from '@react-native-async-storage/async-storage';
import variables from '../../utils/variables';
import { useDispatch, useSelector } from 'react-redux';
import { setUserProfileInfo } from '../../features/userSlice';
import { useNavigation } from '@react-navigation/native';

const Step4 = ({ next = () => { }, isUpdate, data, editable }, ref) => {
  const dipatch = useDispatch()
  const navigation = useNavigation()
  const userProfileInfo = useSelector((store) => store?.user?.userProfileInfo || {});

  const [values, setValues] = useState({
    email: userProfileInfo?.basicInfo?.email,
    contact_number: userProfileInfo?.basicInfo?.mobile_number,
  });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false)
  const getValues = async () => {
    await REQUEST_HANDLER(
      'PATCH',
      API + `profile?page=contactInfo`,
      {},
      res => {
        print('res--contactInfo----', res)
        setValues(res?.contactInfo)
      },
      err => {

        print('errr--contactInfo----', err)

        toast.show(`${err?.message || "Something went wrong"}`, { type: 'danger' })


      },
      fail => {
        print('fail--contactInfo----', fail)
        toast.show('Check network,Try again.', { type: 'danger' })
      }
    )
  }
  useEffect(() => {
    // getValues()
  }, [])
  useEffect(() => {
    let obj = { ...values, ...data }
    setValues(obj)
  }, [data])

  const submit = async () => {
    let step1form = {
      contact_number: validators.checkPhoneNumber('Contact number', values?.contact_number),
      // fathers_contact_number: validators.checkPhoneNumber("Father's contact", values?.fathers_contact_number),
      // email: validators.checkEmail('Email', values?.email),
      // present_address: validators.checkRequire('Present address', values?.present_address),
      // permanent_address: validators.checkRequire('Permanent address', values?.permanent_address)
    }
    if (isValidForm(step1form)) {
      setLoading(true)
      const formData = {}
      // const formData = new FormData()
      for (const key in values) {
        formData[key] = values[key]
        // formData.append(key,values[key])
      }
      await REQUEST_HANDLER(
        editable ? "PATCH" : "POST",
        API + `profile?page=contactInfo`,
        JSON.stringify(formData),
        async success => {
          let obj = { ...userProfileInfo }
          obj.contactInfo = formData
          dipatch(setUserProfileInfo(obj))
          toast.show(`${success.message}`)
          await AsyncStorage.setItem(variables.USER_PROFILE_INFO, JSON.stringify(obj))
          if (isUpdate) {
            navigation.goBack()
          } else {
            next()
          }
          setLoading(false)
        },
        err => {
          toast.show(`${err?.message || 'Something went wrong'}`)
          setLoading(false)
        },
        fail => {
          toast.show(`${fail?.message || 'Something went wrong'}`)
          setLoading(false)
        },
        {
          'Content-Type': 'application/json'
        }
      )
    } else {
      let obj = {}
      for (const field in step1form) {
        if (Object.hasOwnProperty.call(step1form, field)) {
          obj[field] = [step1form[field]]
        }
      }
      setErrors(obj)
    }
  }
  return (
    <View style={{ width: FULL_WIDTH }} className="h-[100%] bg-gray-200">
      {loading && <Loader />}
      <ScrollView className=" px-4  pb-5 ">
        <View style={{ height: 20 }} />
        <TextField
          // label="Contact number *"
          mobileNumber
          placeholder="Contact number *"
          name="contact_number"
          values={values}
          maxLength={10}
          keyboardType={'numeric'}
          setValues={setValues}
          type="number"
          errors={errors}
          setErrors={setErrors}
        />
        <TextField
          // label="Father's contact number"
          mobileNumber
          placeholder="Father's contact number"
          name="fathers_contact_number"
          values={values}
          setValues={setValues}
          keyboardType={'numeric'}
          type="number"
          maxLength={10}
          errors={errors}
          setErrors={setErrors}
        />
        <TextField
          label="Email"
          placeholder="Email"
          name="email"
          values={values}
          setValues={setValues}
          type="email-address"
          errors={errors}
          setErrors={setErrors}
        />
        <TextField
          label="Present address"
          placeholder="Present address"
          name="present_address"
          values={values}
          setValues={setValues}
          errors={errors}
          setErrors={setErrors}
        />
        <TextField
          label="Permanent address"
          placeholder="Permanent address"
          name="permanent_address"
          values={values}
          setValues={setValues}
          errors={errors}
          setErrors={setErrors}
        />
        <PrimaryButton
          onClick={submit}
          title={isUpdate ? "Update" : "Next"}
        />
        <View style={{ height: 55, backgroundColor: 'transparent' }} />
      </ScrollView>
    </View>
  )
}

export default memo(forwardRef(Step4))

const styles = StyleSheet.create({})