import { View, Text, Pressable, Image, TouchableOpacity, ActivityIndicator } from "react-native";
import React from "react";
import Checkbox from 'expo-checkbox';
import colors from "../../utils/colors";

const ImageComponent = ({ uri, onPress, clearHandler, id, isChecked = false, onValueChange = () => { } }) => {
  return (
    <View className=" p-2  relative  flex-grow  min-w-[150] h-[150] ">
      {!!uri && (
        <View className="absolute right-0 top-0 z-10 bg-white rounded-full ">
          <Pressable onPress={() => clearHandler(id)}>
            <Text className="py-2 px-3">X</Text>
          </Pressable>
        </View>
      )}
      {!!uri && (
        <View className="absolute left-3 top-3 z-10 bg-white rounded-full ">
          <Pressable onPress={() => clearHandler(id)}>
            <Checkbox style={{}} color={isChecked ? colors.primary : undefined} value={isChecked} onValueChange={onValueChange} />
          </Pressable>
        </View>
      )}
      <TouchableOpacity activeOpacity={0.7} onPress={onPress} className="flex justify-center border-dashed border h-[100%] border-gray-500 bg-gray-200">
        {uri ? (
          <View>
            {/* <View>
              <ActivityIndicator size={'small'} color={'red'} />
            </View> */}
            <Image source={{ uri }} className="w-[100%] h-[100%]" />
          </View>
        ) : (
          <Pressable >
            <Text className="text-center">+ Add Photo</Text>
          </Pressable>
        )}
      </TouchableOpacity>
    </View>
  );
};

export default ImageComponent;
