import React, { useEffect, useState } from "react";
import * as ImagePicker from "expo-image-picker";
import { BackHandler, FlatList, Image, Modal, Pressable, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import PrimaryButton from "../../Components/Button/PrimaryButton";
import ImageComponent from "./ImageComponent";
import { useDispatch } from "react-redux";
import { formRequiredValidationErrorGen, randomeString } from "../../utils/utils";
import { uploadImages } from "../../features/userSlice";
import axios from "axios";
import * as fs from 'expo-file-system';
import Loader from "../../Components/Loader/Loader";
import { API, BASE_URL, GET_WITH_TOKEN, POST_FORMDATA_WITH_TOKEN, REQUEST_HANDLER } from "../../utils/Backend/backend";
import { UPLOAD_IMAGES } from "../../utils/Backend/end_points";
import colors from "../../utils/colors";
import { FULL_HEIGHT, FULL_WIDTH } from "../../utils/layout";
const ImageUpload = ({ navigation }) => {
  const [images, setImages] = useState([])

  const pickImage = async (index) => {
    let checkExisting = images[index]?.uri || images[index]?.photo
    if (checkExisting) {
      openCarousel(index)
      return
    }
    let option = {
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 1,
      selectionLimit: 1,
      allowsEditing: false,
      allowsMultipleSelection: !Boolean(checkExisting),
    }
    let result = await ImagePicker.launchImageLibraryAsync({
      ...option
    });
    if (!result.canceled) {
      let update = [...images];
      if (result.assets?.length > 1) {
        for (let i = 0; i <= result.assets.length; i++) {
          for (let j = 0; j < 6; j++) {
            if (update[j]?.uri || update[j]?.photo) {
              continue
            } else {
              update.push({
                name: randomeString(),
                uri: result.assets[i]?.uri,
                type: result.assets[i]?.type,
                base64: result.assets[i]?.base64
              })
              break
            }
          }
        }
      } else {
        let obj = result.assets[0]
        update.push({
          name: randomeString(),
          uri: obj.uri,
          type: obj.type,
          base64: obj.base64
        })
      }
      setImages([...update]);
    }
  };

  const uploadClickHandler = async () => {
    let arrWithUri = images.filter((item) => item?.uri) || []
    let arrWithPhoto = images.filter((item) => item?.photo) || []
    let fullArray = [...arrWithUri, ...arrWithPhoto]
    const checkPrimary = fullArray.filter((item) => item?.primary_profile_photo == true)
    if (!checkPrimary.length) {
      toast.show('Please select a primary image.')
      return
    }
    const data = new FormData();
    if (fullArray.length) {
      setLoading(true)
      fullArray.map((item, i) => {
        let imageName = `${randomeString()}_${Date.now()}`
        if (item?.uri) {
          if (item?.primary_profile_photo) {
            data.append('primary_image_key', imageName)
          }

let imageName2 = item?.uri?.split('/')?.reverse()[0]

          data.append(imageName, {
            name: imageName2,
            type: 'image/png',
            uri: item?.uri
          });
        } else if (item?.photo) {
          if (item?.primary_profile_photo) {
            data.append('primary_image_key', item?.id)
          }
          data.append(item?.id, 'exsisting');
        }
      })
      await REQUEST_HANDLER(
        'PUT',
        API + UPLOAD_IMAGES,
        data,
        res => {
          print('res------', res)
          if (res?.message) {
            toast.show(res?.message)

          }
          navigation.goBack()

        },
        err => {

          print('errr------', err)

          toast.show(`${err?.message || "Something went wrong"}`, { type: 'danger' })


        },
        fail => {
          print('fail------', fail)
          toast.show('Check network,Try again.', { type: 'danger' })
        }
      )
    } else {
      toast.show('Please add images')
    }
    setLoading(false)
  };
  const [checkfirstTime, setCheckfirstTime] = useState(false)
  useEffect(() => {
    let isFirstTime = images.filter((item) => item?.primary_profile_photo == true).length
    setCheckfirstTime(!!isFirstTime)
  }, [images])

  const clearHandler = (id) => {
    let imageArr = [...images]
    if (imageArr[id]?.primary_profile_photo == true) {
      toast.show('You cannot delete a primary image.', { type: 'danger' })
      return
    }
    imageArr.splice(id, 1)
    setImages(imageArr)
  };

  const makePrimary = (index) => {
    let obj = [...images]
    let primaryImgIndex = images.findIndex(obj => obj.primary_profile_photo == true)
    if (primaryImgIndex > -1) {
      obj[primaryImgIndex].primary_profile_photo = false
    }
    obj[index].primary_profile_photo = true
    setImages(obj)
  }

  const getImages = async () => {
    await GET_WITH_TOKEN(
      API + UPLOAD_IMAGES,
      res => {
        if (res?.data?.length) {
          let images = res?.data?.map((item, i) => {
            return {
              id: item?.id,
              photo: BASE_URL + item?.photo,
              primary_profile_photo: item?.primary_profile_photo,
              logged_in_user: item?.logged_in_user
            }
          })
          setImages(images)
        }
      },
      err => {
        print('errr------', err)
        toast.show(`${err?.message}`, { type: 'danger' })
      },
      fail => {
        print('fail------', fail)
        toast.show('Check network,Try again.', { type: 'danger' })
      }
    )
    return true
  }
  useEffect(() => {
    getImages().then(() => setLoading(false))
  }, [])

  const [loading, setLoading] = useState(true)
  const [currentIndex, setCurrentIndex] = useState(0)
  const [visible, setVisible] = useState(false)
  const closeCarousel = () => setVisible(false)
  const openCarousel = (index) => {
    setCurrentIndex(index)
    setVisible(true)
  }
  return (
    <SafeAreaView style={{ flex: 1 }}>
      {loading && <Loader />}
      <ScrollView className="p-5">

        <Text className="font-bold text-lg mt-3 mb-5">
          Add Photos to Complete Your Profile
        </Text>

        <View>
          <View className="flex flex-row flex-wrap ">
            {/* {Object?.keys(images)?.map((each, i) => (
              <ImageComponent
                onPress={pickImage}
                key={i}
                uri={images[each]?.uri}
                id={each}
                clearHandler={clearHandler}
              />
            ))} */}
            {[1, 1, 1, 1, 1, 1].map((_, i) => (
              <ImageComponent
                onPress={pickImage.bind(this, i)}
                key={i}
                uri={images[i]?.uri || images[i]?.photo}
                id={i}
                onValueChange={makePrimary.bind(this, i)}
                isChecked={images[i]?.primary_profile_photo || false}
                clearHandler={clearHandler}
              />
            ))}
          </View>
        </View>
        <TouchableOpacity onPress={uploadClickHandler} style={{ marginTop: 10 }}>
          <PrimaryButton
            title={checkfirstTime ? "Update" : "Upload"}
            disabled={true}
            onclick={uploadClickHandler}
          />
        </TouchableOpacity>
        <ImageCarousel
          data={images.filter((item) => item?.uri || item?.photo)}
          currentIndex={currentIndex}
          close={closeCarousel}
          visible={visible}
        />
      </ScrollView>
    </SafeAreaView>
  );
};

export default ImageUpload;


const ImageCarousel = ({ data, currentIndex, visible = false, close = () => { } }) => {
  useEffect(() => {
    const backAction = () => {
      close()
      return true
    }
    let backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      backAction()
    })
    return () => backHandler.remove()
  }, [])

  const _renderImage = ({ item, index }) => <Item item={item} index={index} data={data} />
  return (
    <Modal
      transparent
      onRequestClose={close}
      visible={visible}
      animationType='fade'
      statusBarTranslucent
    >
      <View style={{ flex: 1, backgroundColor: colors.black }}>
        <StatusBar barStyle={'light-content'} backgroundColor='transparent' />
        <View className="absolute right-5 top-5 z-10 bg-white rounded-full ">
          <Pressable onPress={() => close()}>
            <Text className="py-2 px-3">X</Text>
          </Pressable>
        </View>
        <FlatList
          data={data || []}
          initialScrollIndex={currentIndex}
          renderItem={_renderImage}
          horizontal
          pagingEnabled={true}
        />
      </View>
    </Modal>
  )
}

const Item = ({ item, index, data = [] }) => {
  return (
    <View style={styles.imageContainer}>
      <Image resizeMode='contain' style={styles.image} source={{ uri: data[index]?.uri || data[index]?.photo }} />
    </View>
  )
}

const styles = StyleSheet.create({
  imageContainer: {
    width: FULL_WIDTH,
    height: FULL_HEIGHT,
    justifyContent: 'center',
    alignItems: 'center'
  },
  image: {
    width: FULL_WIDTH,
    height: FULL_HEIGHT,
  }
})
