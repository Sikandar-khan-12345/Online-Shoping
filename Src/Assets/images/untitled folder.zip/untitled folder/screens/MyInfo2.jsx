import { View, Text, Pressable, ScrollView } from "react-native";
import React, { useEffect, useState } from "react";
import Header from "../Components/Header/Header";
import SpecificData from "../Components/SpecificData/SpecificData";
import { useSelector } from "react-redux";
import { useNavigation } from "@react-navigation/native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import PrimaryButton from "../Components/Button/PrimaryButton";
import { API, GET_WITH_TOKEN } from "../utils/Backend/backend";
import { PROFILE } from "../utils/Backend/end_points";
import { useIsFocused } from "@react-navigation/native"
import Loader from "../Components/Loader/Loader";
import LoadingModal from "../src/components/UI/LoadingModal";

const MyInfo = () => {
  const navigation = useNavigation();
  const [userInfo, setUserInfo] = useState({})
  const [loading, setLoading] = useState(true)
  const user = useSelector((state) => state?.user?.user?.user || {});
  const user2 = useSelector((state) => state?.user?.userProfileInfo || {});

  // let basicInfo = { ...userInfo?.basicInfo }
  const {
    personalInfo,
    educationalInfo,
    contactInfo,
    religiousInfo,
    familyInfo,
    preferenceInfo,
    basicInfo
  } = userInfo
  // console.log(basicInfo);

  const getUserInfo = async () => {
    await GET_WITH_TOKEN(
      API + PROFILE,
      success => {
        console.log('success', success);
        if (typeof success === 'object') {
          setUserInfo(success)
        }
      },
      err => {
        console.log('err', err);
      },
      fail => {
        console.log('fail', fail);
      }
    )
    return true
  }

  const isFocused = useIsFocused()

  useEffect(() => {
    if (isFocused) {
      getUserInfo().then(() => setLoading(false))
    }
  }, [isFocused])


  return (
    <>
      <Header hideBack title="My Info" />
      <LoadingModal visible={loading} />
      <ScrollView>
        <View className="pl-4 pr-4">
          <PrimaryButton
            rootClass="mt-5 "
            title={"Upload Photos"}
            onClick={() => {
              navigation.navigate("imageUpload");
            }}
          />
        </View>
        <View className="p-4">
          <View
            className={` bg-gray-200 py-2 px-2 flex items-center flex-row justify-between `}
          >
            <Text className="text-primary font-semibold">BASIC INFORMATION</Text>
            <Pressable onPress={() => navigation.navigate("SignUpUpdate")}>
              <Text className="bg-primary text-white py-1 px-3 rounded-md">
                Edit
              </Text>
            </Pressable>
          </View>
          <View className="pl-2 bg-white pt-2 pb-2">
            <SpecificData
              sub="Name"
              value={`${basicInfo?.first_name || ""} ${basicInfo?.middle_name || ""
                } ${basicInfo?.last_name || ""}`}
            />
            <SpecificData
              sub="mobile"
              value={basicInfo?.mobile_number || ""}
            />
            <SpecificData
              sub="Whatsapp"
              value={basicInfo?.whatsapp_number || ""}
            />
            <SpecificData sub="Email" value={basicInfo?.email || ""} />
            <SpecificData sub="DoB" value={basicInfo?.dob || ""} />
            <SpecificData sub="Aakna" value={basicInfo?.aakana?.label || ""} />
            <SpecificData
              sub="Religion"
              value={basicInfo?.religion?.label || ""}
            />
            <SpecificData
              sub="Country"
              value={basicInfo?.country?.label || ""}
            />
            <SpecificData sub="State" value={basicInfo?.state?.label || ""} />
            <SpecificData sub="City" value={basicInfo?.city?.label || ""} />
            <SpecificData sub="Gender" value={basicInfo?.gender || ""} />
            <SpecificData sub="Pincode" value={basicInfo?.pincode || ""} />
          </View>
        </View>
        <View className="p-4">
          <View
            className={` bg-gray-200 py-2 px-2 flex items-center flex-row justify-between `}
          >
            <Text className="text-primary font-semibold">PERSONAL INFORMATION</Text>
            <Pressable onPress={() => navigation.navigate("SignUpUpdate")}>
              <Text className="bg-primary text-white py-1 px-3 rounded-md">
                Edit
              </Text>
            </Pressable>
          </View>
          <View className="pl-2 bg-white pt-2 pb-2">
            <SpecificData
              sub="Name"
              value={`${basicInfo?.first_name || ""} ${basicInfo?.middle_name || ""
                } ${basicInfo?.last_name || ""}`}
            />
            <SpecificData
              sub="mobile"
              value={basicInfo?.mobile_number || ""}
            />
            <SpecificData
              sub="Whatsapp"
              value={basicInfo?.whatsapp_number || ""}
            />
            <SpecificData sub="Email" value={basicInfo?.email || ""} />
            <SpecificData sub="DoB" value={basicInfo?.dob || ""} />
            <SpecificData sub="Aakna" value={basicInfo?.aakana?.label || ""} />
            <SpecificData
              sub="Religion"
              value={basicInfo?.religion?.label || ""}
            />
            <SpecificData
              sub="Country"
              value={basicInfo?.country?.label || ""}
            />
            <SpecificData sub="State" value={basicInfo?.state?.label || ""} />
            <SpecificData sub="City" value={basicInfo?.city?.label || ""} />
            <SpecificData sub="Gender" value={basicInfo?.gender || ""} />
            <SpecificData sub="Pincode" value={basicInfo?.pincode || ""} />
          </View>
        </View>
      </ScrollView>
    </>
  );
};

export default MyInfo;
