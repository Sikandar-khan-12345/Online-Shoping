import { View, ScrollView, Text, StyleSheet } from "react-native";
import React, { useEffect, useState } from "react";
import Header from "../Components/Header/Header";
import TextField from "../Components/Textfield/TextField";
import SelectInput from "../Components/Textfield/SelectInput";
import PrimaryButton from "../Components/Button/PrimaryButton";
import axios from "axios";
import Loader from "../Components/Loader/Loader";
import { useIsFocused, useNavigation, useRoute } from "@react-navigation/native";
import { useDispatch, useSelector } from "react-redux";
import {
  basicDetailsUpdateInputs,
  createdByOptions,
  genderOptions,
  RequiredBasicDetails,
} from "../utils/data";
import { formRequiredValidationErrorGen } from "../utils/utils";
import {
  setUserInfo,
  setUserProfileInfo,
  setVerifyEmail,
  signupUser,
  updateBasicDetails,
} from "../features/userSlice";
import { useToast } from "react-native-toast-notifications";
import { API, POST, POST_FORMDATA } from "../utils/Backend/backend";
import { REGISTER } from "../utils/Backend/end_points";
import SelectPicker from "../Components/SelectPicker";
import AsyncStorage from "@react-native-async-storage/async-storage";
import variables from "../utils/variables";
import Dropdown from "../Components/Ui/Dropdown";
import Checkbox from "expo-checkbox";
import colors from "../utils/colors";
import DatePicker from "../Components/Ui/DatePicker";
import Picker from "../Components/Ui/Picker";
import { isOver18 } from "../src/Constants/functions";
import moment from "moment";
import { ErrorBox } from "../src/components/UI/CommonTextInput";

const SignUpScreen = () => {
  const userProfileInfo = useSelector((store) => store?.user?.userProfileInfo || {});
  const toast = useToast();
  const [values, setValues] = useState({
    profile_created_by: { label: 'Self', value: 'SELF' },
    country: { label: 'India', value: 'India' },
    religion: { label: 'Hindu', value: 'Hindu' },
  });
  const [errors, setErrors] = useState({});
  const [options, setOptions] = useState({
    profile_created_by: createdByOptions,
    gender: genderOptions,
  });
  const [loading, setLoading] = useState(false);

  console.log(errors);

  const fetchInitialOptions = async () => {
    setLoading(true);
    try {
      const res = await Promise.all([
        axios.get("./countries"),
        axios.get("./religions"),
        axios.get("./aakanas"),
      ]);
      const data = res.map((res) => res.data);
      let optionsUpdate = { ...options };
      data.forEach((res, i) => {
        console.log(res);
        if (res.success) {
          if (i === 0 && Array.isArray(res?.data)) {
            optionsUpdate.country = res?.data;
          } else if (i === 1 && Array.isArray(res?.data)) {
            optionsUpdate.religion = res?.data;
          } else if (i === 2 && Array.isArray(res?.data)) {
            optionsUpdate.aakana = res?.data;
          }
        }
      });
      console.log(optionsUpdate);
      setOptions(optionsUpdate);
      setLoading(false);
      return optionsUpdate
    } catch (e) {
      console.log(e);
      toast.show(e?.message || "Failed to Fetch Options", {
        type: "danger",
      });
      setLoading(false);
      return {}
    }
  };

  const CatchErrorHandler = (e) => { };
  const dropdwonResponseHandler = (data, optionsName, oldData = {}) => {
    setLoading(false);
    // if (data?.success) {
    if (Array.isArray(data?.data)) {
      let obj = { ...oldData }
      obj[optionsName] = data?.data
      setOptions(obj);
    }
    // } else {
    // }

    console.log(res);
  };
  const fetchStatesByCountry = (country, data) => {
    // if (!country) {
    //   return;
    // }
    // alert()
    setLoading(true);
    axios
      .get(`/statesForCountry?country_label=India`)
      .then((res) => {
        console.log('---------------', res.data);
        dropdwonResponseHandler(res?.data, "state", data);
      })

      .catch(CatchErrorHandler);
  };
  const fetchCitiesByState = (state) => {
    if (!state) {
      return;
    }
    setLoading(true);
    axios
      .get(`/citiesForState?state_label=${state?.value}`)
      .then((res) => {
        dropdwonResponseHandler(res?.data, "city", options);
      })
      .catch(CatchErrorHandler);
  };
  const isFocused = useIsFocused()
  useEffect(() => {
    if (isFocused) {
      fetchInitialOptions().then((e) => {
        fetchStatesByCountry('India', e)
      })
    }
  }, [isFocused]);

  const user = useSelector((state) => state?.user?.user?.user || {});
  const rootUser = useSelector((state) => state?.user?.user || {});
  console.log(rootUser, 'some')

  const route = useRoute();
  const isUpdate = route?.name === "SignUpUpdate";

  useEffect(() => {
    if (user && isUpdate) {
      let basicDetails = {
        profile_created_by: createdByOptions?.filter(
          (each) => each.value == user.profile_created_by
        )[0],
        first_name: user.first_name || "",
        middle_name: user.middle_name || "",
        last_name: user.last_name || "",
        gender: genderOptions?.filter((each) => each.value == user.gender)[0],
        email: user.email || "",
        mobile_number: user.mobile_number || "",
        whatsapp_number: user.whatsapp_number || "",
        // date: user?.dob?.split("-")[2],
        // month: user?.dob?.split("-")[1],
        // year: user?.dob?.split("-")[0],
        dob: user?.dob,
        aakana: user?.aakana || null,
        religion: user?.religion || null,
        country: user?.country || null,
        state: user?.state || null,
        city: user?.city || null,
        pincode: user?.pincode || "",
      };
      setValues({ ...basicDetails });
    }
  }, []);

  const navigation = useNavigation();
  const cb = (success, data) => {
    console.log(data);
    setLoading(false);
    if (success) {
      toast.show(
        `${data.message || ""} , Please log in` || "User Created Successfully",
        {
          type: "success",
        }
      );
      if (isUpdate) navigation.navigate("myInfo");
      else {
        const { email, password } = values
        navigation.navigate("mobileVerification", { email, password })
      }
      dispatch(setVerifyEmail(values?.email || ""));
    } else {
      setErrors(data);
      toast.show("Please check the Field Errors", {
        type: "danger",
      });
    }
  };
  const dispatch = useDispatch();
  const submitClickHandler = async () => {
    let formValues = { ...values };

    //  let tob = `${values.year||''}-${values.month||""}-${values?.date}`
    let [isErrors, errors] = formRequiredValidationErrorGen(
      formValues,
      isUpdate ? basicDetailsUpdateInputs : RequiredBasicDetails
    );
    if (!values['terms_conditions']) {
      isErrors = true
      errors.terms_conditions = ['Please accept the terms and conditions.']
    }
    if (
      !values?.dob
    ) {
      isErrors = true;
      errors.dob = ["Date of Birth is required"];
    } else if (!isOver18(moment(values?.dob, 'YYYY-MM-DD'))) {
      isErrors = true;
      errors.dob = ["Age should be greater than or equal to 18 years."];
    }
    if (values?.password !== values?.cpassword) {
      isErrors = true
      errors.cpassword = ["Password and confirm password should match"]
    }
    if (isErrors) {
      setErrors(errors);
      toast.show("Please check the Field Errors", {
        type: "danger",
      });
      return;
    }
    // let dob = `${values.year || ""}-${values.month || ""}-${values?.date}`;
    delete formValues.year;
    delete formValues.month;
    delete formValues.date;
    delete formValues.country;
    delete formValues.state;
    formValues.dob = values?.dob;
    formValues.profile_created_by = values?.profile_created_by?.value;
    formValues.city = values?.city?.value;
    formValues.aakana = values?.aakana?.value;
    formValues.religion = values?.religion?.value;
    formValues.gender = values?.gender?.value;
    setLoading(true);
    if (isUpdate) {
      axios.defaults.headers.common['Authorization'] = `Bearer ${rootUser?.access_token}`
      dispatch(updateBasicDetails({ payload: formValues, cb: cb }));
    }
    else {

      let obj = { ...userProfileInfo }
      obj.basicInfo = formValues
      await AsyncStorage.setItem(variables.USER_PROFILE_INFO, JSON.stringify(obj))
      dispatch(setUserProfileInfo(obj))
      dispatch(setUserInfo({ user: formValues }));
      dispatch(signupUser({ payload: formValues, cb: cb }))
    };
  };
  const setSameAsMobile = () => {
    if ((values['mobile_number'] == values['whatsapp_number'])) {
      let obj = { ...values }
      obj['whatsapp_number'] = ''
      setValues(obj)
    } else {
      let obj = { ...values }
      obj['whatsapp_number'] = values['mobile_number']
      setValues(obj)
    }
  }

  const navigate = (route) => navigation.navigate(route)

  return (
    <View className="h-[100%] bg-gray-200">
      {loading && <Loader />}
      <Header
        leftIcon={'back'}
        leftIconColor={colors.white}
        title={isUpdate ? "Update Basic Info" : "Create Your Profile"} />
      <ScrollView className=" px-4  mb-2 ">
        <View style={{ height: 20 }} />
        <Picker
          // rootClassName="mt-3"
          label="Created by *"
          placeholder="Created by *"
          name="profile_created_by"
          values={values}
          setValues={setValues}
          options={options.profile_created_by}
          errors={errors}
          setErrors={setErrors}
        />
        <TextField
          label="First Name *"
          placeholder="First Name *"
          name="first_name"
          values={values}
          setValues={setValues}
          type="Text"
          errors={errors}
          setErrors={setErrors}
        />
        <TextField
          label="Middle Name "
          placeholder="Middle Name "
          name="middle_name"
          values={values}
          setValues={setValues}
          type="Text"
          errors={errors}
          setErrors={setErrors}
        />
        <TextField
          label="Last Name *"
          placeholder="Last Name *"
          name="last_name"
          values={values}
          setValues={setValues}
          type="Text"
          errors={errors}
          setErrors={setErrors}
        />
        <Picker
          rootClassName=""
          label="Gender *"
          placeholder="Select Gender *"
          name="gender"
          values={values}
          setValues={setValues}
          options={options.gender}
          errors={errors}
          setErrors={setErrors}
        />
        {!isUpdate && (
          <TextField
            label="Email *"
            placeholder="Email *"
            name="email"
            values={values}
            keyboardType={'email-address'}
            setValues={setValues}
            type="email"
            errors={errors}
            setErrors={setErrors}
          />
        )}

        {!isUpdate && (
          <TextField
            type="number"
            maxLength={10}
            // label="Mobile *"
            placeholder="Mobile *"
            mobileNumber
            name="mobile_number"
            keyboardType={'numeric'}
            values={values}
            setValues={setValues}
            errors={errors}
            setErrors={setErrors}
          />
        )}
        <TextField
          // label="Whatsapp *"
          placeholder="Whatsapp *"
          mobileNumber
          name="whatsapp_number"
          keyboardType={'numeric'}
          values={values}
          setValues={setValues}
          type="number"
          maxLength={10}
          errors={errors}
          setErrors={setErrors}
        />
        <View style={{ flexDirection: 'row', marginBottom: 15, alignItems: 'center' }}>
          <View>
            <Checkbox style={{}}
              color={((values['mobile_number'] == values['whatsapp_number']) && (values['whatsapp_number']) && (values['mobile_number'])) ? colors.primary : undefined}
              value={(values['mobile_number'] == values['whatsapp_number']) && (values['whatsapp_number']) && (values['mobile_number'])}
              onValueChange={setSameAsMobile} />
          </View>
          <Text style={{ marginLeft: 10, color: colors.black, fontSize: 16 }}>Same as mobile number.</Text>
        </View>
        <DatePicker
          name={'dob'}
          values={values}
          errors={errors}
          label={'Date of Birth *'}
          setErrors={setErrors}
          setValues={setValues}
        />
        {/* <Text className="mb-3">Date of Birth * : </Text>
        <View style={{ justifyContent: 'space-between' }} className="flex flex-row ">
          <View style={{ width: '32%' }}>
            <TextField
              label="Date "
              placeholder="DD"
              name="date"
              values={values}
              setValues={setValues}
              rootClassName="mr-2 w-20"
              type="number"
              errors={errors}
              setErrors={setErrors}
              maxLength={2}
            />
          </View>
          <View style={{ width: '32%' }}>
            <TextField
              label="Month"
              placeholder="MM"
              name="month"
              values={values}
              setValues={setValues}
              rootClassName="mr-2 w-20"
              type="number"
              maxLength={2}
              errors={errors}
              setErrors={setErrors}
            />
          </View>
          <View style={{ width: '32%' }}>
            <TextField
              label="Year"
              placeholder="YYYY"
              name="year"
              values={values}
              setValues={setValues}
              rootClassName="flex-1"
              type="number"
              maxLength={4}
              errors={errors}
              setErrors={setErrors}
            />
          </View>
        </View> */}
        {errors?.dob?.length ? (
          <Text className="text-red-400 relative mt-[-12px] mb-4">
            {errors?.dob?.[0]}
          </Text>
        ) : null}
        {/* <Text className="mb-3">Time of Birth : </Text>
        <View className="flex flex-row ">
          <TextField
            label="Date"
            placeholder="HH"
            name="date"
            values={values}
            setValues={setValues}
            rootClassName="mr-2 w-20"
            type="number"
            maxHeight={2}
          />
          <TextField
            rootClassName="mr-2 w-20"
            label="Month"
            placeholder="MM"
            name="month"
            values={values}
            setValues={setValues}
            type="number"
            maxHeight={2}
          />
          <TextField
            label="Year"
            placeholder="SS"
            name="Year"
            values={values}
            setValues={setValues}
            rootClassName="flex-1"
            type="number"
            maxHeight={2}
          />
        </View> */}

        <SelectPicker
          label="Aakana *"
          placeholder="Select Aakana *"
          name="aakana"
          values={values}
          setValues={setValues}
          options={options.aakana}
          errors={errors}
          setErrors={setErrors}
        />
        <Picker
          label="Religion *"
          placeholder="Select Religion *"
          name="religion"
          values={values}
          setValues={setValues}
          options={options.religion}
          errors={errors}
          setErrors={setErrors}
        />
        <Picker
          label="Country *"
          placeholder="Select Country *"
          name="country"
          values={values}
          setValues={setValues}
          options={options.country}
          onChange={fetchStatesByCountry}
          errors={errors}
          setErrors={setErrors}
        />
        <SelectPicker
          label="State *"
          placeholder="Select State *"
          name="state"
          values={values}
          setValues={setValues}
          options={options?.state}
          onChange={fetchCitiesByState}
          errors={errors}
          setErrors={setErrors}
        />
        <SelectPicker
          label="City *"
          placeholder="Select City *"
          name="city"
          values={values}
          setValues={setValues}
          options={options.city}
          errors={errors}
          setErrors={setErrors}
        />
        <TextField
          label="Pincode"
          placeholder="Pincode"
          name="pincode"
          values={values}
          setValues={setValues}
          keyboardType={'numeric'}
          maxLength={6}
          errors={errors}
          setErrors={setErrors}
        />
        {!isUpdate && (
          <TextField
            label="Password *"
            placeholder="Min. 8 characters"
            type="password"
            values={values}
            setValues={setValues}
            name="password"
            errors={errors}
            setErrors={setErrors}
          />
        )}
        {!isUpdate && (
          <TextField
            label="Confirm Password *"
            placeholder="Confirm Password *"
            type="password"
            values={values}
            setValues={setValues}
            containerStyle={{
              borderWidth: 1,
              borderColor: errors['cpassword'] ? 'red' :
                (values['cpassword'] === values['password']) && (!!values['cpassword'] && !!values['password'])
                  ? 'green' : 'transparent'
            }}
            name="cpassword"
            errors={errors}
            setErrors={setErrors}
          />
        )}
        <View style={{ flexDirection: 'row', marginBottom: 15, }}>
          <Checkbox style={{ marginTop: 5 }}
            color={values['terms_conditions'] ? colors.primary : undefined}
            value={values['terms_conditions']}
            onValueChange={() => {
              setValues({ ...values, ['terms_conditions']: !values['terms_conditions'] });
              setErrors({ ...errors, ['terms_conditions']: null })
            }} />
          <Text style={{ marginLeft: 10, fontFamily: 'blinker', color: colors.black, fontSize: 16 }}>
            I accept the
            <Text onPress={navigate.bind(this, 'T_C')} style={{ marginLeft: 10, fontFamily: 'blinker', color: colors.primary, fontSize: 16 }}> Terms and Condition </Text> and
            <Text onPress={navigate.bind(this, 'PrivacyPolicy')} style={{ marginLeft: 10, fontFamily: 'blinker', color: colors.primary, fontSize: 16 }}> Privacy Policies.</Text>
          </Text>
        </View>
        {errors?.terms_conditions?.length ? (
          <Text className="text-red-400 relative mt-[-12px] mb-4">
            {errors?.terms_conditions?.[0]}
          </Text>
        ) : null}
        <PrimaryButton
          onClick={submitClickHandler}
          title={isUpdate ? "Update" : "Create my profile"}
        />
      </ScrollView>
    </View>
  );
};

export default SignUpScreen;
