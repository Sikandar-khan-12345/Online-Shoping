import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import Header from '../../Components/Header/Header'
import Card from '../../Components/Ui/Card'
import ScrollContainer from '../../src/components/HOC/ScrollContainer'
import Typography from '../../src/components/UI/Typography'
import colors from '../../utils/colors'

const T_C = () => {
    return (
        <ScrollContainer>
            <Header
                leftIconColor={colors.white}
                leftIcon={'back'} title='Terms and Conditions' />
            <Card>
                <Typography textAlign={'justify'}>
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                </Typography>
            </Card>
        </ScrollContainer>
    )
}

export default T_C

const styles = StyleSheet.create({})