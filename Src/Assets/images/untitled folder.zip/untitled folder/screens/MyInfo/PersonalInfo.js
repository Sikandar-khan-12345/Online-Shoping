import { Pressable, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import SpecificData from '../../Components/SpecificData/SpecificData'
import { useNavigation } from '@react-navigation/native'
const PersonalInfo = ({ data = {} }) => {
    const navigation = useNavigation()
    return (
        <View className="p-4">
            <View
                className={` bg-gray-200 py-2 px-2 flex items-center flex-row justify-between `}
            >
                <Text className="text-primary font-semibold">PERSONAL INFORMATION</Text>
                <Pressable onPress={() => navigation.navigate("Registration2", { indexToUpdate: 1 })}>
                    <Text className="bg-primary text-white py-1 px-3 rounded-md">
                        Edit
                    </Text>
                </Pressable>
            </View>
            <View className="pl-2 bg-white pt-2 pb-2">
                <SpecificData
                    sub="Marital status"
                    value={data?.marital_status}
                />
                <SpecificData
                    sub="Complexion"
                    value={data?.complexion}
                />
                <SpecificData
                    sub="Height"
                    value={data?.height}
                />
                <SpecificData
                    sub="Weight"
                    value={data?.weight}
                />
                <SpecificData
                    sub="Diet"
                    value={data?.diet}
                />
                <SpecificData
                    sub="Disability"
                    value={data?.disability}
                />
            </View>
        </View>
    )
}

export default PersonalInfo

const styles = StyleSheet.create({})