import { Pressable, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import SpecificData from '../../Components/SpecificData/SpecificData'
import { useNavigation } from '@react-navigation/native'
const ContactInfo = ({ data = {} }) => {
    const navigation = useNavigation()
    return (
        <View className="p-4">
            <View
                className={` bg-gray-200 py-2 px-2 flex items-center flex-row justify-between `}
            >
                <Text className="text-primary font-semibold">CONTACT INFORMATION</Text>
                <Pressable onPress={() => navigation.navigate("Registration2", { indexToUpdate: 3 })}>
                    <Text className="bg-primary text-white py-1 px-3 rounded-md">
                        Edit
                    </Text>
                </Pressable>
            </View>
            <View className="pl-2 bg-white pt-2 pb-2">
                <SpecificData
                    sub="Contact number"
                    value={data?.contact_number}
                />
                <SpecificData
                    sub="Father's contact number"
                    value={data?.fathers_contact_number}
                />
                <SpecificData
                    sub="Email"
                    value={data?.email}
                />
                <SpecificData
                    sub="Present address"
                    value={data?.present_address}
                />
                <SpecificData
                    sub="Permanent address"
                    value={data?.permanent_address}
                />
            </View>
        </View>
    )
}

export default ContactInfo

const styles = StyleSheet.create({})