import { Pressable, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { useNavigation } from '@react-navigation/native'
import SpecificData from '../../Components/SpecificData/SpecificData'
const ReligiousInfo = ({ data = {} }) => {
    const navigation = useNavigation()
    return (
        <View className="p-4">
            <View
                className={` bg-gray-200 py-2 px-2 flex items-center flex-row justify-between `}
            >
                <Text className="text-primary font-semibold">RELIGIOUS INFORMATION</Text>
                <Pressable onPress={() => navigation.navigate("Registration2", { indexToUpdate: 4 })}>
                    <Text className="bg-primary text-white py-1 px-3 rounded-md">
                        Edit
                    </Text>
                </Pressable>
            </View>
            <View className="pl-2 bg-white pt-2 pb-2">
                <SpecificData
                    sub="Gotra"
                    value={data?.gotra}
                />
                <SpecificData
                    sub="Mother tongue"
                    value={data?.mother_tongue}
                />
                <SpecificData
                    sub="Birth time"
                    value={data?.birth_time}
                />
                <SpecificData
                    sub="Birth place"
                    value={data?.birth_place}
                />
                <SpecificData
                    sub="Zodiac"
                    value={data?.zodiac}
                />
                <SpecificData
                    sub="Manglik"
                    value={data?.manglik}
                />
                <SpecificData
                    sub="Nakshatra"
                    value={data?.nakshatra}
                />
                <SpecificData
                    sub="Caste"
                    value={data?.caste}
                />
                <SpecificData
                    sub="Sub caste"
                    value={data?.sub_caste}
                />
                {/* <SpecificData
                    sub="open_to_other_ communities"
                    value={data?.open_to_other_communities}
                /> */}
            </View>
        </View>
    )
}

export default ReligiousInfo

const styles = StyleSheet.create({})