import { View, Text, Pressable, ScrollView, Alert } from "react-native";
import React, { useEffect, useState } from "react";
import Header from "../../Components/Header/Header";
import SpecificData from "../../Components/SpecificData/SpecificData";
import { useDispatch, useSelector } from "react-redux";
import { useNavigation, useIsFocused } from "@react-navigation/native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import PrimaryButton from "../../Components/Button/PrimaryButton";
import { API, GET_WITH_TOKEN } from "../../utils/Backend/backend";
import { PROFILE } from "../../utils/Backend/end_points";
import LoadingModal from "../../src/components/UI/LoadingModal";
import BasicInfo from "./BasicInfo";
import PersonalInfo from "./PersonalInfo";
import EducationalInfo from "./EducationalInfo";
import ContactInfo from "./ContactInfo";
import ReligiousInfo from "./ReligiousInfo";
import FamilyInfo from "./FamilyInfo";
import PreferenceInfo from "./PreferenceInfo";
import Dropdown from "../../Components/Ui/Dropdown";
import colors from "../../utils/colors";
import { clearUserInfo } from "../../features/userSlice";
import { updateAuth } from "../../features/authReducer";
import DatePicker from "../../Components/Ui/DatePicker";

const MyInfo = ({ route }) => {
  const navigation = useNavigation();
  const [userInfo, setUserInfo] = useState({})
  const [loading, setLoading] = useState(true)
  const user = useSelector((state) => state?.user?.user?.user || {});
  const user2 = useSelector((state) => state?.user?.userProfileInfo || {});

  // let basicInfo = { ...userInfo?.basicInfo }
  const {
    personalInfo,
    educationalInfo,
    contactInfo,
    religiousInfo,
    familyInfo,
    preferenceInfo,
    basicInfo
  } = userInfo
  // console.log(basicInfo);

  const getUserInfo = async () => {
    await GET_WITH_TOKEN(
      API + PROFILE,
      success => {
        console.log('success', success);
        if (typeof success === 'object') {
          setUserInfo(success)
        }
      },
      err => {
        console.log('err', err);
      },
      fail => {
        console.log('fail', fail);
        toast.show(`Check network,Try again.`)
      }
    )
    return true
  }

  const isFocused = useIsFocused()
  const dispatch = useDispatch()

  useEffect(() => {
    if (isFocused) {
      getUserInfo().then(() => setLoading(false))
    }
  }, [isFocused])

  const handleLogout = () => {
    Alert.alert(
      'Logout',
      'Are you sure,you want to logout?',
      [
        {
          text: 'Cancel',
          style: 'cancel',
          onPress: () => null
        },
        {
          text: 'OK',
          style: 'default',
          onPress: () => {
            dispatch(clearUserInfo())
            dispatch(updateAuth(false))
          }
        },
      ]
    )
  }
  return (
    <>
      <Header
        rightText={'LOGOUT'}
        onRightPress={handleLogout}
        rightIconSize={20}
        title="My Profile" />
      <LoadingModal visible={loading} />
      <ScrollView>
        <View className="pl-4 pr-4">
          <PrimaryButton
            rootClass="mt-5 "
            title={"Upload Photos"}
            onClick={() => {
              navigation.navigate("imageUpload");
            }}
          />
        </View>
        <BasicInfo basicInfo={basicInfo} />
        <PersonalInfo data={personalInfo} />
        <EducationalInfo data={educationalInfo} />
        <ContactInfo data={contactInfo} />
        <ReligiousInfo data={religiousInfo} />
        <FamilyInfo data={familyInfo} />
        <PreferenceInfo data={preferenceInfo} />
      </ScrollView>
    </>
  );
};

export default MyInfo;
