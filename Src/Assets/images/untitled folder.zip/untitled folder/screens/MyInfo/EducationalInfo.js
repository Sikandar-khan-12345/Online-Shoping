import { Pressable, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import SpecificData from '../../Components/SpecificData/SpecificData'
import { useNavigation } from "@react-navigation/native"
const EducationalInfo = ({ data = {} }) => {
    const navigation = useNavigation()
    return (
        <View className="p-4">
            <View
                className={` bg-gray-200 py-2 px-2 flex items-center flex-row justify-between `}
            >
                <Text className="text-primary font-semibold">EDUCATIONAL INFORMATION</Text>
                <Pressable onPress={() => navigation.navigate("Registration2", { indexToUpdate: 2 })}>
                    <Text className="bg-primary text-white py-1 px-3 rounded-md">
                        Edit
                    </Text>
                </Pressable>
            </View>
            <View className="pl-2 bg-white pt-2 pb-2">
                <SpecificData
                    sub="Highest education"
                    value={data?.highest_education}
                />
                <SpecificData
                    sub="College attended"
                    value={data?.college_attended}
                />
                <SpecificData
                    sub="Employed in"
                    value={data?.employed_in}
                />
                <SpecificData
                    sub="Profession"
                    value={data?.profession}
                />
                <SpecificData
                    sub="Current company name"
                    value={data?.current_company_name}
                />
                <SpecificData
                    sub="Annual income"
                    value={data?.annual_income}
                />
            </View>
        </View>
    )
}

export default EducationalInfo

const styles = StyleSheet.create({})