import { Pressable, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import SpecificData from '../../Components/SpecificData/SpecificData'
import { useNavigation } from '@react-navigation/native'
const PreferenceInfo = ({ data = {} }) => {
    const navigation = useNavigation()
    return (
        <View className="p-4">
            <View
                className={` bg-gray-200 py-2 px-2 flex items-center flex-row justify-between `}
            >
                <Text className="text-primary font-semibold">PREFERENCE INFORMATION</Text>
                <Pressable onPress={() => navigation.navigate("Registration2", { indexToUpdate: 6 })}>
                    <Text className="bg-primary text-white py-1 px-3 rounded-md">
                        Edit
                    </Text>
                </Pressable>
            </View>
            <View className="pl-2 bg-white pt-2 pb-2">
                <SpecificData
                    sub="Age"
                    value={data?.age}
                />
                <SpecificData
                    sub="Height"
                    value={data?.height}
                />
                <SpecificData
                    sub="Marital status"
                    value={data?.marital_status}
                />
                <SpecificData
                    sub="Profession"
                    value={data?.profession}
                />
                <SpecificData
                    sub="State"
                    value={data?.state}
                />
                <SpecificData
                    sub="City"
                    value={data?.city}
                />
                <SpecificData
                    sub="Drinking"
                    value={data?.drinking}
                />
                <SpecificData
                    sub="Smoking"
                    value={data?.smoking}
                />
                <SpecificData
                    sub="Diet"
                    value={data?.diet}
                />
            </View>
        </View>
    )
}

export default PreferenceInfo

const styles = StyleSheet.create({})