import { Pressable, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import SpecificData from '../../Components/SpecificData/SpecificData'
import { useNavigation } from "@react-navigation/native"
const FamilyInfo = ({ data = {} }) => {
    const navigation = useNavigation()
    return (
        <View className="p-4">
            <View
                className={` bg-gray-200 py-2 px-2 flex items-center flex-row justify-between `}
            >
                <Text className="text-primary font-semibold">FAMILY INFORMATION</Text>
                <Pressable onPress={() => navigation.navigate("Registration2", { indexToUpdate: 5 })}>
                    <Text className="bg-primary text-white py-1 px-3 rounded-md">
                        Edit
                    </Text>
                </Pressable>
            </View>
            <View className="pl-2 bg-white pt-2 pb-2">
                <SpecificData
                    sub="Father name"
                    value={data?.father_name}
                />
                <SpecificData
                    sub="Father profession"
                    value={data?.father_profession}
                />
                <SpecificData
                    sub="Mother name"
                    value={data?.mother_name}
                />
                <SpecificData
                    sub="Mother profession"
                    value={data?.mother_profession}
                />
                <SpecificData
                    sub="Married brother"
                    value={data?.married_brother}
                />
                <SpecificData
                    sub="Unmarried brother"
                    value={data?.unmarried_brother}
                />
                <SpecificData
                    sub="Married sister"
                    value={data?.married_sister}
                />
                <SpecificData
                    sub="Unmarried sister"
                    value={data?.unmarried_sister}
                />
                <SpecificData
                    sub="Maternal uncle name"
                    value={data?.maternal_uncle_name}
                />
                <SpecificData
                    sub="Maternal uncle aakana"
                    value={data?.maternal_uncle_aakana}
                />
                <SpecificData
                    sub="House"
                    value={data?.house}
                />
                <SpecificData
                    sub="Car"
                    value={data?.car}
                />
            </View>
        </View>
    )
}

export default FamilyInfo

const styles = StyleSheet.create({})