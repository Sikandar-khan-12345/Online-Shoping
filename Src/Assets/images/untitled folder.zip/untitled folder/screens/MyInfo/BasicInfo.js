import { Pressable, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { useNavigation } from '@react-navigation/native'
import SpecificData from '../../Components/SpecificData/SpecificData'
import moment from 'moment'
const BasicInfo = ({ basicInfo = {} }) => {
  const navigation = useNavigation()
  return (
    <View className="p-4">
      <View
        className={` bg-gray-200 py-2 px-2 flex items-center flex-row justify-between `}
      >
        <Text className="text-primary font-semibold">BASIC INFORMATION</Text>
        <Pressable onPress={() => navigation.navigate("Registration2", { indexToUpdate: 0 })}>
          <Text className="bg-primary text-white py-1 px-3 rounded-md">
            Edit
          </Text>
        </Pressable>
      </View>
      <View className="pl-2 bg-white pt-2 pb-2">
        <SpecificData
          sub="Name"
          value={`${basicInfo?.first_name || ""} ${basicInfo?.middle_name || ""
            } ${basicInfo?.last_name || ""}`}
        />
        <SpecificData
          sub="Mobile"
          value={basicInfo?.mobile_number || ""}
        />
        <SpecificData
          sub="WhatsApp"
          value={basicInfo?.whatsapp_number || ""}
        />
        <SpecificData sub="Email" value={basicInfo?.email || ""} />
        <SpecificData sub="Date of Birth" value={moment(basicInfo?.dob, 'YYYY-MM-DD').format('DD-MMMM-YYYY') || ""} />
        <SpecificData sub="Aakna" value={basicInfo?.aakana?.label || ""} />
        <SpecificData
          sub="Religion"
          value={basicInfo?.religion?.label || ""}
        />
        <SpecificData
          sub="Country"
          value={basicInfo?.country?.label || ""}
        />
        <SpecificData sub="State" value={basicInfo?.state?.label || ""} />
        <SpecificData sub="City" value={basicInfo?.city?.label || ""} />
        <SpecificData sub="Gender" value={basicInfo?.gender || ""} />
        <SpecificData sub="Pincode" value={basicInfo?.pincode || ""} />
      </View>
    </View>
  )
}

export default BasicInfo

const styles = StyleSheet.create({})