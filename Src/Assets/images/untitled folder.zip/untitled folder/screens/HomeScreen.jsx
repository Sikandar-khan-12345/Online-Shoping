import * as React from "react";
import { StatusBar } from "expo-status-bar";
import { ImageBackground, Text, View } from "react-native";
import PrimaryButton from "../Components/Button/PrimaryButton";
import { useNavigation } from "@react-navigation/native";
import { useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useDispatch } from "react-redux";
import { setUserInfo } from "../features/userSlice";
import { StyleSheet } from "react-native";
import { FocusAwareStatusBar } from "../Components/Ui/FocusAwareStatusBar";
import colors from "../utils/colors";

const HomeScreen = () => {
  const navigation = useNavigation();
  const loginClickHandler = () => {
    navigation.navigate("login");
  };
  const signupClickHandler = () => {
    navigation.navigate("signUp");
  };

  const dispatch = useDispatch();
  // useEffect(() => {
  //   AsyncStorage.getItem("user")
  //     .then((data) => {
  //       if (data) {
  //         dispatch(setUserInfo(JSON.parse(data)));
  //         navigation.navigate("myInfo");
  //       }
  //     })
  //     .catch((e) => {
  //       console.log(e);
  //     });
  // }, []);

  return (
    <ImageBackground
      source={require("../assets/home_bg.jpg")}
      style={styles.screen}
    >
      <FocusAwareStatusBar backgroundColor={colors.black} />
      <View
        style={styles.screen}
        className="pt-10 pl-5 pr-5 pb-7 flex h-screen"
      >
        <Text className="text-xl font-[blinker] font-bold text-white ">
          Gahoi Rishtey
        </Text>

        <View className="mt-auto  ">
          <View className='flex h-14'>
            <PrimaryButton
              title={"Register"}
              onClick={signupClickHandler}
              rootClass="flex-1 "
              subText="new member ?"
            />
          </View>

          <View className="flex flex-row mt-5">
            <PrimaryButton
              title={"Explore the App"}
              onClick={loginClickHandler}
              rootClass="flex-1 mr-2 "
              isOutline
            />
            <PrimaryButton
              title={"Login"}
              onClick={loginClickHandler}
              rootClass="flex-1 ml-2"
              isOutline
              subText="already a member?"
            />
          </View>
        </View>
      </View>
    </ImageBackground>
  );
};

export default HomeScreen;

const styles = StyleSheet.create({
  screen: {
    height: "100%",
  },
});
