import * as React from "react";
import { persistor, store } from './store'
import { Provider } from 'react-redux'
import { NativeWindStyleSheet } from "nativewind";
import axios from "axios";
import { ToastProvider } from 'react-native-toast-notifications'
import { useFonts } from 'expo-font';
import Toast from "react-native-toast-notifications";
import RootNavigation from "./src/navigation/RootNavigation";
import { PersistGate } from 'redux-persist/integration/react';
import { toastRef } from "./utils/Backend/backend";
NativeWindStyleSheet.setOutput({
  default: "native",
});

axios.defaults.baseURL = "https://gahoirishtey.com/api"

const App = () => {


  const [loaded] = useFonts({
    blinker: require('./assets/fonts/Blinker-Regular.ttf'),
  });
  global.print = (...arg) => console.log(...arg)


  if (!loaded) {
    return null;
  }
  return (
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <ToastProvider>
          <RootNavigation />
        </ToastProvider>
        <Toast ref={(ref) => {
          global['toast'] = ref
          toastRef.current = ref
        }} />
      </PersistGate>
    </Provider>
  );
}

export default App