import { configureStore } from '@reduxjs/toolkit'
import userSlice from './features/userSlice'
import { combineReducers } from '@reduxjs/toolkit';
import { persistReducer } from 'redux-persist';
import storage from '@react-native-async-storage/async-storage';
import authReducer from './features/authReducer';
import { persistStore } from 'redux-persist';
const authReducerPersistConfig = {
  key: 'authReducer',
  storage,
};

const rootReducer = combineReducers({
    user: userSlice,
    auth: persistReducer(authReducerPersistConfig,authReducer),
});

const store = configureStore({
  reducer: rootReducer
})

const persistor = persistStore(store, null, () => {
  // This callback will be called once the persistence has completed.
  console.log('Persistence completed for exampleReducer1');
});

export { store, persistor };
