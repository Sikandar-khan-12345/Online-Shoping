import { createSlice } from "@reduxjs/toolkit";
const initialState = {
    isAuth: false,
}
export const authReducer = createSlice({
    name: 'auth',
    initialState,
    reducers: {
        updateAuth: (state, action) => {
            // alert(action.payload)
            state.isAuth = action.payload
        }
    }
})

export const { updateAuth } = authReducer.actions

export default authReducer.reducer;