
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const initialState = {
    isLoading: false,
    user: null,
    email: null,
    userProfileInfo: null
}

export const signInUser = createAsyncThunk('/login', (data) => {
    return axios.post('/login', data.payload).then(res => {
        if (res.data?.success) {
            data.cb(true, res.data)
        }
        else
            data.cb(false, res?.data)

        return res.data
    }
    ).catch(e => {
        data.cb(false, e.response?.data)
        throw new Error(e.response?.data)
        //  return e.response?.data
    })
});

export const signupUser = createAsyncThunk('/register', (data) => {
    return axios.post('/register', data.payload).then(res => {
        if (res.data?.success) {
            data.cb(true, res.data)
        }
        else {
            data.cb(false, res?.data)
            throw new Error(e.response?.data)
        }

        return res.data
    }
    ).catch(e => {
        data.cb(false, e.response?.data)
        throw new Error(e.response?.data)
    })
});
export const uploadImages = createAsyncThunk('/profile/images', (data) => {
    // console.log('--------',data);
    return axios.post('/profile/images', data.payload, { headers: data?.headers }).then(res => {
        if (res.data?.success) {
            console.warn('response', res);
            data.cb(true, res.data)
        }
        else {
            console.warn('errr', res);
            data.cb(false, res?.data)
            throw new Error(e.response?.data)
        }

        return res.data
    }
    ).catch(e => {
        data.cb(false, e.response?.data)
        throw new Error(e.response?.data)
    })
});
export const updateBasicDetails = createAsyncThunk('/profile?page=basicInfo', (data) => {
    return axios.patch('/profile?page=basicInfo', data.payload).then(res => {
        if (res.data?.success) {
            data.cb(true, res.data)
        }
        else {
            data.cb(false, res?.data)
            throw new Error(e.response?.data)
        }
        return res.data
    }
    ).catch(e => {
        data.cb(false, e.response?.data)
        throw new Error(e.response?.data)
    })
});

export const userSlice = createSlice({
    name: 'user',
    initialState,
    reducers: {
        setUserInfo: (state, action) => {
            state.user = action.payload;
        },
        setUserProfileInfo: (state, action) => {
            console.log('11111', action.payload)
            state.userProfileInfo = action.payload;
        },
        setVerifyEmail: (state, action) => {
            state.email = action.payload;
        },
        clearUserInfo: (state, action) => {
            console.log(action, 'some action')
            AsyncStorage.removeItem('user')
            state.user = null
            state.isLoading = false
        }
    },
    extraReducers: builder => {
        builder.addCase(signInUser.pending, (state, action) => {
            state.isLoading = true;
        })
        builder.addCase(signInUser.fulfilled, (state, action) => {
            AsyncStorage.setItem('user', JSON.stringify(action?.payload?.data));
            state.user = action.payload?.data;
            state.isLoading = false;
        })
        builder.addCase(signInUser.rejected, (state, action) => {
            state.isLoading = false;
        })

        builder.addCase(signupUser.pending, (state, action) => {
            state.isLoading = true;
        })
        builder.addCase(signupUser.fulfilled, (state, action) => {
            // AsyncStorage.setItem('user', JSON.stringify(action?.payload?.data));
            state.user = action.payload;
            state.isLoading = false;
        })
        builder.addCase(signupUser.rejected, (state, action) => {
            state.isLoading = false;
        })
        builder.addCase(updateBasicDetails.pending, (state, action) => {
            state.isLoading = true;
        })
        builder.addCase(updateBasicDetails.fulfilled, (state, action) => {
            // state.user = action.payload;
            let update = state?.user;
            update.user = action.payload.basicInfo
            state.user = update;
            AsyncStorage.setItem('user', JSON.stringify(update));

            state.isLoading = false;
        })
        builder.addCase(updateBasicDetails.rejected, (state, action) => {
            state.isLoading = false;
        })
    }
})

export const { setUserInfo, clearUserInfo, setVerifyEmail, setUserProfileInfo } = userSlice.actions

export default userSlice.reducer;
