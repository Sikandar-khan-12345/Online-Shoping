import { View, Text, Pressable, StatusBar, TouchableOpacity, StyleSheet } from "react-native";
import React, { memo } from "react";
import Icon from "react-native-vector-icons/FontAwesome";
import MuiIcon from "react-native-vector-icons/MaterialIcons";
import { useDispatch, useSelector } from "react-redux";
import { clearUserInfo } from "../../features/userSlice";
import colors from "../../utils/colors";
import { FULL_WIDTH } from "../../utils/layout";
import { FocusAwareStatusBar } from "../Ui/FocusAwareStatusBar";
import Typography from "../../src/components/UI/Typography";
import SvgIcon from "../Svg";
import Press from "../../src/components/HOC/Press";
import { DrawerActions, useNavigation } from '@react-navigation/native';


const Header = ({
  title,
  hideBack,
  backgroundColor = colors.primary,
  translucent,
  height = 55,
  width = FULL_WIDTH,
  leftIcon,
  leftIconSize = 25,
  leftIconColor,
  leftIconStyle,
  rightIcon,
  rightText,
  rightIconColor,
  rightIconSize = 25,
  rightIconStyle,
  paddingHorizontal = 12,
  onLeftPress = () => { },
  onRightPress = () => { },
  renderCenter,
  renderRight,
  secondRightIcon,
  secondRightIconStyle,
  secondRightIconSize,
  secondRightIconColor,
  leftMenuIcon,
  leftMenuIconSize = 30,
  leftMenuIconColor,
  iconContainerWidth = 50,
  headerStyle,
  rightIconImg,
  rightBellIcon,
  titleColor = colors.white,
  titleSize = 17
}) => {
  const navigation = useNavigation();
  const goBackHandler = () => {
    if (navigation.canGoBack()) {
      navigation.goBack();
    }
  };
  const dispatch = useDispatch();
  const clearUserHandler = () => {
    dispatch(clearUserInfo());
    navigation.navigate("home");
  };
  const user = useSelector((state) => state?.user?.user?.user);
  return (
    <View style={{ backgroundColor }}>
      <View
        style={[
          styles.container(height, width, backgroundColor, paddingHorizontal),
          { ...headerStyle }
        ]}>
        <FocusAwareStatusBar
          backgroundColor={backgroundColor}
          translucent={translucent}
        />
        <View
          style={[
            [
              styles.contentContainer('flex-start', 0),
              { minWidth: iconContainerWidth },
            ],
          ]}>
          {!!leftIcon && (
            <Press
              // onPress={onLeftPress}
              onPress={() => leftIcon === 'back' ? navigation?.goBack() : onLeftPress()}
              style={leftIconStyle}>
              <SvgIcon
                size={leftIconSize}
                name={leftIcon}
                color={leftIconColor}
              />
              {/* <Image
              style={{ height: 22, width: 22 }}
              resizeMode="contain"
              source={leftIcon}
            /> */}
            </Press>
          )}
          {!!leftMenuIcon && (
            <Press
              onPress={() => {
                navigation.dispatch(DrawerActions.openDrawer);
              }}
              style={leftIconStyle}>
              <SvgIcon size={40} name={'menu'} color={leftIconColor} />
            </Press>
          )}
        </View>
        {renderCenter ? (
          renderCenter()
        ) : (
          <View
            style={{ flex: 1, marginHorizontal: 8, justifyContent: 'center' }}>
            {!!title && (
              <Typography color={titleColor} textAlign="center" type="blinker" size={titleSize}>
                {title}
              </Typography>
            )}
          </View>
        )}
        {renderRight ? (
          renderRight()
        ) : (
          <View
            style={[
              styles.contentContainer('flex-end', 0),
              {
                flexDirection: 'row',
                alignItems: 'center',
                minWidth: iconContainerWidth,
              },
            ]}>
            {!!rightIconImg && (
              <Press onPress={onRightPress} style={styles.dotImageContainer}>
                <SvgIcon size={16} name="dot" />
              </Press>
            )}

            {!!rightIcon && (
              <Press onPress={onRightPress} style={[rightIconStyle]}>
                <SvgIcon
                  name={rightIcon}
                  size={rightIconSize}
                  color={rightIconColor}
                />
              </Press>
            )}
            {!!rightText && (
              <Press onPress={onRightPress} style={[rightIconStyle]}>
                <Typography size={14} color={colors.white} style={{ fontWeight: 'bold' }}>{rightText}</Typography>
              </Press>
            )}
            {!!rightBellIcon && (
              <Press onPress={onRightPress} style={[rightIconStyle]}>
                <Icon
                  size={20}
                  source={rightBellIcon}
                />
              </Press>
            )}
            {!!secondRightIcon && (
              <Press
                onPress={onRightPress}
                style={[secondRightIconStyle, { marginHorizontal: 5 }]}>
                <SvgIcon
                  name={secondRightIcon}
                  size={secondRightIconSize}
                  color={secondRightIconColor}
                />
              </Press>
            )}
          </View>
        )}
      </View>
    </View>

    // <View className="relative py-4 pt-9 px-2 bg-primary flex flex-row align-middle ">
    //   <View>
    //     {!hideBack && (
    //       <TouchableOpacity className="absolute px-3" onPress={() => {
    //         goBackHandler()
    //       }}>
    //         <Icon size={17} name="chevron-left" color="white" />
    //       </TouchableOpacity>
    //     )}
    //   </View>
    //   <Text className="text-white font-[blinker] opacity-80 text-center  font-bold flex-1 uppercase  ">
    //     {title}
    //   </Text>
    //   {user && (
    //     <Pressable className="absolute right-4 bottom-4" onPress={clearUserHandler}>
    //       <View>
    //         <MuiIcon size={18} name="logout" color="white" />
    //       </View>
    //     </Pressable>
    //   )}
    // </View>
  );
};

export default memo(Header);

const STATUSBAR_HEIGHT = StatusBar.currentHeight;
const styles = StyleSheet.create({
  container: (height, width, backgroundColor, paddingHorizontal) => {
    return {
      width,
      height,
      backgroundColor,
      flexDirection: 'row',
      alignSelf: 'center',
      paddingHorizontal,
      justifyContent: 'space-between',
      marginTop: Platform.OS == 'android' ? 0 : 30,

      // marginTop: 55 - 25
    };
  },
  contentContainer: (alignItems, padding, width) => {
    return {
      width: width,
      alignItems,
      padding,
      justifyContent: 'center',
    };
  },
  starIcon: {
    width: 25,
    height: 25,
    position: 'absolute',
    top: 40,
    right: 30,
  },
  dotImageContainer: {
    height: 30,
    width: 30,
    backgroundColor: colors.white,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 0.5,
    borderColor: colors.white,
    elevation: 1,
    shadowOpacity: 0.1,
    shadowOffset: 0.1,
  },
});

