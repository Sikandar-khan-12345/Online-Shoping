import { StyleSheet, Text, View, TouchableOpacity } from 'react-native'
import React, { useRef, useState, memo } from 'react'
import { Picker } from '@react-native-picker/picker'
import colors from '../../utils/colors';
import Typography from '../../src/components/UI/Typography';
import Icon from "react-native-vector-icons/FontAwesome";
const Dropdown = ({
    options = [],
    selected = null,
    label = 'Select',
    name,
    values = {},
    setValues,
    onChange,
    errors = {},
    setErrors,
}) => {
    const pickerRef = useRef();
    const [Select, setSelect] = useState({})
    function open() {
        pickerRef.current.focus();
    }

    function close() {
        pickerRef.current.blur();
    }
    const onSelect = (selectedItem) => {
        setValues({ ...values, [name]: selectedItem });
        setErrors({ ...errors, [name]: null })
        onChange && onChange(selectedItem);
    }
    return (
        <View style={{ marginBottom: 20 }}>
            {values?.[name] && (
                <Text style={{ zIndex: 200 }} className="absolute font-[blinker] bg-white left-3 text-xs -top-2 rounded-md px-1 opacity-70">
                    {label}
                </Text>
            )}
            <Header
                title={values[name] ? values?.[name]?.label || values?.[name] : label}
                onPress={open} />
            <Picker
                ref={pickerRef}
                mode='dropdown'
                style={{ display: 'none', width: 200 }}
                selectedValue={values[name]?.value}
                onValueChange={(itemValue, itemIndex) => {
                    console.log({ label: options[itemIndex - 1].label, value: itemValue })
                    onSelect({ label: options[itemIndex - 1].label, value: itemValue })
                }}>
                {
                    // !!!selected &&
                    <Picker.Item enabled={false} label={'Select'} value={null} />
                }
                {
                    options.map((item, index) => <Picker.Item key={index} label={item?.label} value={item?.value} />)
                }
            </Picker>
        </View>
    )
}

export default Dropdown
const Header = memo(({ title, onPress = () => { } }) => {
    return (
        <TouchableOpacity activeOpacity={0.9} onPress={onPress} style={styles.header}>
            <Typography numberOfLines={1} size={16} style={{ fontFamily: 'blinker' }}>{title}</Typography>
            <Icon size={17} name="chevron-down" color="black" />
        </TouchableOpacity>
    )
}, (p, n) => p.title == n.title)
const styles = StyleSheet.create({
    header: {
        width: '100%',
        height: 55,
        borderRadius: 8,
        flexDirection: 'row',
        justifyContent: 'space-between',
        backgroundColor: colors.white,
        alignItems: 'center',
        padding: 10,
        // position: 'absolute',
        zIndex: 100,
    }
})