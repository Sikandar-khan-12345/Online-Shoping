import React, { FC, memo, ReactElement, useRef, useState } from 'react';
import { FlatList, Modal, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import Typography from '../../src/components/UI/Typography';
import Icon from "react-native-vector-icons/FontAwesome";
import colors from '../../utils/colors';
import Animated, { FadeInDown, FadeInUp, FadeOutUp } from 'react-native-reanimated';
import { FULL_HEIGHT } from '../../utils/layout';

interface Props {
    label: string;
    name: string;
    values: object;
    setValues: any;
    onChange: any;
    errors: object;
    setErrors: any;
    options: Array<{ label: string; value: string }>,
}

const Dropdown: FC<Props> = ({
    label,
    name,
    values = {},
    setValues,
    onChange = () => { },
    errors = {},
    setErrors = () => { },
    options = [],
}) => {
    const [visible, setVisible] = useState(false);
    const DropdownButton = useRef();
    const [dropdownTop, setDropdownTop] = useState({ top: 0, width: 0, left: 0, bottom: 0 });
    const toggleDropdown = (): void => {
        visible ? setVisible(false) : openDropdown();
    };

    const openDropdown = (): void => {
        DropdownButton.current.measure((_fx, _fy, _w, h, _px, py) => {
            if (py + h > FULL_HEIGHT / 2) {
                setDropdownTop({ top: undefined, width: _w, left: _px, bottom: FULL_HEIGHT - (py + h - 40) });
            } else {
                setDropdownTop({ top: py + h, width: _w, left: _px, bottom: undefined });
            }
        });
        setVisible(true);
    };

    const onSelect = (selectedItem: any) => {
        setValues({ ...values, [name]: selectedItem });
        setErrors({ ...errors, [name]: null })
        toggleDropdown()
        onChange && onChange(selectedItem);
    }

    return (
        <View style={{ marginBottom: 20 }}>
            {values?.[name] && (
                <Text style={{ zIndex: 1000 }} className="absolute font-[blinker] bg-white left-3 text-xs -top-2 rounded-md px-1 opacity-70">
                    {label}
                </Text>
            )}
            <TouchableOpacity onPress={toggleDropdown} ref={DropdownButton} activeOpacity={0.9} style={styles.header}>
                <RenderDropdown onChange={onSelect} dropdownTop={dropdownTop} data={options} visible={visible} close={setVisible.bind(this, false)} />
                <Typography numberOfLines={1} size={16} style={{ fontFamily: 'blinker' }}>
                    {values[name] ? values?.[name]?.label || values?.[name] : label}
                </Typography>
                <Icon size={17} name="chevron-down" color="black" />
            </TouchableOpacity>
        </View>
    );
}


const RenderDropdown = ({ visible, data, close = () => { }, dropdownTop, onChange = (e) => { } }) => {
    const renderItem = ({ item, index }) => <Item onPress={() => onChange(item)} item={item} index={index} />
    if (visible) {
        return (
            <Modal visible={visible} transparent animationType="fade">
                <TouchableOpacity
                    activeOpacity={1}
                    // disabled
                    className=" px-4  pb-5 "
                    style={{ flex: 1, backgroundColor: 'transparent' }}
                    onPress={close}
                >
                    <Animated.View
                        entering={FadeInUp}
                        exiting={FadeOutUp}
                        style={[styles.dropdown, { top: dropdownTop?.top, width: dropdownTop?.width, left: dropdownTop?.left, bottom: dropdownTop?.bottom }]}>
                        <FlatList
                            data={data}
                            initialNumToRender={10}
                            renderItem={renderItem}
                            keyExtractor={(item, index) => index.toString()}
                        />
                    </Animated.View>
                </TouchableOpacity>
            </Modal>
        );
    }
};
const Item = ({ item, index, onPress = () => { } }): ReactElement<any, any> => (
    <TouchableOpacity key={index} onPress={onPress} style={styles.item}>
        <Typography size={16}>{item.label}</Typography>
    </TouchableOpacity>
)
const styles = StyleSheet.create({
    button: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#efefef',
        height: 50,
        width: '90%',
        paddingHorizontal: 10,
        zIndex: 1,
    },
    buttonText: {
        flex: 1,
        textAlign: 'center',
    },
    dropdown: {
        position: 'absolute',
        backgroundColor: '#fff',
        width: '100%',
        shadowColor: '#000000',
        shadowRadius: 4,
        shadowOffset: { height: 4, width: 0 },
        shadowOpacity: 0.5,
        alignSelf: 'center',
        elevation: 5,
        maxHeight: FULL_HEIGHT / 2
    },
    header: {
        width: '100%',
        height: 55,
        borderRadius: 8,
        flexDirection: 'row',
        justifyContent: 'space-between',
        backgroundColor: colors.white,
        alignItems: 'center',
        padding: 10,
        // position: 'absolute',
        zIndex: 100,
        paddingLeft: 20,
    },
    item: {
        paddingHorizontal: 10,
        paddingLeft: 20,
        borderBottomWidth: StyleSheet.hairlineWidth,
        height: 50,
        justifyContent: 'center'
    },
});

export default Dropdown;