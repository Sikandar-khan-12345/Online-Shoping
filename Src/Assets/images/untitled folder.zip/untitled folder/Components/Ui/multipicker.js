import React, { useCallback, useState, memo, useEffect } from 'react';
import {
  View,
  StyleSheet,
  Text,
  FlatList,
  Modal,
  TextInput,
  Button,
  Image
} from 'react-native';
import colors from '../../Constants/colors';
import { Picker } from '@react-native-picker/picker';
import fonts from '../../Constants/fonts';
import { FULL_HEIGHT, STANDARD_WIDTH } from '../../Constants/layout';
import { FocusAwareStatusBar } from './FocusAwareStatusBar';
import Ripple from 'react-native-material-ripple';
import Icon from './Icon';
import Icons from '../../Constants/Icons';
import Typography from './Typography';
import Press from '../HOC/Press';

const areEqual = (prevProps, nextProps) => {
  const { isSelected } = nextProps;
  const { isSelected: prevIsSelected } = prevProps;

  /*if the props are equal, it won't update*/
  const isSelectedEqual = isSelected == prevIsSelected;
  return isSelectedEqual;
};

const ListView = memo(({ onPress, item }) => {
  return (
    <Ripple key={item?.id} onPress={() => onPress(item?.id)}>
      <View key={`${item?.id}_`} style={styles.listView}>
        <View style={{ flexDirection: 'row' }}>
          <Image
            style={{ width: 50, height: 50, borderRadius: 35, marginRight: 10 }}
            source={{ uri: item?.image_url }}
          />
          <Typography color={colors.white} size={18}>{item?.name}</Typography>
        </View>
        <Icon
          source={Icons.check}
          size={18}
          marginRight={10}
          tintColor={item.active ? colors.Orange : colors.placeTextColor}
        />
      </View>
    </Ripple>
  )
}, areEqual);

export const Multipicker = (props) => {
  const {
    data = [],
    close,
    onSubmit = () => { },
    search = true,
    heading = '',
    visible = false,
    placeholder = 'Search....'
  } = props;

  const [searchValue, setSearchValue] = useState('');
  useEffect(() => {
    setListing(data);
  }, [data])
  const [listing, setListing] = useState(data);


  const selectItems = (value) => {
    let data = [...listing];
    data.map((v) => {
      if (v.id == value) {
        v.active = (v.active) ? false : true;
      }
    });
    setListing(data);
  }

  const keyExtractor = useCallback((item) => String(item.id), []);
  const getItemLayout = useCallback((data, index) => ({
    length: 50,
    offset: 50 * index,
    index
  }), []);


  const searchItem = (value) => {
    let items = [...data];
    if (value != '') {
      const regex = new RegExp(`${value}*`, 'i');
      items = items.filter((v) => regex.test(v.label));
    }
    setListing(items)
    setSearchValue(value);
  }

  const renderItem = ({ item, index }) => <ListView isSelected={item.active} onPress={selectItems} item={item} />

  return (
    <Modal
      transparent
      animationType={'slide'}
      visible={visible}>
      <FocusAwareStatusBar
        translucent={Platform.OS == 'android'}
        backgroundColor={colors.bgcolor}
      />
      <View style={{
        flex: 1,
        backgroundColor: colors.bgcolor
      }}>
        <View style={{ backgroundColor: colors.bgcolor, width: STANDARD_WIDTH, alignSelf: 'center', borderRadius: 5, maxHeight: FULL_HEIGHT - 60, minHeight: FULL_HEIGHT / 3 }}>
          {(search) &&
            <View style={styles.inputContainer}>
              <Icon
                source={Icons.search}
                size={20}
                tintColor={colors.white}
              />
              <View style={{
                flex: 1
              }}>
                <TextInput
                  value={searchValue}
                  onChangeText={(v) => searchItem(v)}
                  placeholder={placeholder}
                  placeholderTextColor={colors.placeTextColor}
                  style={{ padding: 0, marginHorizontal: 10, color: colors.white }}
                />
              </View>
              <Press onPress={() => onSubmit(listing?.filter((v) => (v.active)))}>
                <Typography type='0' size={15} color={colors.Orange}>
                  Done
                </Typography>
              </Press>
            </View>
          }
          {(heading != '') &&
            <View style={{ alignSelf: 'center', justifyContent: 'center', paddingTop: 5 }}>
              <Text style={{ color: colors.black, fontStyle: fonts.medium, fontSize: 18 }}>{heading}</Text>
            </View>
          }
          <FlatList
            data={listing}
            keyExtractor={keyExtractor}
            renderItem={renderItem}
            ListFooterComponent={
              (listing?.length == 0) &&
              <View style={{ alignSelf: 'center', justifyContent: 'center', paddingTop: 4 }}>
                <Text style={{ color: colors.placeTextColor, fontStyle: fonts.regular, fontSize: 14 }}>No Item Found</Text>
              </View>
            }
          />
          {/* <View style={{ flexDirection: 'row', paddingHorizontal: 10, marginVertical: 2, justifyContent: 'space-around', position: 'absolute', height: 60, backgroundColor: 'red', bottom: 0, left: 0, right: 0 }}>
            <Button onPress={close} labelStyle={styles.btnLabel} btnStyle={styles.btn} title={'Cancel'} />
            <Button onPress={() => onSubmit(listing?.filter((v) => (v.active)))} labelStyle={styles.btnLabel} btnStyle={{ ...styles.btn, backgroundColor: colors.btnBlue }} title={'Ok'} />
          </View> */}
        </View>
      </View>
    </Modal>
  );
};


const styles = StyleSheet.create({
  btnLabel: {
    fontSize: 13,
    fontFamily: fonts.regular
  },
  btn: {
    backgroundColor: colors.gray6,
    borderRadius: 0,
    width: 70,
    height: 40,
  },
  inputContainer: {
    flexDirection: 'row',
    padding: 10,
    alignItems: 'center',
    borderBottomColor: 'ghostwhite',
    borderBottomWidth: 0.5
  },
  input: {
    height: 50,
    width: STANDARD_WIDTH,
    borderWidth: 0,
    borderRadius: 0,
    borderBottomWidth: 1,
    borderColor: colors.placeTextColor,
    alignSelf: 'center',
    color: colors.black,
    fontSize: 14
  },
  listView: {
    alignItems: 'center',
    flexDirection: 'row',
    borderBottomWidth: 0.3,
    borderColor: colors.Orange,
    paddingVertical: 7,
    justifyContent: 'space-between'
  },
  listText: {
    fontFamily: fonts.regular,
    color: colors.gray4,
    fontSize: 15
  }
});
