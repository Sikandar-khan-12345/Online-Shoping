import { StyleSheet, View } from 'react-native';
import React, { memo } from 'react';
import { SPACING, STANDARD_WIDTH } from '../../src/Constants/layout';
const Card = ({ children, style = {}, marginVertical = SPACING }) => {
  return <View style={[styles.card(marginVertical), style]}>{children}</View>;
};

export default Card;

const styles = StyleSheet.create({
  card: (marginVertical) => {
    return {
      width: STANDARD_WIDTH,
      alignSelf: 'center',
      marginVertical: marginVertical,
    }
  },
});
