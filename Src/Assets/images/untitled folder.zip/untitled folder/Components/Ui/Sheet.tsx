import {
    Dimensions,
    SafeAreaView,
    ScrollViewProps,
    StatusBar,
    StyleSheet,
    TouchableOpacity,
    View,
    ViewStyle,
  } from 'react-native';
  import {ScrollView} from 'react-native-gesture-handler';
  import React, {
    forwardRef,
    JSXElementConstructor,
    ReactNode,
    useEffect,
    useImperativeHandle,
    useRef,
  } from 'react';
  import Animated, {
    AnimationCallback,
    runOnJS,
    useAnimatedGestureHandler,
    useAnimatedStyle,
    useSharedValue,
    withDelay,
    withRepeat,
    withSequence,
    withSpring,
    WithSpringConfig,
  } from 'react-native-reanimated';
  import {PanGestureHandler} from 'react-native-gesture-handler';
  import colors from '../../utils/colors';
  
  interface SheetProps {
    minHeight?: number;
    maxHeight?: number;
    expandedHeight?: number;
    children?: ReactNode;
    renderHeaderComponent?: Function;
    containerStyle?: ViewStyle;
    scrollViewProps?: ScrollViewProps;
    handle?: Boolean;
    openSheet?: Function;
    closeSheet?: Function;
    onLayoutChange?:SheetCallBackType
  }
  
  type SheetCallBackType = (info: SheetCallBackInterface) =>  void;
  
  interface SheetCallBackInterface {
    isOpen:Boolean,
    position:SheetPositions
  }
  type SheetPositions = 'minimized' | 'maximized' | 'expanded';
  
  const {height, width} = Dimensions.get('screen');
  const STATUSBAR_HEIGHT: any = StatusBar.currentHeight;
  const NAV_HEIGHT = 48;
  const Sheet: React.FC<SheetProps> = (
    {
      children,
      minHeight = 65,
      maxHeight = height - STATUSBAR_HEIGHT - 10,
      expandedHeight = height * 0.6,
      renderHeaderComponent = () => null,
      containerStyle,
      scrollViewProps,
      handle = true,
      onLayoutChange=()=>{}
    }: SheetProps,
    ref,
  ) => {
    const position = useSharedValue<SheetPositions>('minimized');
    const sheetHeight = useSharedValue(-minHeight);
    const springConfig: WithSpringConfig = {
      damping: 50,
      mass: 0.3,
      stiffness: 60,
      overshootClamping: true,
      restSpeedThreshold: 0.3,
      restDisplacementThreshold: 0.3,
    };
    const scrollTo = (e: any) => {
      console.log(e);
    };
    const scrollViewRef = useRef<any>(null);
  
    useEffect(() => {
      sheetHeight.value = withRepeat(
        withDelay(
          3000,
          withRepeat(
            withSequence(
              withSpring(-80, springConfig),
              withSpring(-65, springConfig),
            ),
            1,
          ),
        ),
        -1,
      );
    }, []);
  
    useImperativeHandle(ref, () => ({
      // openSheet: () =>runOnJS(handleSheet)('maximized',()=>{}),
      // closeSheet: () =>runOnJS(handleSheet)('minimized',()=>{}),
      openSheet: () =>{
        sheetHeight.value = withSpring(-maxHeight + 80, springConfig);
        position.value = 'maximized';
        onLayoutChange({isOpen:position.value!=='maximized',position:'maximized'})
      },
      closeSheet: () =>{
        sheetHeight.value = withSpring(-65, springConfig);
        position.value = 'minimized';
        onLayoutChange({isOpen:position.value!=='minimized',position:'minimized'})
      }
    }));
    const handleSheet = (type: SheetPositions,cb:AnimationCallback) => {
      // 'worklet';
      switch (type) {
        case 'maximized':
          sheetHeight.value = withSpring(-maxHeight + 80, springConfig,cb);
          position.value = 'maximized';
          onLayoutChange({isOpen:true,position:'maximized'})
          break;
        case 'minimized':
          sheetHeight.value = withSpring(-65, springConfig,cb);
          position.value = 'minimized';
          onLayoutChange({isOpen:false,position:'minimized'})
          break;
        case 'expanded':
          sheetHeight.value = withSpring(-65, springConfig,cb);
          position.value = 'expanded';
          onLayoutChange({isOpen:true,position:'expanded'})
          break;
        default:
          sheetHeight.value = withSpring(-65, springConfig);
          position.value = 'minimized';
          onLayoutChange({isOpen:false,position:'minimized'})
          break;
      }
    };
  
    const onGestureEvent = useAnimatedGestureHandler({
      onStart: (_ev, ctx: any) => {
        'worklet';
        ctx.offsetY = sheetHeight.value;
      },
      onActive: (ev, ctx: any) => {
        'worklet';
        if (position.value === 'maximized') {
          sheetHeight.value = ctx.offsetY + ev.translationY;
        } else if (ev.translationY < 0 && position.value === 'minimized') {
          sheetHeight.value = ctx.offsetY + ev.translationY;
        }
      },
      onEnd: () => {
        'worklet';
        if (
          -sheetHeight.value < maxHeight * 0.76 &&
          position.value === 'maximized'
        ) {
          runOnJS(handleSheet)('minimized',()=>{})
        } else if (-sheetHeight.value > 100 && position.value === 'minimized') {
          runOnJS(handleSheet)('maximized',()=>{})
        } else {
          runOnJS(handleSheet)('minimized',()=>{})
        }
      },
    });
    const sheetHeightAnimatedStyle = useAnimatedStyle(() => ({
      height: -sheetHeight.value,
    }));
    return (
      <View style={containerStyle}>
        {/* <SafeAreaView > */}
        <PanGestureHandler onGestureEvent={onGestureEvent}>
          <Animated.View style={[sheetHeightAnimatedStyle, styles.sheet]}>
            {handle && (
              <TouchableOpacity
                activeOpacity={0.8}
                style={styles.handleContainer}>
                <View style={styles.handle} />
              </TouchableOpacity>
            )}
            {renderHeaderComponent()}
            <ScrollView ref={scrollViewRef} {...scrollViewProps}>
              {children}
            </ScrollView>
          </Animated.View>
        </PanGestureHandler>
        {/* </SafeAreaView> */}
      </View>
    );
  };
  
  export default forwardRef(Sheet);
  
  const styles = StyleSheet.create({
    sheet: {
      justifyContent: 'flex-start',
      backgroundColor: colors.white,
      // Round the top corners
      // borderTopLeftRadius: 20,
      // borderTopRightRadius: 20,
      borderTopWidth: 1,
      borderTopColor: colors.white,
      minHeight: 80,
      // Add a shadow to the top of the sheet
      shadowColor: colors.black,
      shadowOffset: {
        width: 0,
        height: -2,
      },
      shadowOpacity: 0.23,
      shadowRadius: 2.62,
      elevation: 4,
    },
    handleContainer: {
      alignItems: 'center',
      justifyContent: 'center',
      paddingTop: 10,
    },
    // Add a small handle component to indicate the sheet can be dragged
    handle: {
      width: '15%',
      height: 4,
      borderRadius: 8,
      backgroundColor: colors.gray,
    },
    closeButton: {
      width: NAV_HEIGHT,
      height: NAV_HEIGHT,
      borderRadius: NAV_HEIGHT,
      alignItems: 'center',
      justifyContent: 'center',
      alignSelf: 'flex-start',
      marginBottom: 10,
    },
  });
  