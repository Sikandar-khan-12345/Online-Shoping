import React from 'react'
import netInfo from '@react-native-community/netinfo';
import { toastRef } from '../utils/Backend/backend';
const NetAlert = () => {
    const [status, setStatus] = React.useState(false)
    const { isConnected, isInternetReachable } = netInfo;
    React.useEffect(() => {
        const removeNetInfoSubscription = netInfo.addEventListener((state) => {
            toastRef.current?.hideAll()
            if (status && state.isInternetReachable) {
                toastRef.current?.show('Back online', { type: 'success', duration: 5000 })
                setStatus(false)
                return
            }
            if (!status && !state.isInternetReachable) {
                toastRef.current?.show('Please check your network connection.', { type: 'danger', duration: 5000 })
                setStatus(true)
                return
            }
        });
        return () => removeNetInfoSubscription();
    }, [isInternetReachable, status]);
    return null
}

export default NetAlert