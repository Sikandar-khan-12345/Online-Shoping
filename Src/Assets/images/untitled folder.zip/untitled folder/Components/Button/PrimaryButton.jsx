import { Text, Pressable } from "react-native";
import React from "react";


const PrimaryButton = ({
  title,
  onClick,
  isOutline,
  rootClass,
  textClass,
  subText,
  disabled,
  style
}) => {
  return (
    <Pressable
      onPress={onClick}
      disabled={disabled}
      style={style}
      className={`py-3  flex justify-center ${
        isOutline ? " bg-transparent border-primary border " : " bg-primary "
      }rounded-md ${rootClass}`}
    >
      <Text
        className={` font-bold font-[blinker] ${
          isOutline ? "text-primary" : "text-white"
        } text-center uppercase ${textClass}`}
      >
        {" "}
        {title}{" "}
      </Text>
      {subText ? (
        <Text
          className={`text-[10px] font-[blinker] ${
            isOutline ? "text-primary" : "text-white"
          } text-center uppercase  ${textClass}`}
        >
          {subText}
        </Text>
      ) : null}
    </Pressable>
  );
};

export default PrimaryButton;
