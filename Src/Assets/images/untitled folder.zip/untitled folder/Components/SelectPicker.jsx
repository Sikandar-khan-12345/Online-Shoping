import { Modal, StyleSheet, ActivityIndicator, Text, TextInput, FlatList, TouchableOpacity, View, ScrollView, SafeAreaViewBase, SafeAreaView } from 'react-native'
import React, { useRef, useState, memo, useEffect } from 'react'
import Sheet from './Ui/Sheet'
import colors from '../utils/colors'
import Typography from '../src/components/UI/Typography'
import Icon from "react-native-vector-icons/FontAwesome";
import { Picker } from '@react-native-picker/picker'
import { makeDropDownData } from '../utils/data'

const SelectPicker = ({
  selected = { label: 'Select', value: null },
  options = [],
  label,
  placeholder = 'Select',
  name,
  values,
  setValues,
  onChange,
  errors,
  setErrors,
  nesting = false
}) => {
  const pickerRef = useRef();
  const [show, setShow] = useState(false)
  const [data, setData] = useState([])
  const [loading, setLoading] = useState(true)
  function open() {
    // pickerRef.current.focus();
    setLoading(true)
    setTimeout(() => {
      setShow(true)
      const time = setTimeout(() => {
        setLoading(false)
        clearTimeout(time)
      }, 800);
    }, 100);
  }

  function close() {
    // pickerRef.current.blur();
    setShow(false)
  }
  const onSelect = (selectedItem) => {
    setValues({ ...values, [name]: selectedItem });
    setErrors({ ...errors, [name]: null })
    onChange && onChange(selectedItem);
  }
  const done = () => {
    close()
    setSearchText('')
  }
  const [value, setValue] = useState(selected)
  const isSelected = values[name]?.value
  const _renderTab = ({ item, index }) => <SelectionTab onPress={onSelect} index={index} item={item} isSelected={isSelected} selected={values[name]?.value || values[name]} />
  const [searchText, setSearchText] = useState('')
  const filterData = (text) => {
    if (!nesting) {
      if (text) {
        RegExp.quote = function allowSpecialSymbols(str) {
          console.log('RegExp.quote++++===', str);
          return str.replace(/([?*+^$[\]\\(){}|-])/g, '');
        };
        const regx = new RegExp(RegExp.quote(text), "i")
        let arr2 = options.filter(obj => regx.test(obj.label))
        console.log(arr2);
        setData(arr2)
      } else {
        setData([])
      }
    } else {

    }
  }


  const filterDropdownData = (arr = [], text = '') => {
    if (text) {
      RegExp.quote = function allowSpecialSymbols(str) {
        console.log('RegExp.quote++++===', str);
        return str.replace(/([?*+^$[\]\\(){}|-])/g, '');
      };
      const regx = new RegExp(RegExp.quote(text), "i")
      return arr.filter(obj => regx.test(obj.label))
    } else {
      return arr
    }
  }

  return (
    <View style={{ marginBottom: 20 }}>
      {values?.[name] && (
        <Text className="absolute z-20 font-[blinker] bg-white left-3 text-xs -top-2 rounded-md px-1 opacity-70">
          {label}
        </Text>
      )}
      <Header
        title={values[name] ? values?.[name]?.label || values?.[name] : placeholder}
        onPress={open}
      />
      {errors?.[name]?.length ? (
        <View className="ml-1 ">
          {errors[name]?.map((each, i) => (
            <Text key={i} className="text-red-400 font-[blinker]">{each}</Text>
          ))}
        </View>
      ) : null}
      <Modal
        transparent
        visible={show}
        animationType='slide'
      >
        <SafeAreaView style={{ flex: 1, backgroundColor: colors.white }}>
          <SearchBar
            selected={values[name]}
            onPress={done}
            onChange={setSearchText}
          />
          {loading ?
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
              <ActivityIndicator color={colors.primary} size='small' />
            </View>
            : <View>
              {!nesting &&
                <View style={{ paddingHorizontal: 10, }}>
                  <Typography size={17} style={{ fontFamily: 'blinker', fontWeight: "bold", marginVertical: 10 }}>{label}</Typography>
                  <FlatList
                    keyExtractor={(item, index) => `${JSON.stringify(item)}${index}`}
                    data={filterDropdownData(options, searchText)}
                    renderItem={_renderTab}
                    ListEmptyComponent={<Typography textAlign={'center'} size={18} style={{ marginVertical: 10, fontFamily: 'blinker' }}>No data</Typography>}
                  // ItemSeparatorComponent={<View style={{ height: 1, backgroundColor: colors.gray }} />}
                  />
                </View>}
              <ScrollView contentContainerStyle={{ flexGrow: 1, paddingHorizontal: 10 }} showsVerticalScrollIndicator={false}>
                {nesting &&
                  <>
                    {
                      options.map((item, index) => {
                        let object = { ...item }
                        for (const key in object) {
                          if (Object.hasOwnProperty.call(object, key)) {
                            if (filterDropdownData(makeDropDownData(object[key]), searchText).length) {
                              return (
                                <View key={Math.random().toString()}>
                                  <Typography size={17} style={{ fontFamily: 'blinker', fontWeight: 'bold', marginVertical: 10 }}>{key}</Typography>
                                  <FlatList
                                    keyExtractor={(item, index) => `${JSON.stringify(item)}${index}`}
                                    data={filterDropdownData(makeDropDownData(object[key]), searchText)}
                                    scrollEnabled={false}
                                    renderItem={_renderTab}
                                    ListEmptyComponent={<Typography textAlign={'center'} size={18} style={{ marginVertical: 10, fontFamily: 'blinker' }}>No data</Typography>}
                                  // ItemSeparatorComponent={<View style={{ height: 1, backgroundColor: colors.gray }} />}
                                  />
                                </View>
                              )
                            }
                          }
                        }
                      })
                    }
                  </>
                }
              </ScrollView>
            </View>}
        </SafeAreaView>
      </Modal>
    </View>
  )
}

export default SelectPicker

const SearchBar = memo(({ onPress = () => { }, selected, onChange = () => { } }) => {
  const [search, setSearch] = useState('')
  const changeText = (text) => {
    setSearch(text)
    onChange(text)
  }
  return (
    <View style={{ flexDirection: 'row', paddingHorizontal: 10, alignItems: 'center', borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.black }}>
      <TextInput
        placeholder='Search something here....'
        value={search}
        onChangeText={changeText}
        cursorColor={colors.primary}
        style={{ padding: 0, paddingVertical: 0, width: '100%', flex: 1, height: 50, backgroundColor: colors.white, color: colors.black, fontFamily: 'blinker' }}
      />
      <TouchableOpacity
        onPress={onPress}
        style={{ paddingHorizontal: 5, height: 50, justifyContent: 'center', alignItems: 'center' }}>
        {
          !!selected ?
            <Typography color={colors.primary} type='bold'>Done</Typography>
            : <Icon size={17} name="close" color="black" />
        }
      </TouchableOpacity>
    </View>
  )
}, (p, n) => p.selected == n.selected)

const Header = memo(({ title, onPress = () => { } }) => {
  return (
    <TouchableOpacity onPress={onPress} style={styles.header}>
      <Typography numberOfLines={1} size={16} style={{ fontFamily: 'blinker' }}>{title}</Typography>
      <Icon size={17} name="chevron-down" color="black" />
    </TouchableOpacity>
  )
}, (p, n) => p.title == n.title)

const SelectionTab = memo(({ item, index, onPress = () => { }, selected = {} }) => {
  return (
    <TouchableOpacity
      onPress={() => onPress(item)}
      style={{
        flexDirection: 'row', padding: 5, alignItems: 'center',
        height: 50,
      }}>
      <View style={{
        marginHorizontal: 10, width: 20, height: 20, borderRadius: 10, borderWidth: 1.5, borderColor: selected == item?.value ? colors.primary : colors.gray, justifyContent: 'center', alignItems: 'center'
      }}>
        {
          (selected == item?.value) &&
          <View style={{ width: 14, height: 14, borderRadius: 10, backgroundColor: colors.primary }} />
        }
      </View>
      {console.log('----------item?.label--------', item?.label, 'item?.label')}
      <Typography style={{ fontFamily: 'blinker' }}>{item?.label}</Typography>
    </TouchableOpacity>
  )
}, (p, n) => p.isSelected == n.isSelected)

const styles = StyleSheet.create({
  header: {
    width: '100%',
    height: 55,
    borderRadius: 8,
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: colors.white,
    alignItems: 'center',
    padding: 10,
    paddingLeft: 20
  }
})