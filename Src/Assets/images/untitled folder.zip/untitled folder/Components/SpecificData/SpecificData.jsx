import { View, Text } from "react-native";
import React from "react";
import Icon from "react-native-vector-icons/Entypo";

const SpecificData = ({ sub, value }) => {
  const beautify = (text = '') => {
    console.log(text);
    if (text && text.includes('/')) {
      let textArr = text.split('/')
      return (
        <Text>
          <Text style={{ fontWeight: 'bold' }}>{textArr[0]}</Text>
          <Text> / </Text>
          <Text style={{ fontWeight: '300' }}>{textArr[1]}</Text>
        </Text>
      )
    }
    return text
  }
  return (
    <View className="flex flex-row  items-center mb-2">
      <View style={{ flexDirection: 'row' }}>
        <View style={{ width: '30%' }}>
          <Text className='font-[blinker]'>{sub}</Text>
        </View>
        <Icon name="dots-two-vertical" />
        <View style={{ width: '70%' }}>
          <Text className='font-[blinker]'>{beautify(value)}</Text>
        </View>
      </View>
    </View>
  );
};



export default SpecificData;


