import { View, ActivityIndicator } from "react-native";
import React from "react";



const Loader = () => {
  return (
    <View className="
     absolute z-100000000  left-0 top-0 right-0
     bottom-0 flex align-middle justify-center
     bg-gray-800/[0.2]">
      <ActivityIndicator size={60} color="orange" />
    </View>
  );
};

export default Loader;
