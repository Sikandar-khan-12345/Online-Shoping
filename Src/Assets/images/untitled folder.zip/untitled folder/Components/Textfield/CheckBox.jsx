import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import Checkbox from 'expo-checkbox';
import colors from '../../utils/colors';

const InputCheckBox = ({
    label,
    placeholder,
    name,
    values,
    setValues,
    rootClassName,
    onChange,
    errors,
    setErrors,
}) => {
    const inputChangeHandler = (value) => {
        // if (value?.length > maxLength) return;
        setValues({ ...values, [name]: value });
        // setErrors({ ...errors, [name]: null })
        // onChange&&onChange(value)
    };
    return (
        <View style={{}}>
            <View>
                <Checkbox style={{}} color={values[name] ? colors.primary : undefined} value={values[name]||false} onValueChange={inputChangeHandler.bind(this, !values[name])} />
            </View>
            {errors?.[name]?.length ? (
                <View className="ml-1 mt-1">
                    {errors[name]?.map((each) => (
                        <Text className="text-red-400 font-[blinker]">{each}</Text>
                    ))}
                </View>
            ) : null}
        </View>
    )
}

export default InputCheckBox

const styles = StyleSheet.create({})