import React, { useEffect, useRef, useState, memo, forwardRef, useImperativeHandle } from 'react';
import {
  Text,
  TextInput,
  StyleSheet,
  View,
  Animated,
  Easing,
  TouchableWithoutFeedback,
  Platform,
  Image,
  ActivityIndicator,
  TouchableOpacity
} from 'react-native';

import colors from '../../utils/colors';
import Typography from '../../src/components/UI/Typography';
import fonts from '../../src/Constants/fonts';
import Reanimated, {
  FadeIn,
  FadeInLeft,
  FadeInRight,
  FadeOut,
  SlideInLeft,
} from 'react-native-reanimated';
import Press from '../../src/components/HOC/Press';
import SvgIcon from '../Svg';
import IndianFlag from './IndianFlag';


const TextField = ({
  label,
  placeholder,
  name,
  type,
  values = {},
  setValues,
  onFocus = () => { },
  onBlur = () => { },
  rootClassName,
  maxLength = 50,
  errors,
  setErrors,
  containerStyle = {},
  inputStyle = {},
  secure = false,
  height = 55,
  inputRefs = {},
  leftIcon,
  leftIconSize = 25,
  leftIconColor,
  leftIconStyle,
  rightIcon,
  rightIconColor,
  rightIconSize = 25,
  rightIconStyle,
  labelPosition = (height / 2) - 9,
  onRightPress = () => { },
  keyboardType,
  mobileNumber = false,
  ...restOfProps
}) => {
  const inputChangeHandler = (value) => {
    if (type === "number") {
      value = value.replace(/[^0-9]/g, "");
    }
    if (value?.length > maxLength) return;
    setValues({ ...values, [name]: value });
    setErrors({ ...errors, [name]: null })
  };

  const [isFocused, setIsFocused] = useState(false);
  const [show, setShow] = React.useState(type == 'password' || secure);
  const inputRef = useRef();
  const focusAnim = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    setShow(secure)
  }, [secure])

  const focusInput = () => {

  }

  useEffect(() => {
    Animated.timing(focusAnim, {
      toValue: isFocused || !!values[name] ? 1 : 0,
      duration: 150,
      easing: Easing.bezier(0.4, 0, 0.2, 1),
      useNativeDriver: false,
    }).start();
  }, [focusAnim, isFocused, values[name]]);

  // let color = animation && isFocused ? colors.secondary : colors.lightBorder;
  // if (error) {
  //   color = '#B00020';
  // }


  return (
    <View style={{ width: '100%', marginBottom: 15 }}>
      <TouchableOpacity
        activeOpacity={1}
        // onPress={}
        style={{
          width: '100%',
          height: height,
          backgroundColor: colors.white,
          // marginBottom: 5,
          borderRadius: 8,
          flexDirection: "row",
          alignItems: 'center',
          ...containerStyle

        }}>
        {
          mobileNumber &&
          <View style={{
            width: 75,
            height: 50,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}>
            <View style={{ marginHorizontal: 10 }}>
              <IndianFlag />
            </View>
            <Typography>+91</Typography>
            <View style={{ height: 25, width: 1.5, marginLeft: 5, backgroundColor: colors.black }} />
          </View>
        }
        {!!leftIcon && (
          <Press
            // onPress={onLeftPress}
            onPress={() => leftIcon === 'back' ? navigation?.goBack() : onLeftPress()}
            style={[leftIconStyle]}>
            <SvgIcon
              size={leftIconSize}
              name={leftIcon}
              color={leftIconColor}
            />
          </Press>
        )}
        <View style={{ flex: 1, }}>
          {!!label && <Animated.View
            style={[
              styles.labelContainer,
              {
                top: focusAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [labelPosition, -7],
                }),
                left: focusAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [mobileNumber ? 10 : 20, 10],
                }),
                // transform: [{
                //   scale: focusAnim.interpolate({
                //     inputRange: [0, 1],
                //     outputRange: [1, 0.75],
                //   }),
                // }],
                paddingHorizontal: focusAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [0, 10],
                })
              }
            ]}>
            <Animated.Text
              style={{
                fontFamily: 'blinker',
                color: colors.black + '90',
                fontSize: focusAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [16, 13],
                })
              }}
              onPress={() => inputRef.current?.focus()}
            >
              {label}
            </Animated.Text>
          </Animated.View>}
          <TextInput
            placeholder={(isFocused || mobileNumber) ? placeholder : ''}
            cursorColor={colors.primary}
            ref={(el) => {
              inputRef.current = el
              inputRefs.current = el
            }}
            secureTextEntry={type == 'password' ? !show : false}
            value={values[name]}
            style={[styles.input, { paddingLeft: mobileNumber ? 10 : 20 }]}
            keyboardType={keyboardType}
            onChangeText={inputChangeHandler}
            onBlur={event => {
              setIsFocused(false);
              onBlur(event);
            }}
            onFocus={event => {
              setIsFocused(true);
              onFocus(event);
            }}
            {...restOfProps}
          />
        </View>
        {!!rightIcon && (
          <Press onPress={onRightPress} style={[rightIconStyle]}>
            <SvgIcon
              name={rightIcon}
              size={rightIconSize}
              color={rightIconColor}
            />
          </Press>
        )}
        {type == 'password' && (
          <Press onPress={() => setShow(!show)} style={[{ marginHorizontal: 10 }, rightIconStyle]}>
            <SvgIcon
              name={show ? 'eye-open' : 'eye-close'}
              size={22}
              color={rightIconColor || '#000000'}
            />
          </Press>
        )}
      </TouchableOpacity>
      {errors?.[name]?.length ? (
        <View className="ml-1 mt-1">
          {errors[name]?.map((each, i) => (
            <Reanimated.Text entering={SlideInLeft} key={i} className='text-red-400 font-[blinker]'>{each}</Reanimated.Text>
          ))}
        </View>
      ) : null}
    </View>
    // <View style={containerStyle} className={` ${rootClassName} mb-4`}>
    //   <View className={`bg-white shadow-sm  rounded-md relative `}>
    //     {values?.[name] && (
    //       <Text className="font-[blinker] absolute  bg-white left-3 text-xs -top-2 rounded-md px-1 opacity-70">
    //         {label}
    //       </Text>
    //     )}
    //     <TextInput
    //       className="px-3 py-3 text-base font-[blinker]"
    //       style={inputStyle}
    //       value={values?.[name] || ""}
    //       onChangeText={inputChangeHandler}
    //       placeholder={placeholder}
    //       secureTextEntry={type === "password"}
    //       keyboardType={type === "number" ? "numeric" : "default"}
    //       {...props}
    //     />
    //   </View>
    //   {errors?.[name]?.length ? (
    //     <View className="ml-1 mt-1">
    //       {errors[name]?.map((each,i) => (
    //         <Text key={i} className='text-red-400 font-[blinker]'>{each}</Text>
    //       ))}
    //     </View>
    //   ) : null}
    // </View>
  );
};

export default memo(TextField);

const styles = StyleSheet.create({
  input: {
    flex: 1,
    paddingHorizontal: 10,
    paddingLeft: 20
  },
  labelContainer: {
    position: "absolute",
    zIndex: 10,
    // backgroundColor: 'red',
    backgroundColor: colors.white,
    borderRadius: 10,
    fontFamily: 'blinker',
    color: colors.black,
    // minWidth:70,
    // flexGrow:1
  }
})
