import { View, Text } from "react-native";
import React, { memo } from "react";
import SelectDropdown from "react-native-select-dropdown";
import Icon from "react-native-vector-icons/FontAwesome";

const SelectInput = ({
  label,
  placeholder,
  name,
  values,
  setValues,
  options,
  rootClassName,
  onChange,
  errors,
  setErrors,
}) => {
  return (
    <View className={`relative mb-4 ${rootClassName}`}>
      {values?.[name] && (
        <Text className="absolute z-20 font-[blinker] bg-white left-3 text-xs -top-2 rounded-md px-1 opacity-70">
          {label}
        </Text>
      )}
      <SelectDropdown
        // search

        // searchPlaceHolder="Search"

        data={options || []}
        defaultButtonText={values[name] ? values?.[name]?.label : placeholder}
        buttonStyle={{
          backgroundColor: "white",
          borderRadius: 6,
          width: "100%",
        }}
        buttonTextStyle={{
          fontFamily : "blinker",
          fontSize: 16,
          textAlign: "left",
          marginLeft: 5,
          opacity: values?.[name] ? 1 : 0.5,
        }}
        dropdownStyle={{
          // overflow: "auto",
          borderRadius: 10,
        }}
        searchInputStyle={{
          outline: "none",
        }}
        rowStyle={{
          paddingTop: 7,
          paddingBottom: 7,
        }}
        onSelect={(selectedItem, index) => {
          setValues({ ...values, [name]: selectedItem });
          setErrors({...errors, [name]:null})
          onChange && onChange(selectedItem);
        }}
        buttonTextAfterSelection={(selectedItem, index) => {
          return selectedItem?.label;
        }}
        rowTextForSelection={(item, index) => {
          return item?.label;
        }}
        renderDropdownIcon={() => {
          return <Icon size={17} name="chevron-down" color="black" />;
        }}
      />
      {errors?.[name]?.length ? (
        <View className="ml-1 mt-1">
          {errors[name]?.map((each,i) => (
            <Text key={i} className="text-red-400 font-[blinker]">{each}</Text>
          ))}
        </View>
      ) : null}
    </View>
  );
};

export default SelectInput;
