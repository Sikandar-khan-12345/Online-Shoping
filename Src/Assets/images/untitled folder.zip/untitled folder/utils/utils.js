
let ERROR_MSG = "Feild is Required"
export const formRequiredValidationErrorGen = (values, requiredData) => {
    let errors = {}
    let isErrors = false
    requiredData?.map(each => {
        let fieldError = []
        if (each?.type == "email") {
            let value = values[each?.key];
            if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(value))) {
                fieldError.push(`Invalid ${each.label}`)
            }
        }
        if (!values?.[each.key]) {
            fieldError.push(`${each.label} ${ERROR_MSG}`)
            isErrors = true
        }
        else if (each?.equalLength && each?.equalLength != values?.[each.key]?.length) {
            fieldError.push(`Invalid ${each.label}`)
            isErrors = true
        }
        else if (each.minLength && each.minLength > values?.[each.key]?.length) {
            fieldError.push(`${each.label} should be min of ${each.minLength} Characters`)
            isErrors = true
        }
        errors[each?.key] = fieldError
    })
    return [isErrors, errors]
}
export const randomeString = (length = 10) => {
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const charactersLength = characters.length;
    let counter = 0;
    while (counter < length) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
        counter += 1;
    }
    return result;
}
export const isValidForm = (form = {}) => {
    let valid = true;
    for (const field in form) {
      if (Object.hasOwnProperty.call(form, field)) {
        const error = form[field];
        valid = valid && !error;
      }
    }
    return valid;
  };