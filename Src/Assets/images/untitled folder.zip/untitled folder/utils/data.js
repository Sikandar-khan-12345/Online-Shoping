export const createdByOptions = [
    { label: "Self", value: 'SELF' },
    { label: "Parents", value: 'PARENTS' },
    { label: "Relative", value: 'RELATIVE' },
    { label: "Others", value: 'OTHERS' },
];
export const genderOptions = [
    { label: "Male", value: 'MALE' },
    { label: "Female", value: 'FEMALE' },
];

export const yesNoOptions = [
    { label: "Yes", value: 'Yes' },
    { label: "No", value: 'No' },
];

export const makeDropDownData = (arr=[]) => {
    return arr.map((item)=>({label:item,value:item}))
}

export const basicDetailsUpdateInputs = [
    {
        label: "Created By",
        key: "profile_created_by"
    },
    {
        label: "First Name",
        key: "first_name"
    },
    {
        label: "Last Name",
        key: "last_name"
    },

    {
        label: "Mobile",
        key: "mobile_number",
        minLength: 10
    },
    {
        label: "Whatsapp Number",
        key: "whatsapp_number",
        minLength: 10
    },
    {
        label: "Mobile",
        key: "mobile_number",
        minLength: 10
    },
    {
        label: "Aakana",
        key: "aakana"
    },
    {
        label: "Religion",
        key: "religion"
    },
    {
        label: "Country",
        key: "country"
    },
    {
        label: "State",
        key: "state"
    },
    {
        label: "City",
        key: "city"
    },
]

export const RequiredBasicDetails = [
    ...basicDetailsUpdateInputs,
    {
        label: "Password",
        key: "password",
        minLength: 8
    }
]

export const RequiredLoginFields = [
    {
        label: "Email",
        key: "email",
        type : "email"
    },
    {
        label: "Password",
        key: "password",
        minLength: 6
    },
]