export default {
    primary: '#ef4f5f',
    white: '#ffffff',
    black: '#000000',
    gray: '#ccc',
}