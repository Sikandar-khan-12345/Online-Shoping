import AsyncStorage from '@react-native-async-storage/async-storage';
import { createRef } from 'react';
import { EventRegister } from 'react-native-event-listeners'
// import SimpleToast from 'react-native-simple-toast';
export const toastRef = createRef()
const getAuth = async () => {
    let token = await AsyncStorage.getItem('user')
    if (token) {
        let userData = JSON.parse(token)
        return userData['access_token']
    }
    return null
}

// export const BASE_URL = '';
export const BASE_URL = 'https://gahoirishtey.com'
export const API = `${BASE_URL}/api/`;

export const statusMessage = {
    400: 'Invalid request format.',
    401: 'Invalid API Key.',
    403: 'The request is forbidden.',
    404: 'The specified resource could not be found.',
    405: 'You tried to access the resource with an invalid method.',
    500: 'We had a problem with our server. Try again later.',
    503: "We're temporarily offline for maintenance. Please try again later.",
};

export const getToken = async () => {
    const token = await AsyncStorage.getItem('TOKEN');
    print(token);
    return token;
};
export const authStatus = async () => {
    const auth = await AsyncStorage.getItem('isAuth');
    print(auth);
    return auth;
};
export const getUserData = async (field = null) => {
    const userDataRes = await AsyncStorage.getItem('user');
    if (!field) {
        return JSON.parse(userDataRes);
    } else {
        const userData = JSON.parse(userDataRes);
        return userData[field];
    }
};
export const Toast = (msg, type = 'normal', config) => {
    toastRef.current?.show(msg, { type, ...config })
    // toast.show(msg, { type, ...config })
}
const responseBack = (data, msg, status) => {
    return {
        data,
        msg,
        status,
    };
};
export const logoutHandler = async () => {
    try {
        await AsyncStorage.removeItem('isAuth');
        await AsyncStorage.removeItem('userData');
        await AsyncStorage.removeItem('TOKEN');
        await AsyncStorage.removeItem('userType');

        return Toast('Logged out successfully');
    } catch (error) {
        console.log(error);
    }
};
const printAPIDetails = (token, url, body) => {
    // print every api data on console for test purpose you can comment in live build
    print('TOKEN : ', token);
    print('URL : ', url);
    print('BODY : ', body);
    return;
};
export const POST = async (
    route,
    body = {},
    onSuccess = () => { },
    onError = () => { },
    onFail = () => {
        Toast('Check Network, Try Again.');
    },
    headers = {}
) => {
    try {
        printAPIDetails('NO TOKEN', route, body);
        const res = await fetch(route, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                ...headers
                // 'Accept-Language': strings.getLanguage(),
            },
            body: JSON.stringify(body),
        });


        if (res.status == 401 || res.status == 403) {
            EventRegister.emit('updateIsAuth')
            // Toast(`${statusMessage[res.status]}`)
            onError({ data: null, message: statusMessage[res.status], status: 'error' });
            return
        }

        if (res.status !== 200) {
            const resText = await res.text();
            print(resText);
            onError(resText);
            // onError({ data: null, msg: statusMessage[res.status], status: 'error' });
            return { data: null, msg: statusMessage[res.status], status: 'error' };
        }
        const resJSON = await res.json();
        console.log('resJSON-----', resJSON);
        if (resJSON.success == true) {
            onSuccess(resJSON);
            return {
                ...resJSON,
            };
        } else {
            onError(resJSON);
            return {
                ...resJSON,
            };
        }
    } catch (error) {
        console.log(error);
        onFail({ data: null, msg: 'Network Error', status: 'error' });
        return { data: null, msg: 'Network Error', status: 'error' };
    }
};
export const POST_FORMDATA = async (
    route,
    body = {},
    onSuccess = () => { },
    onError = () => { },
    onFail = () => {
        Toast('Check Network, Try Again.');
    },
) => {
    const token = await getAuth();
    printAPIDetails('NO TOKEN', route, body);
    try {
        const res = await fetch(route, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'multipart/form-data',
                // 'Accept-Language': strings.getLanguage(),
            },
            body,
        });

        // console.log('here 2');
        // console.log(res.status);
        if (res.status == 401 || res.status == 403) {
            EventRegister.emit('updateIsAuth')
            Toast(`${statusMessage[res.status]}`)
            onError({ data: null, msg: statusMessage[res.status], status: 'error' });
            return
        }
        if (res.status !== 200) {
            const resText = await res.text();
            print(resText);
            // console.log('==>', resText);
            // console.log(res.status, statusMessage[res.status]);
            Toast(`Try Again, ${statusMessage[res.status]}`, 'danger');
            onError({ data: null, message: statusMessage[res.status], status: 'error' });
            return { data: null, message: statusMessage[res.status], status: 'error' };
        }
        const resJSON = await res.json();
        if (resJSON.success == true) {
            onSuccess(resJSON);
            return {
                ...resJSON,
            };
        } else {
            onError(resJSON);
            return {
                ...resJSON,
            };
        }
    } catch (error) {
        console.log('FAIL', error, token);
        onFail({ data: null, message: 'Network Error', status: 'error' });
        return { data: null, message: 'Network Error', status: 'error' };
    }
};
export const GET = async (
    route,
    onSuccess = () => { },
    onError = () => { },
    onFail = () => {
        Toast('Check Network, Try Again.');
    },
) => {
    // console.log('LANG', strings.getLanguage());
    printAPIDetails('NO TOKEN', route, 'No Body');
    try {
        const res = await fetch(route, {
            headers: {
                'Content-Type': 'application/json',
                // 'Accept-Language': strings.getLanguage(),
            },
            method: 'GET',
        });
        // console.log(res.status);
        if (res.status == 401 || res.status == 403) {
            EventRegister.emit('updateIsAuth')
            Toast(`${statusMessage[res.status]}`)
            onError({ data: null, msg: statusMessage[res.status], status: 'error' });
            return
        }
        if (res.status !== 200) {
            const resText = await res.text();
            print(resText);
            onError({ data: null, msg: statusMessage[res.status], status: 'error' });
            return { data: null, msg: statusMessage[res.status], status: 'error' };
        }
        const resJSON = await res.json();
        if (resJSON.success == true) {
            // console.log(route, resJSON.msg);
            onSuccess(resJSON);
            return {
                ...resJSON,
            };
        } else {
            // console.log(route, resJSON.msg);
            onError(resJSON);
            return {
                ...resJSON,
            };
        }
    } catch (error) {
        onFail({ data: null, msg: 'Network Error', status: 'error' });
        return { data: null, msg: 'Network Error', status: 'error' };
    }
};
export const POST_WITH_TOKEN = async (
    route,
    body = {},
    onSuccess = () => { },
    onError = () => { },
    onFail = () => {
        Toast('Check Network, Try Again.');
    },
    headers = { 'Content-Type': 'application/json' },
) => {
    try {
        const token = await getAuth();
        printAPIDetails(token, route, body);

        const res = await fetch(route, {
            headers: {
                Authorization: `Bearer ${token}`,
                "Accept": "application/json",
                // 'Accept-Language': strings.getLanguage(),
                ...headers,
            },
            body,
            method: 'POST',
        });
        // console.log(res.status);

        if (res.status == 401 || res.status == 403) {
            EventRegister.emit('updateIsAuth')
            Toast(`${statusMessage[res.status]}`)
            onError({ data: null, msg: statusMessage[res.status], status: 'error' });
            return
        }

        if (res.status !== 200) {
            const resText = await res.text();
            print(resText);
            onError({ data: null, msg: statusMessage[res.status], status: 'error' });
            return { data: null, msg: statusMessage[res.status], status: 'error' };
        }
        const resJSON = await res.json();
        if (resJSON.success == true) {
            onSuccess(resJSON);
            return {
                ...resJSON,
            };
        } else {
            onError(resJSON);
            return {
                ...resJSON,
            };
        }
    } catch (error) {
        // console.log(route);
        // console.log(error);
        onFail({ data: null, msg: 'Network Error', status: 'error' });
        return { data: null, msg: 'Network Error', status: 'error' };
    }
};
export const POST_FORMDATA_WITH_TOKEN = async (
    route,
    body = {},
    onSuccess = () => { },
    onError = () => { },
    onFail = () => {
        Toast('Check Network, Try Again.');
    },
    headers = {
        'Content-Type': 'multipart/form-data',
        // "Accept": "application/json",
    },
) => {
    try {
        const token = await getAuth();
        printAPIDetails(token, route, body);

        const res = await fetch(route, {
            headers: {
                Authorization: `Bearer ${token}`,
                ...headers,
            },
            body,
            method: 'PUT',
        });


        if (res.status == 401 || res.status == 403) {
            EventRegister.emit('updateIsAuth')
            Toast(`${statusMessage[res.status]}`)
            onError({ data: null, msg: statusMessage[res.status], status: 'error' });
            return
        }

        if (res.status !== 200) {
            const resText = await res.text();
            print(resText);
            onError({ data: null, msg: statusMessage[res.status], status: 'error' });
            return { data: null, msg: statusMessage[res.status], status: 'error' };
        }
        const resJSON = await res.json();
        // console.log('===>>', resJSON, '==??');
        if (resJSON.success == true) {
            onSuccess(resJSON);
            return {
                ...resJSON,
            };
        } else {
            console.log(resJSON, '==??GET');
            onError(resJSON);
            return {
                ...resJSON,
            };
        }
    } catch (error) {
        // console.log(route);
        print('-----------', error);
        onFail({ data: null, msg: 'Network Error', status: 'error' });
        return { data: null, msg: 'Network Error', status: 'error' };
    }
};
export const GET_WITH_TOKEN = async (
    route,
    onSuccess = () => { },
    onError = () => { },
    onFail = () => {
        Toast('Check Network, Try Again.');
    },
    headers = {},
    status = () => { },
) => {
    try {
        // console.log(route);
        const token = await getToken();
        printAPIDetails(token, route, 'NO BODY');
        // console.log(token);
        const res = await fetch(route, {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                // 'Authorization': `Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNjc4OTAxMDc2LCJpYXQiOjE2Nzg4MTQ2NzYsImp0aSI6IjllYmY1ZGM3Nzg2ZTQ3NzBiMTJkMTBiYjRjZWQ2MTNlIiwidXNlcl9pZCI6MTR9.JGcAoaRd7ClYcdqw4PUloossqGOeOHOCzkyCu5fsZK8`,
                'Authorization': `Bearer ${token}`,
                // 'Accept-Language': strings.getLanguage(),
                ...headers,
            },
            method: 'GET',
            redirect: 'follow'
        });
        // console.log('-----------------');
        // console.log(res);
        // console.log('-----------------');
        if (res.status == 401 || res.status == 403) {
            EventRegister.emit('updateIsAuth')
            Toast(`${statusMessage[res.status]}`)
            onError({ data: null, msg: statusMessage[res.status], status: 'error' });
            return
        }
        if (res.status !== 200) {
            const resText = await res.text();
            print(resText);
            Toast(`${statusMessage[res.status]}`)
            onError({ data: null, msg: statusMessage[res.status], status: 'error' });
            status(res.status);
            return { data: null, msg: statusMessage[res.status], status: 'error' };
        }
        const resJSON = await res.json();
        if (resJSON.success == true) {
            status(res.status);
            onSuccess(resJSON);
            return {
                ...resJSON,
            };
        } else {
            // console.log('Error', resJSON);
            status(res.status);
            onError(resJSON);
            return {
                ...resJSON,
            };
        }
    } catch (error) {
        // console.log(error);
        Toast(`Check network,Try again22.`)
        onFail({ data: null, msg: 'Network Error', status: 'error', error });
        return { data: null, msg: 'Network Error', status: 'error' };
    }
};
export const DELETE_WITH_TOKEN = async (
    route,
    onSuccess = () => { },
    onError = () => { },
    onFail = () => {
        Toast('Check Network, Try Again.');
    },
    headers = {},
) => {
    // console.log(route);
    try {
        const token = await getAuth();
        printAPIDetails(token, route, null);
        const res = await fetch(route, {
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${token}`,
                // 'Accept-Language': strings.getLanguage(),
                ...headers,
            },
            method: 'DELETE',
        });
        if (res.status == 401 || res.status == 403) {
            EventRegister.emit('updateIsAuth')
            Toast(`${statusMessage[res.status]}`)
            onError({ data: null, msg: statusMessage[res.status], status: 'error' });
            return
        }

        if (res.status !== 200) {
            Toast(`Try Again, ${statusMessage[res.status]}`, 'danger');
            const resText = await res.text();
            print(resText);
            onError({ data: null, msg: statusMessage[res.status], status: 'error' });
            return { data: null, msg: statusMessage[res.status], status: 'error' };
        }
        const resJSON = await res.json();
        if (resJSON.success == true) {
            onSuccess(resJSON);
            return {
                ...resJSON,
            };
        } else {
            onError(resJSON);
            return {
                ...resJSON,
            };
        }
    } catch (error) {
        onFail({ data: null, msg: 'Network Error', status: 'error', error });
        return { data: null, msg: 'Network Error', status: 'error' };
    }
};

export const REQUEST_HANDLER = async (
    method = 'GET',
    route,
    body = {},
    onSuccess = () => { },
    onError = () => { },
    onFail = () => {
        Toast('Check Network, Try Again.');
    },
    headers = {
        'Content-Type': 'multipart/form-data',
        // "Accept": "application/json",
    },
) => {
    try {
        const token = await getToken();
        printAPIDetails(token, route, body);
        print('METHOD', method)
        const res = await fetch(route, {
            headers: {
                // Authorization: `Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNjc4NzMzNzI0LCJpYXQiOjE2Nzg2NDczMjQsImp0aSI6IjA3MWVmNDg2MjU4ZTQ0ZGY4ZmJkNjNmN2VmNDRjZDE1IiwidXNlcl9pZCI6Mn0.1rkRu2ZXpn7AtaNLBIp8oT_y_i06NvjCDhLCbqhBuAQ`,
                Authorization: `Bearer ${token}`,
                ...headers,
            },
            body,
            method,
        });

        if (res.status == 401 || res.status == 403) {
            EventRegister.emit('updateIsAuth')
            Toast(`${statusMessage[res.status]}`)
            onError({ data: null, msg: statusMessage[res.status], status: 'error' });
            return
        }

        if (res.status !== 200) {
            const resText = await res.text();
            print(resText);
            onError(resText);
            // onError({ data: null, msg: statusMessage[res.status], status: 'error' });
            return { data: null, msg: statusMessage[res.status], status: 'error' };
        }
        const resJSON = await res.json();
        console.log('===>>', resJSON, '==??');
        if (resJSON.success == true) {
            onSuccess(resJSON);
            return {
                ...resJSON,
            };
        } else {
            console.log(resJSON, '==??GET');
            onError(resJSON);
            return {
                ...resJSON,
            };
        }
    } catch (error) {
        // console.log(route);
        print('-----------', error);

        onFail({ data: null, msg: 'Network Error', status: 'error' });
        return { data: null, msg: 'Network Error', status: 'error' };
    }
}

export function onErrorFound(res, onError) {
    const errorResponse = responseBack(null, statusMessage[res.status], 'error');
    onError(errorResponse);
    return errorResponse;
}

